'use strict';

const crypto = require('crypto');
const pmPlanning = require('./pm-planning');

const REQUEST_FLOW = {
  new: ['review', 'rejected', 'cancelled'],
  review: ['rejected', 'cancelled'],
  approved: [],
  wo: [],
  closed: [],
  rejected: [],
  cancelled: []
};
const WORK_ORDER_FLOW = {
  draft: ['open', 'assigned'],
  open: ['assigned'],
  assigned: ['seen', 'doing', 'open', 'hold'],
  seen: ['doing', 'hold'],
  doing: ['hold', 'done'],
  hold: ['doing', 'assigned'],
  done: ['closed'],
  closed: [],
  cancel: []
};
const LOCKED_REQUEST = new Set(['approved', 'wo', 'closed', 'rejected', 'cancelled']);
const LOCKED_WORK_ORDER = new Set(['done', 'closed', 'cancel']);
const LOCKED_PM = new Set(['cancelled']);
const PM_OCCURRENCE_STATES = new Set(['scheduled', 'due', 'overdue', 'work_order_generated', 'in_progress', 'completed', 'cancelled', 'skipped']);
const PM_OCCURRENCE_FINAL_STATES = new Set(['completed', 'cancelled', 'skipped']);
const PM_ACTIVE_WORK_ORDER_STATES = new Set(['draft', 'open', 'assigned', 'seen', 'doing', 'hold']);
const CANCELLABLE_WORK_ORDER = new Set(['draft', 'open', 'assigned', 'seen', 'doing', 'hold']);

function coded(status, code) {
  const error = new Error(code);
  error.status = status;
  error.code = code;
  return error;
}

function asObject(value) {
  if (!value) return {};
  if (typeof value === 'string') {
    try { return JSON.parse(value); } catch (_) { return {}; }
  }
  return typeof value === 'object' ? value : {};
}

function asArray(value) {
  if (Array.isArray(value)) return value;
  if (typeof value === 'string') {
    try { const parsed = JSON.parse(value); return Array.isArray(parsed) ? parsed : []; } catch (_) { return []; }
  }
  return [];
}

function hasExecutionHistory(row) {
  if (!row) return false;
  const times = asObject(row.times);
  const report = asObject(row.report);
  return Boolean(times.start || times.end || report.text || asArray(row.parts).length);
}

function isRecipientAllowed(user, permission, equipmentId, factoryId) {
  const permissions = asArray(user.permissions);
  const permitted = user.role === 'admin' || permissions.includes('*') || permissions.includes(permission);
  if (!permitted) return false;
  if (user.role === 'admin') return true;
  const scopes = asArray(user.scopes);
  const companyWide = scopes.some(scope => scope && scope.scope_type === 'company');
  if (!equipmentId) return companyWide;
  if (companyWide) return true;
  return scopes.some(scope => scope && (
    (scope.scope_type === 'equipment' && scope.scope_id === equipmentId)
    || (factoryId && scope.scope_type === 'factory' && scope.scope_id === factoryId)
  ));
}

function assertTransition(flow, from, to) {
  if (!Object.prototype.hasOwnProperty.call(flow, from) || !flow[from].includes(to)) {
    throw coded(409, 'INVALID_STATUS_TRANSITION');
  }
}

function versionOf(value) {
  const version = Number(value);
  if (!Number.isInteger(version) || version < 1) throw coded(422, 'ROW_VERSION_REQUIRED');
  return version;
}

function reasonOf(value, code) {
  const reason = String(value || '').trim();
  if (!reason) throw coded(422, code);
  return reason.slice(0, 500);
}

function appendHistory(history, text) {
  const next = asArray(history).slice();
  next.push({ t: new Date().toISOString(), x: text });
  return next;
}

function dateIso(value, code = 'INVALID_DATE') {
  if (value == null || value === '') return null;
  const date = value instanceof Date ? new Date(value.getTime()) : new Date(value);
  if (Number.isNaN(date.getTime())) throw coded(422, code);
  return date.toISOString();
}

function timestampIso(value) {
  if (value == null || value === '') return null;
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? new Date(parsed).toISOString() : null;
}

function parsePmTimestamp(value, code = 'PM_DATE_INVALID') {
  if (value == null || value === '') return null;
  if (value instanceof Date) {
    if (!Number.isFinite(value.getTime())) throw coded(422, code);
    return value.toISOString();
  }
  if (typeof value !== 'string') throw coded(422, code);
  const text = value.trim();
  const match = text.match(/^([0-9]{4})-([0-9]{2})-([0-9]{2})(.*)$/);
  if (!match) throw coded(422, code);
  const year = Number(match[1]);
  const month = Number(match[2]);
  const day = Number(match[3]);
  const leapYear = year % 4 === 0 && (year % 100 !== 0 || year % 400 === 0);
  const daysInMonth = [31, leapYear ? 29 : 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31];
  if (month < 1 || month > 12 || day < 1 || day > daysInMonth[month - 1]) throw coded(422, code);
  const suffix = match[4];
  if (suffix && !/^T[0-9]{2}:[0-9]{2}(?::[0-9]{2}(?:[.][0-9]+)?)?(?:Z|[+-][0-9]{2}:?[0-9]{2})$/i.test(suffix)) {
    throw coded(422, code);
  }
  const parsed = Date.parse(text);
  if (!Number.isFinite(parsed)) throw coded(422, code);
  return new Date(parsed).toISOString();
}

function calendarDaysFrom(value, days) {
  const start = timestampIso(value);
  const amount = Number(days);
  if (!start || !Number.isInteger(amount) || amount < 1) return null;
  const date = new Date(start);
  date.setUTCDate(date.getUTCDate() + amount);
  return date.toISOString();
}

function nextDueAtForPlan(plan = {}) {
  const basis = String(plan.schedule_basis || plan.scheduleBasis || '').trim().toLowerCase();
  if (basis !== 'calendar') return null;
  const lastCompletedAt = parsePmTimestamp(plan.last_completed_at ?? plan.lastCompletedAt, 'PM_LAST_COMPLETED_AT_INVALID');
  const storedNextDueAt = parsePmTimestamp(plan.next_due_at ?? plan.nextDueAt, 'PM_NEXT_DUE_AT_INVALID');
  const firstDueAt = parsePmTimestamp(plan.first_due_at ?? plan.firstDueAt, 'PM_FIRST_DUE_AT_INVALID');
  const interval = plan.interval_days ?? plan.intervalDays ?? plan.interval;
  if (lastCompletedAt) {
    if (storedNextDueAt && Date.parse(storedNextDueAt) > Date.parse(lastCompletedAt)) return storedNextDueAt;
    const frequency = asObject(plan.ext).calendarFrequency;
    if (Object.hasOwn(pmPlanning.calendarMonths, frequency)) return pmPlanning.advancePersianMonths(lastCompletedAt, pmPlanning.calendarMonths[frequency]);
    return calendarDaysFrom(lastCompletedAt, frequency === 'daily' ? 1 : frequency === 'weekly' ? 7 : interval);
  }
  return storedNextDueAt || firstDueAt;
}

function calculatePmDue(plan = {}, evaluatedAt) {
  const insufficient = reason => ({ nextDueAt:null, dueStatus:'insufficient_data', reason });
  const basis = String(plan.schedule_basis || plan.scheduleBasis || '').trim().toLowerCase();
  const lastCompletedAt = parsePmTimestamp(plan.last_completed_at ?? plan.lastCompletedAt, 'PM_LAST_COMPLETED_AT_INVALID');
  parsePmTimestamp(plan.first_due_at ?? plan.firstDueAt, 'PM_FIRST_DUE_AT_INVALID');
  parsePmTimestamp(plan.next_due_at ?? plan.nextDueAt, 'PM_NEXT_DUE_AT_INVALID');
  const evaluationIso = parsePmTimestamp(evaluatedAt, 'PM_EVALUATED_AT_INVALID');
  if (!basis) return insufficient('schedule_basis_missing');
  if (basis !== 'calendar') return insufficient('unsupported_schedule_basis');
  const nextDueAt = nextDueAtForPlan(plan);
  if (!nextDueAt) {
    return insufficient(lastCompletedAt ? 'calendar_interval_missing_or_invalid' : 'first_or_next_due_at_missing');
  }
  if (!evaluationIso) return insufficient('evaluation_time_required');
  const toleranceValue = Number(plan.tolerance_days ?? plan.toleranceDays ?? 0);
  if (!Number.isInteger(toleranceValue) || toleranceValue < 0) throw coded(422, 'PM_TOLERANCE_DAYS_INVALID');
  const dueDay = Math.floor(Date.parse(nextDueAt) / 86400000);
  const currentDay = Math.floor(Date.parse(evaluationIso) / 86400000);
  if (!Number.isFinite(dueDay) || !Number.isFinite(currentDay)) throw coded(422, 'PM_SCHEDULE_DATE_INVALID');
  if (currentDay < dueDay) return { nextDueAt, dueStatus:'scheduled', reason:null };
  if (currentDay <= dueDay + toleranceValue) return { nextDueAt, dueStatus:'due', reason:null };
  return { nextDueAt, dueStatus:'overdue', reason:null };
}

function periodKeyForDueDate(value, basis = 'calendar') {
  const iso = parsePmTimestamp(value, 'PM_DUE_DATE_INVALID');
  if (!iso) throw coded(422, 'PM_DUE_DATE_REQUIRED');
  if (String(basis).trim().toLowerCase() !== 'calendar') throw coded(422, 'PM_SCHEDULE_BASIS_UNSUPPORTED');
  return `calendar:${iso.slice(0, 10)}`;
}

function occurrenceDto(row) {
  return {
    id:row.id, pmPlanId:row.pm_plan_id, equipmentId:row.equipment_id, periodKey:row.period_key,
    dueAt:row.due_at, dueMeterValue:row.due_meter_value == null ? null : Number(row.due_meter_value),
    status:row.status, workOrderId:row.linked_work_order_id || null, generatedAt:row.generated_at || null,
    startedAt:row.started_at || null, completedAt:row.completed_at || null, cancelledAt:row.cancelled_at || null,
    cancellationReason:row.cancellation_reason || null, completionSource:row.completion_source || null,
    provenanceStatus:row.provenance_status || 'verified', rowVersion:Number(row.row_version),
    createdAt:row.created_at, updatedAt:row.updated_at, createdBy:row.created_by || null, updatedBy:row.updated_by || null
  };
}

function positiveInteger(value, code, { nullable = true, maximum = 1000000 } = {}) {
  if (value == null || value === '') {
    if (nullable) return null;
    throw coded(422, code);
  }
  const number = Number(value);
  if (!Number.isInteger(number) || number < 1 || number > maximum) throw coded(422, code);
  return number;
}

function nonNegativeInteger(value, code, maximum = 3650) {
  if (value == null || value === '') return 0;
  const number = Number(value);
  if (!Number.isInteger(number) || number < 0 || number > maximum) throw coded(422, code);
  return number;
}

function pmListValue(row, snake, camel, fallback) {
  if (Object.prototype.hasOwnProperty.call(row, snake)) return row[snake];
  if (Object.prototype.hasOwnProperty.call(row, camel)) return row[camel];
  return fallback;
}

function equipmentOf(row) {
  if (!row.asset_id && !row.equipment_id) return null;
  return {
    id: row.equipment_id || row.asset_id,
    code: row.equipment_code || null,
    name: row.equipment_name || null
  };
}

function requestDto(row) {
  return {
    id: row.id, no: row.no, type: row.type, unit: row.unit, requester: row.requester,
    requesterId: row.requester_id, assetId: row.asset_id, equipment: equipmentOf(row),
    desc: row.descr, descr: row.descr, urgency: row.urgency, impact: row.impact === true,
    status: row.status, form: asObject(row.form), history: asArray(row.history),
    createdAt: row.created_at, updatedAt: row.updated_at, rowVersion: Number(row.row_version),
    workOrderId: row.work_order_id, cancelReason: row.cancel_reason, deletedAt: row.deleted_at || null
  };
}

function workOrderDto(row) {
  return {
    id: row.id, no: row.no, type: row.type, assetId: row.asset_id, equipment: equipmentOf(row),
    desc: row.descr, descr: row.descr, priority: row.priority, assignee: row.assignee,
    status: row.status, reqId: row.req_id, pmId: row.pm_id, ptw: row.ptw === true,
    ptwId: row.ptw_id || null, permitStatus: row.permit_status || (row.ptw ? 'pending_issuance' : 'not_required'),
    occurrenceId:row.occurrence_id || null, dueAt:row.due_at || null,
    failureType: row.failure_type || null, probableCauses: asArray(row.probable_causes),
    confirmedRootCause: row.confirmed_root_cause || null, recommendedAction: row.recommended_action || null,
    performedAction: row.performed_action || null, requiredParts: asArray(row.required_parts),
    times: asObject(row.times), parts: asArray(row.parts), report: asObject(row.report),
    est: row.est == null ? null : Number(row.est), createdAt: row.created_at, updatedAt: row.updated_at,
    rowVersion: Number(row.row_version), holdReason: row.hold_reason, cancelReason: row.cancel_reason,
    requesterOK: row.requester_confirmed_at ? { by: row.requester_confirmed_name || row.requester_confirmed_by, t: row.requester_confirmed_at, note: row.requester_confirmation_note || null } : null,
    deletedAt: row.deleted_at || null
  };
}

function pmDto(row, evaluatedAt = new Date()) {
  const checklistItems = asArray(row.checklist);
  const checklist = checklistItems.map(pmPlanning.checklistLabel).filter(Boolean);
  const metadata = asObject(row.ext);
  const due = calculatePmDue(row, evaluatedAt);
  return {
    id:row.id, code:row.code || null, assetId:row.asset_id, equipment:equipmentOf(row), title:row.title,
    interval:row.interval_days, intervalDays:row.interval_days, scheduleBasis:row.schedule_basis || null,
    firstDueAt:row.first_due_at || null, nextDueAt:due.nextDueAt, dueStatus:due.dueStatus, dueReason:due.reason || null,
    periodKey:due.nextDueAt && String(row.schedule_basis || '').toLowerCase() === 'calendar' ? `calendar:${due.nextDueAt.slice(0, 10)}` : null,
    toleranceDays:Number(row.tolerance_days || 0), last:row.last_completed_at || null,
    lastCompletedAt:row.last_completed_at || null, provenanceStatus:row.provenance_status || 'legacy_unverified',
    estimatedDurationMinutes:row.estimated_duration_minutes == null ? null : Number(row.estimated_duration_minutes),
    requiredSkill:row.required_skill || null, requiredPersonnel:row.required_personnel == null ? null : Number(row.required_personnel),
    requiredTools:asArray(row.required_tools), requiredParts:asArray(row.required_parts),
    safetyRequirements:asArray(row.safety_requirements), lotoRequired:row.loto_required === true,
    ptwRequired:row.ptw_required === true, instructions:row.instructions || '', spec:row.spec || '',
    owner:row.owner || null, sup:row.sup || null, kind:row.kind || 'PM', checklist, checklistItems,
    calendarFrequency:metadata.calendarFrequency || 'custom', targetNodeId:metadata.targetNodeId || null, targetName:row.target_name || null, activityGroup:metadata.activityGroup || null,
    activityType:metadata.activityType || null, productionStopRequired:metadata.productionStopRequired ?? null,
    status:row.status || 'active', archivedAt:row.archived_at || null, archivedBy:row.archived_by || null,
    archiveReason:row.archive_reason || null, cancelReason:row.cancel_reason || null,
    createdAt:row.created_at, updatedAt:row.updated_at, rowVersion:Number(row.row_version),
    deletedAt:row.deleted_at || null
  };
}

async function withTransaction(pool, work) {
  const client = await pool.connect();
  try {
    await client.query('BEGIN');
    const result = await work(client);
    await client.query('COMMIT');
    return result;
  } catch (error) {
    try {
      await client.query('ROLLBACK');
    } catch (rollbackError) {
      if (error && typeof error === 'object') error.rollbackError = rollbackError;
    }
    throw error;
  } finally {
    client.release();
  }
}

function mapPmDatabaseError(error) {
  if (error && error.code === '23505') {
    const constraint = String(error.constraint || '');
    if (constraint.includes('pm_plans_active_asset_code')) return coded(409, 'PM_CODE_CONFLICT');
    if (constraint.includes('pm_occurrences_plan_period')) return coded(409, 'PM_OCCURRENCE_CONFLICT');
    if (constraint.includes('work_orders_occurrence')) return coded(409, 'PM_OCCURRENCE_WORK_ORDER_CONFLICT');
    return coded(409, 'PM_UNIQUE_CONFLICT');
  }
  if (error && error.code === '23503') return coded(409, 'PM_REFERENCE_CONFLICT');
  if (error && ['40P01','40001'].includes(error.code)) return coded(409, 'VERSION_CONFLICT');
  if (error && /^[0-9A-Z]{5}$/.test(String(error.code))) return coded(500, 'PM_TRANSACTION_FAILED');
  return error;
}

async function withPmTransaction(pool, work) {
  try {
    return await withTransaction(pool, work);
  } catch (error) {
    throw mapPmDatabaseError(error);
  }
}

async function lockPmWorkOrderContext(client, workOrder) {
  if (!workOrder.occurrence_id) return null;
  if (!workOrder.pm_id) throw coded(409, 'PM_OCCURRENCE_LINK_MISMATCH');
  const { rows:plans } = await client.query('SELECT * FROM pm_plans WHERE id=$1 FOR UPDATE', [workOrder.pm_id]);
  const plan = plans[0];
  if (!plan || plan.deleted_at) throw coded(409, 'PM_PLAN_NOT_FOUND');
  const { rows:occurrences } = await client.query('SELECT * FROM pm_occurrences WHERE id=$1 FOR UPDATE', [workOrder.occurrence_id]);
  const occurrence = occurrences[0];
  if (!occurrence) throw coded(409, 'PM_OCCURRENCE_NOT_FOUND');
  if (String(occurrence.pm_plan_id) !== String(workOrder.pm_id)
    || String(occurrence.equipment_id) !== String(workOrder.asset_id)
    || String(plan.id) !== String(workOrder.pm_id)
    || String(plan.asset_id) !== String(occurrence.equipment_id)) {
    throw coded(409, 'PM_OCCURRENCE_LINK_MISMATCH');
  }
  if (!PM_OCCURRENCE_STATES.has(occurrence.status)) throw coded(409, 'PM_OCCURRENCE_STATUS_INVALID');
  return { plan, occurrence };
}

function assertPmStartConsistency(workOrder, occurrence) {
  if (occurrence.status !== 'in_progress') throw coded(409, 'PM_START_INCONSISTENT');
  const workStart = parsePmTimestamp(asObject(workOrder.times).start, 'PM_START_INCONSISTENT');
  const occurrenceStart = parsePmTimestamp(occurrence.started_at, 'PM_START_INCONSISTENT');
  if (!workStart || !occurrenceStart || Date.parse(workStart) !== Date.parse(occurrenceStart)) {
    throw coded(409, 'PM_START_INCONSISTENT');
  }
}

function assertPmCompletionConsistency(workOrder, context) {
  const { plan, occurrence } = context;
  if (occurrence.status !== 'completed' || occurrence.completion_source !== 'work_order') {
    throw coded(409, 'PM_COMPLETION_INCONSISTENT');
  }
  assertPmStartConsistency(workOrder, { ...occurrence, status:'in_progress' });
  const workEnd = parsePmTimestamp(asObject(workOrder.times).end, 'PM_COMPLETION_INCONSISTENT');
  const occurrenceEnd = parsePmTimestamp(occurrence.completed_at, 'PM_COMPLETION_INCONSISTENT');
  const planLastCompleted = parsePmTimestamp(plan.last_completed_at, 'PM_COMPLETION_INCONSISTENT');
  const planNextDue = parsePmTimestamp(plan.next_due_at, 'PM_COMPLETION_INCONSISTENT');
  if (!workEnd || !occurrenceEnd || !planLastCompleted
    || Date.parse(workEnd) !== Date.parse(occurrenceEnd)
    || Date.parse(planLastCompleted) < Date.parse(occurrenceEnd)) {
    throw coded(409, 'PM_COMPLETION_INCONSISTENT');
  }
  const expected = calculatePmDue({
    schedule_basis:plan.schedule_basis,
    interval_days:plan.interval_days,
    last_completed_at:planLastCompleted,
    next_due_at:null,
    tolerance_days:plan.tolerance_days
  }, planLastCompleted);
  if (expected.nextDueAt !== planNextDue) throw coded(409, 'PM_COMPLETION_INCONSISTENT');
}

async function reservePmGenerationRequest(client, userId, idempotencyKey, requestHash) {
  await client.query(
    `DELETE FROM idempotency_keys WHERE user_id=$1 AND idempotency_key=$2 AND expires_at<=now()`,
    [userId, idempotencyKey]
  );
  const inserted = await client.query(
    `INSERT INTO idempotency_keys(user_id,idempotency_key,request_hash,expires_at)
     VALUES($1,$2,$3,now()+interval '24 hours')
     ON CONFLICT(user_id,idempotency_key) DO NOTHING RETURNING idempotency_key`,
    [userId, idempotencyKey, requestHash]
  );
  if (inserted.rows[0]) return null;
  const existing = await client.query(
    `SELECT request_hash,response_status,response_body FROM idempotency_keys
     WHERE user_id=$1 AND idempotency_key=$2 FOR UPDATE`, [userId, idempotencyKey]
  );
  const row = existing.rows[0];
  if (!row) throw coded(409, 'DUPLICATE_REQUEST_PENDING');
  if (row.request_hash !== requestHash) throw coded(409, 'IDEMPOTENCY_KEY_REUSED');
  if (Number(row.response_status) !== 201 || !row.response_body) throw coded(409, 'DUPLICATE_REQUEST_PENDING');
  const body = typeof row.response_body === 'string' ? JSON.parse(row.response_body) : row.response_body;
  if (!body || !body.occurrence || !body.workOrder) throw coded(409, 'DUPLICATE_REQUEST_PENDING');
  return body;
}

async function findPmOccurrence(client, planId, periodKey) {
  const { rows } = await client.query(
    `SELECT o.*, w.id AS linked_work_order_id
     FROM pm_occurrences o LEFT JOIN work_orders w ON w.occurrence_id=o.id
     WHERE o.pm_plan_id=$1 AND o.period_key=$2 FOR UPDATE OF o`,
    [planId, periodKey]
  );
  return rows[0] || null;
}

async function findPmWorkOrder(client, occurrenceId) {
  const { rows } = await client.query(
    `SELECT w.*, a.id AS equipment_id, a.code AS equipment_code, a.name AS equipment_name
     FROM work_orders w LEFT JOIN assets a ON a.id=w.asset_id
     WHERE w.occurrence_id=$1 ORDER BY w.created_at LIMIT 1`,
    [occurrenceId]
  );
  return rows[0] || null;
}

async function nextNumber(client, name, prefix) {
  const { rows } = await client.query(
    `INSERT INTO maintenance_counters(name, value) VALUES($1, 1)
     ON CONFLICT(name) DO UPDATE SET value = maintenance_counters.value + 1
     RETURNING value`,
    [name]
  );
  return `${prefix}-${String(rows[0].value).padStart(6, '0')}`;
}

async function requireEquipment(client, assetId, required = false) {
  if (!assetId) {
    if (required) throw coded(422, 'EQUIPMENT_REQUIRED');
    return null;
  }
  const { rows } = await client.query(
    'SELECT id, code, name, deleted_at FROM assets WHERE id=$1',
    [assetId]
  );
  if (!rows[0] || rows[0].deleted_at) throw coded(422, 'EQUIPMENT_NOT_FOUND');
  return rows[0];
}

async function requireUser(client, userId) {
  if (!userId) return null;
  const { rows } = await client.query('SELECT id FROM users WHERE id=$1 AND active=true', [userId]);
  if (!rows[0]) throw coded(422, 'ASSIGNEE_NOT_FOUND');
  return rows[0].id;
}

async function lockRow(client, table, id) {
  const { rows } = await client.query(`SELECT * FROM ${table} WHERE id=$1 FOR UPDATE`, [id]);
  if (!rows[0] || rows[0].deleted_at) throw coded(404, 'RECORD_NOT_FOUND');
  return rows[0];
}

async function writeUpdate(client, table, id, rowVersion, userId, fields) {
  const keys = Object.keys(fields);
  const values = keys.map(key => fields[key]);
  const assignments = keys.map((key, index) => `${key}=$${index + 3}`).join(', ');
  const userIndex = keys.length + 3;
  const { rows } = await client.query(
    `UPDATE ${table} SET ${assignments}, updated_at=now(), updated_by=$${userIndex}, row_version=row_version+1
     WHERE id=$1 AND row_version=$2 AND deleted_at IS NULL RETURNING *`,
    [id, rowVersion, ...values, userId]
  );
  if (!rows[0]) throw coded(409, 'VERSION_CONFLICT');
  return rows[0];
}

async function audit(client, user, action, module, entity, before, after, note) {
  await client.query(
    `INSERT INTO audit_x(id,t,u,uid,role,action,mod,entity,note,before,after)
     VALUES($1,now(),$2,$3,$4,$5,$6,$7,$8,$9,$10)`,
    [crypto.randomUUID(), user.name || user.username, user.id, user.role, action, module, entity, note,
      before ? JSON.stringify(before) : null, after ? JSON.stringify(after) : null]
  );
}

async function factoryOf(client, equipmentId) {
  if (!equipmentId) return null;
  const { rows } = await client.query(
    `WITH RECURSIVE ancestors(id,parent,node_kind,depth) AS (
       SELECT a.id,a.parent,a.ext->>'nodeKind',0 FROM assets a WHERE a.id=$1
       UNION ALL
       SELECT p.id,p.parent,p.ext->>'nodeKind',ancestors.depth+1
       FROM assets p JOIN ancestors ON p.id=ancestors.parent WHERE ancestors.depth < 64
     )
     SELECT COALESCE(c.factory_asset_id,
       (SELECT id FROM ancestors WHERE lower(COALESCE(node_kind,''))='factory' ORDER BY depth LIMIT 1)
     ) AS factory_asset_id
     FROM assets a LEFT JOIN asset_categories c ON c.id=a.category_id WHERE a.id=$1`,
    [equipmentId]
  );
  return rows[0] ? rows[0].factory_asset_id || null : null;
}

async function userScopes(client, user) {
  if (!user || !user.id) throw coded(403, 'EQUIPMENT_SCOPE_DENIED');
  if (user.role === 'admin') return [];
  const { rows } = await client.query(
    'SELECT scope_type,scope_id FROM user_scopes WHERE user_id=$1', [user.id]
  );
  return rows;
}

function scopeAllows(scopes, equipmentId, factoryId) {
  return scopes.some(scope => scope && (
    scope.scope_type === 'company'
    || (scope.scope_type === 'equipment' && scope.scope_id === equipmentId)
    || (factoryId && scope.scope_type === 'factory' && scope.scope_id === factoryId)
  ));
}

async function assertEquipmentScope(client, user, equipmentId, knownFactoryId = null) {
  const equipment = await requireEquipment(client, equipmentId, true);
  if (!user || !user.id) throw coded(403, 'EQUIPMENT_SCOPE_DENIED');
  if (user.role === 'admin') return { equipment, factoryId:knownFactoryId || await factoryOf(client, equipmentId) };
  const scopes = await userScopes(client, user);
  const factoryId = knownFactoryId || await factoryOf(client, equipmentId);
  if (!scopeAllows(scopes, equipmentId, factoryId)) throw coded(403, 'EQUIPMENT_SCOPE_DENIED');
  return { equipment, factoryId };
}

async function selectRecipients(client, permission, equipmentId) {
  const factoryId = await factoryOf(client, equipmentId);
  const { rows } = await client.query(
    `SELECT u.id, u.role,
      COALESCE((SELECT jsonb_agg(rp.permission) FROM role_permissions rp WHERE rp.role=u.role AND rp.granted=true), '[]'::jsonb) AS permissions,
      COALESCE((SELECT jsonb_agg(jsonb_build_object('scope_type', s.scope_type, 'scope_id', s.scope_id)) FROM user_scopes s WHERE s.user_id=u.id), '[]'::jsonb) AS scopes
     FROM users u WHERE u.active=true`
  );
  return rows.filter(user => isRecipientAllowed(user, permission, equipmentId, factoryId)).map(user => user.id);
}

async function publish(client, user, event) {
  const recipients = await selectRecipients(client, event.permission, event.equipmentId || null);
  await client.query(
    `INSERT INTO event_outbox(id,event_type,aggregate_type,aggregate_id,actor_id,payload,recipient_ids)
     VALUES($1,$2,$3,$4,$5,$6,$7)`,
    [crypto.randomUUID(), event.type, event.aggregateType, event.aggregateId, user.id,
      JSON.stringify(event.payload), JSON.stringify(recipients)]
  );
  return recipients;
}

async function linkWorkOrderAsset(client, workOrderId, assetId) {
  if (!assetId) return;
  await client.query(
    `INSERT INTO work_order_assets(work_order_id, asset_id, relation_type, is_confirmed)
     VALUES($1,$2,'primary',true)
     ON CONFLICT(work_order_id, asset_id, relation_type) DO NOTHING`,
    [workOrderId, assetId]
  );
}

async function createRequestInTransaction(client, user, input) {
  const descr = String(input.descr || input.desc || '').trim();
  if (!descr) throw coded(422, 'DESCRIPTION_REQUIRED');
  const assetId = input.assetId || null;
  await requireEquipment(client, assetId, false);
  const id = crypto.randomUUID();
  const no = await nextNumber(client, 'request', 'WR');
  const history = appendHistory([], `ثبت درخواست توسط ${user.name || user.username}`);
  const form = input.form && typeof input.form === 'object' && !Array.isArray(input.form) ? input.form : {};
  const { rows } = await client.query(
    `INSERT INTO requests(id,no,type,unit,requester,requester_id,asset_id,descr,urgency,impact,status,form,history)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'new',$11,$12) RETURNING *`,
    [id, no, input.type || 'repair', String(input.unit || user.unit || '').trim() || null, user.name || user.username, user.id,
      assetId, descr, input.urgency || 'normal', input.impact === true,
      JSON.stringify(form), JSON.stringify(history)]
  );
  await audit(client, user, 'create', 'request', id, null, rows[0], 'ثبت درخواست کار');
  await publish(client, user, {
    type: 'request.created', aggregateType: 'request', aggregateId: id, permission: 'request.view',
    equipmentId: assetId, payload: { id, no, status: 'new', assetId }
  });
  return requestDto(rows[0]);
}

async function createRequest(pool, user, input) {
  return withTransaction(pool, client => createRequestInTransaction(client, user, input));
}

async function listRequests(pool, filters = {}) {
  const { rows } = await pool.query(
    `SELECT r.*, a.id AS equipment_id, a.code AS equipment_code, a.name AS equipment_name
     FROM requests r LEFT JOIN assets a ON a.id=r.asset_id
     WHERE r.deleted_at IS NULL AND ($1::text IS NULL OR r.asset_id=$1)
     ORDER BY r.created_at DESC LIMIT 500`,
    [filters.assetId || null]
  );
  return rows.map(requestDto);
}

async function getRequest(pool, id) {
  const { rows } = await pool.query(
    `SELECT r.*, a.id AS equipment_id, a.code AS equipment_code, a.name AS equipment_name
     FROM requests r LEFT JOIN assets a ON a.id=r.asset_id
     WHERE r.id=$1 AND r.deleted_at IS NULL`,
    [id]
  );
  if (!rows[0]) throw coded(404, 'RECORD_NOT_FOUND');
  return requestDto(rows[0]);
}

async function updateRequest(pool, user, id, input) {
  const rowVersion = versionOf(input.rowVersion);
  return withTransaction(pool, async client => {
    const current = await lockRow(client, 'requests', id);
    if (LOCKED_REQUEST.has(current.status)) throw coded(409, 'RECORD_LOCKED');
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    const assetId = input.assetId === undefined ? current.asset_id : (input.assetId || null);
    await requireEquipment(client, assetId, false);
    const descr = String(input.descr ?? current.descr ?? '').trim();
    if (!descr) throw coded(422, 'DESCRIPTION_REQUIRED');
    const updated = await writeUpdate(client, 'requests', id, rowVersion, user.id, {
      type: input.type || current.type,
      unit: input.unit === undefined ? current.unit : input.unit,
      asset_id: assetId,
      descr,
      urgency: input.urgency || current.urgency,
      impact: input.impact === undefined ? current.impact : input.impact === true,
      form: JSON.stringify(input.form || asObject(current.form)),
      history: JSON.stringify(appendHistory(current.history, `ویرایش توسط ${user.name || user.username}`))
    });
    await audit(client, user, 'edit', 'request', id, current, updated, 'ویرایش درخواست');
    await publish(client, user, {
      type: 'request.updated', aggregateType: 'request', aggregateId: id, permission: 'request.view',
      equipmentId: updated.asset_id, payload: { id, no: updated.no, status: updated.status, assetId: updated.asset_id, rowVersion: Number(updated.row_version) }
    });
    return requestDto(updated);
  });
}

async function transitionRequest(pool, user, id, input) {
  const rowVersion = versionOf(input.rowVersion);
  const status = String(input.status || '');
  return withTransaction(pool, async client => {
    const current = await lockRow(client, 'requests', id);
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    assertTransition(REQUEST_FLOW, current.status, status);
    const reason = ['rejected', 'cancelled'].includes(status) ? reasonOf(input.reason, 'CANCEL_REASON_REQUIRED') : null;
    const updated = await writeUpdate(client, 'requests', id, rowVersion, user.id, {
      status,
      cancel_reason: status === 'cancelled' || status === 'rejected' ? reason : current.cancel_reason,
      cancelled_at: status === 'cancelled' ? new Date().toISOString() : current.cancelled_at,
      history: JSON.stringify(appendHistory(current.history, `${status} توسط ${user.name || user.username}${reason ? ' — ' + reason : ''}`))
    });
    await audit(client, user, 'transition', 'request', id, current, updated, reason || status);
    await publish(client, user, {
      type: 'request.transitioned', aggregateType: 'request', aggregateId: id, permission: 'request.view',
      equipmentId: updated.asset_id, payload: { id, status, assetId: updated.asset_id, rowVersion: Number(updated.row_version) }
    });
    return requestDto(updated);
  });
}

async function readPartAvailability(client, itemId) {
  const { rows } = await client.query(
    `SELECT i.id, COALESCE(SUM(CASE WHEN l.id IS NOT NULL AND w.id IS NOT NULL THEN b.on_hand - b.reserved ELSE 0 END),0) AS available, i.code, i.name, i.unit
     FROM items i LEFT JOIN item_balances b ON b.item_id=i.id
     LEFT JOIN storage_locations l ON l.id=b.location_id AND l.deleted_at IS NULL
     LEFT JOIN warehouses w ON w.id=l.warehouse_id AND w.deleted_at IS NULL AND w.active=true
     WHERE i.id=$1 AND i.deleted_at IS NULL
     GROUP BY i.id`, [itemId]
  );
  return rows[0] || null;
}

async function normalizeRequiredParts(client, value, { allowShortage = false } = {}) {
  if (!Array.isArray(value)) {
    if (allowShortage) throw coded(422, 'PM_ACTIVITY_FIELDS_INVALID');
    return [];
  }
  if (value.length > 50) throw coded(422, 'TOO_MANY_REQUIRED_PARTS');
  const parts = [];
  const seen = new Set();
  for (const entry of value) {
    const itemId = String(entry && (entry.itemId || entry.item_id || entry.id) || '').trim();
    const qty = Number(entry && entry.qty);
    if (!itemId) throw coded(422, 'PART_NOT_FOUND');
    if (seen.has(itemId)) continue;
    if (!Number.isFinite(qty) || qty <= 0 || qty > 100000 || (allowShortage && qty < 0.001)) throw coded(422, 'INVALID_PART_QUANTITY');
    const row = await readPartAvailability(client, itemId);
    if (!row) throw coded(422, 'PART_NOT_FOUND');
    if (!allowShortage && Number(row.available) < qty) throw coded(409, 'INSUFFICIENT_AVAILABLE_STOCK');
    parts.push({ itemId, qty:Math.round(qty * 1000) / 1000,
      ...(allowShortage ? { code:row.code, name:row.name, unit:row.unit } : {}) });
    seen.add(itemId);
  }
  return parts;
}

function textList(value, maxItems = 20) {
  if (Array.isArray(value)) return value.map(item => String(item || '').trim()).filter(Boolean).slice(0, maxItems);
  return String(value || '').split(/[\n،,;]/).map(item => item.trim()).filter(Boolean).slice(0, maxItems);
}

function workOrderInput(input = {}, request = null) {
  const requestForm = request ? asObject(request.form) : {};
  const ptw = input.ptwRequired !== undefined ? input.ptwRequired === true
    : input.ptw !== undefined ? input.ptw === true
      : requestForm.ptwRequired === true || requestForm.ptw === true;
  return {
    type:input.workOrderType || input.type || (request ? (request.type === 'fab' ? 'FAB' : request.type === 'service' ? 'SRV' : request.urgency === 'critical' ? 'BD' : 'CM') : 'CM'),
    assetId:input.assetId === undefined && request ? request.asset_id : input.assetId || null,
    descr:String(input.descr || (request && request.descr) || '').trim(),
    priority:input.priority || (request && request.urgency) || 'normal',
    assignee:input.assignee || null,
    est:input.est,
    failureType:input.failureType || requestForm.failureType || null,
    probableCauses:textList(input.probableCauses ?? input.probableCause ?? requestForm.probableCause),
    confirmedRootCause:String(input.confirmedRootCause || '').trim() || null,
    recommendedAction:String(input.recommendedAction || '').trim() || null,
    performedAction:String(input.performedAction || '').trim() || null,
    requiredParts:Array.isArray(input.requiredParts) ? input.requiredParts : [],
    ptw,
    permitId:input.permitId || null
  };
}

async function createWorkOrderInTransaction(client, user, input, requestId = null) {
  const fields = workOrderInput(input);
  if (!fields.descr) throw coded(422, 'DESCRIPTION_REQUIRED');
  const assetId = fields.assetId || null;
  await requireEquipment(client, assetId, false);
  const assignee = await requireUser(client, fields.assignee);
  const requiredParts = await normalizeRequiredParts(client, fields.requiredParts);
  const id = crypto.randomUUID();
  const no = await nextNumber(client, 'work_order', 'WO');
  const status = assignee ? 'assigned' : 'open';
  const permitStatus = fields.ptw ? 'pending_issuance' : 'not_required';
  if (fields.permitId) throw coded(422, 'PERMIT_MUST_BE_LINKED_AFTER_WORK_ORDER_CREATION');
  const { rows } = await client.query(
    `INSERT INTO work_orders(id,no,type,asset_id,descr,priority,assignee,status,req_id,pm_id,ptw,times,parts,report,est,
       failure_type,probable_causes,confirmed_root_cause,recommended_action,performed_action,required_parts,permit_status)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,'{}'::jsonb,'[]'::jsonb,'{}'::jsonb,$12,$13,$14,$15,$16,$17,$18,$19) RETURNING *`,
    [id, no, fields.type, assetId, fields.descr, fields.priority, assignee, status,
      requestId, input.pmId || null, fields.ptw, Number(fields.est) > 0 ? Number(fields.est) : null,
      fields.failureType, JSON.stringify(fields.probableCauses), fields.confirmedRootCause, fields.recommendedAction,
      fields.performedAction, JSON.stringify(requiredParts), permitStatus]
  );
  await linkWorkOrderAsset(client, id, assetId);
  await audit(client, user, 'create', 'work_order', id, null, rows[0], requestId ? `صدور از درخواست ${requestId}` : 'صدور دستورکار');
  await publish(client, user, {
    type: 'work_order.created', aggregateType: 'work_order', aggregateId: id, permission: 'work_order.view',
    equipmentId: assetId, payload: { id, no, status, assetId, requestId }
  });
  return workOrderDto(rows[0]);
}

async function createWorkOrder(pool, user, input) {
  return withTransaction(pool, client => createWorkOrderInTransaction(client, user, input, input.requestId || null));
}

async function approveRequestInTransaction(client, user, id, input) {
  const rowVersion = versionOf(input.rowVersion);
  const current = await lockRow(client, 'requests', id);
  if (!['new', 'review'].includes(current.status)) throw coded(409, 'RECORD_LOCKED');
  if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
  const request = current;
  const fields = workOrderInput(input, request);
  const assignee = await requireUser(client, fields.assignee);
  const assetId = fields.assetId || null;
  await requireEquipment(client, assetId, false);
  const requiredParts = await normalizeRequiredParts(client, fields.requiredParts);
  const workOrderId = crypto.randomUUID();
  const workOrderNo = await nextNumber(client, 'work_order', 'WO');
  const note = String(input.note || '').trim().slice(0, 1000);
  const descr = fields.descr + (note ? `\nیادداشت: ${note}` : '');
  const status = assignee ? 'assigned' : 'open';
  const permitStatus = fields.ptw ? 'pending_issuance' : 'not_required';
  if (fields.permitId) throw coded(422, 'PERMIT_MUST_BE_LINKED_AFTER_WORK_ORDER_CREATION');
  const { rows:createdRows } = await client.query(
    `INSERT INTO work_orders(id,no,type,asset_id,descr,priority,assignee,status,req_id,ptw,times,parts,report,est,
       failure_type,probable_causes,confirmed_root_cause,recommended_action,performed_action,required_parts,permit_status)
     VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,'{}'::jsonb,'[]'::jsonb,'{}'::jsonb,$11,$12,$13,$14,$15,$16,$17,$18) RETURNING *`,
    [workOrderId, workOrderNo, fields.type, assetId, descr, fields.priority, assignee, status, request.id, fields.ptw,
      Number(fields.est) > 0 ? Number(fields.est) : null, fields.failureType, JSON.stringify(fields.probableCauses),
      fields.confirmedRootCause, fields.recommendedAction, fields.performedAction, JSON.stringify(requiredParts), permitStatus]
  );
  await linkWorkOrderAsset(client, workOrderId, assetId);
  const pmSourceWorkOrderId = asObject(request.form).pmSourceWorkOrderId;
  if (pmSourceWorkOrderId && assetId === request.asset_id) {
    const { rows:[source] } = await client.query(
      `SELECT report->>'pmTargetNodeId' AS target_id FROM work_orders
       WHERE id=$1 AND asset_id=$2 AND occurrence_id IS NOT NULL AND report->>'pmFollowUpRequestId'=$3`,
      [pmSourceWorkOrderId, assetId, request.id]
    );
    if (source?.target_id) await client.query(
      `INSERT INTO work_order_assets(work_order_id,asset_id,relation_type,is_confirmed)
       SELECT $1,id,'related',true FROM assets WHERE id=$2 ON CONFLICT DO NOTHING`, [workOrderId, source.target_id]
    );
  }

  const updated = await writeUpdate(client, 'requests', id, rowVersion, user.id, {
    status:'wo', work_order_id:workOrderId, approved_at:new Date().toISOString(),
    history:JSON.stringify(appendHistory(current.history, `تأیید و صدور دستورکار ${workOrderNo} توسط ${user.name || user.username}`))
  });
  await audit(client, user, 'approve', 'request', id, current, updated, workOrderNo);
  await audit(client, user, 'create', 'work_order', workOrderId, null, createdRows[0], `صدور از ${current.no}`);
  await publish(client, user, {
    type:'request.approved', aggregateType:'request', aggregateId:id, permission:'request.view',
    equipmentId:assetId, payload:{ id, status:'wo', assetId, workOrderId, rowVersion:Number(updated.row_version) }
  });
  await publish(client, user, {
    type:'work_order.created', aggregateType:'work_order', aggregateId:workOrderId, permission:'work_order.view',
    equipmentId:assetId, payload:{ id:workOrderId, no:workOrderNo, status, assetId, requestId:id }
  });
  return { request:requestDto(updated), workOrder:workOrderDto(createdRows[0]) };
}

async function approveRequest(pool, user, id, input) {
  return withTransaction(pool, client => approveRequestInTransaction(client, user, id, input));
}

async function archiveRequest(pool, user, id, input) {
  const rowVersion = versionOf(input.rowVersion);
  const reason = reasonOf(input.reason, 'ARCHIVE_REASON_REQUIRED');
  return withTransaction(pool, async client => {
    const current = await lockRow(client, 'requests', id);
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    const linked = await client.query(
      'SELECT count(*)::int AS linked FROM work_orders WHERE req_id=$1 AND deleted_at IS NULL',
      [id]
    );
    if (linked.rows[0].linked) throw coded(409, 'REQUEST_HAS_WORK_ORDER');
    const { rows } = await client.query(
      `UPDATE requests SET deleted_at=now(), updated_at=now(), updated_by=$3, row_version=row_version+1, cancel_reason=$4
       WHERE id=$1 AND row_version=$2 AND deleted_at IS NULL RETURNING *`,
      [id, rowVersion, user.id, reason]
    );
    if (!rows[0]) throw coded(409, 'VERSION_CONFLICT');
    await audit(client, user, 'archive', 'request', id, current, rows[0], reason);
    await publish(client, user, {
      type: 'request.archived', aggregateType: 'request', aggregateId: id, permission: 'request.view',
      equipmentId: current.asset_id, payload: { id, archived: true, assetId: current.asset_id }
    });
    return { archived: true, historyPreserved: true };
  });
}


function normalizeMatch(value) {
  return String(value || '').normalize('NFKC').trim().toLocaleLowerCase('fa').replace(/[\u064B-\u065F\u0670]/g, '').replace(/[\s\u200c_-]+/g, ' ');
}

async function technicianSuggestions(pool, user, equipmentId, workOrderType = '') {
  if (!equipmentId) throw coded(422, 'EQUIPMENT_REQUIRED');
  const { rows:assets } = await pool.query(
    `SELECT a.id,a.code,a.name,a.cls,a.type,a.ext,c.factory_asset_id
     FROM assets a LEFT JOIN asset_categories c ON c.id=a.category_id
     WHERE a.id=$1 AND a.deleted_at IS NULL`, [equipmentId]
  );
  const asset = assets[0];
  if (!asset) throw coded(422, 'EQUIPMENT_NOT_FOUND');
  if (user && user.role !== 'admin') {
    const { rows:scopes } = await pool.query(
      `SELECT 1 FROM user_scopes WHERE user_id=$1 AND (
        (scope_type='equipment' AND scope_id=$2) OR
        (scope_type='factory' AND scope_id=$3) OR scope_type='company') LIMIT 1`,
      [user.id,asset.id,asset.factory_asset_id]
    );
    if (!scopes[0]) throw coded(403, 'EQUIPMENT_SCOPE_DENIED');
  }
  const { rows:users } = await pool.query(
    `SELECT u.id,u.name,u.hr,
       (SELECT count(*)::int FROM work_orders w WHERE w.assignee=u.id AND w.deleted_at IS NULL
         AND w.status IN ('open','assigned','seen','doing','hold')) AS active_load,
       COALESCE((SELECT jsonb_agg(jsonb_build_object('scope_type',s.scope_type,'scope_id',s.scope_id))
         FROM user_scopes s WHERE s.user_id=u.id),'[]'::jsonb) AS scopes
     FROM users u WHERE u.active=true AND u.role='tech'`
  );
  const assetTerms = [asset.cls, asset.ext && (asset.ext.maintenanceDomain || asset.ext.specialty), asset.type]
    .map(normalizeMatch).filter(Boolean);
  const wantedType = normalizeMatch(workOrderType);
  const candidates = users.flatMap(row => {
    const hr = asObject(row.hr);
    const specialty = normalizeMatch(hr.specialty);
    const authorizations = [].concat(hr.authorizations || hr.workAuthorizations || hr.licenses || hr.certifications || [])
      .map(normalizeMatch).filter(Boolean);
    const onDuty = hr.onDuty === true || hr.shiftOnDuty === true || asObject(hr.shift).onDuty === true;
    const scoped = asArray(row.scopes).some(scope => scope && (
      (scope.scope_type === 'equipment' && scope.scope_id === asset.id)
      || (asset.factory_asset_id && scope.scope_type === 'factory' && scope.scope_id === asset.factory_asset_id)
    ));
    const specialtyMatch = !!specialty && assetTerms.some(term => term === specialty || term.includes(specialty) || specialty.includes(term));
    const authorized = authorizations.some(item => item === '*' || item === wantedType || (!wantedType && item));
    if (!specialtyMatch || !authorized || !onDuty || !scoped) return [];
    return [{ id:row.id, name:row.name, specialty:hr.specialty, activeWorkOrders:Number(row.active_load) || 0 }];
  }).sort((a,b) => a.activeWorkOrders - b.activeWorkOrders || a.name.localeCompare(b.name,'fa'));
  return {
    data:candidates,
    message:candidates.length ? null : 'داده کافی برای پیشنهاد تکنسین وجود ندارد',
    evaluated:{ equipmentId:asset.id, workOrderType:workOrderType || null, source:'users.hr, user_scopes, active work_orders' }
  };
}

async function listWorkOrders(pool, filters = {}) {
  const { rows } = await pool.query(
    `SELECT w.*, a.id AS equipment_id, a.code AS equipment_code, a.name AS equipment_name
     FROM work_orders w LEFT JOIN assets a ON a.id=w.asset_id
     WHERE w.deleted_at IS NULL AND ($1::text IS NULL OR w.asset_id=$1)
     ORDER BY w.created_at DESC LIMIT 500`,
    [filters.assetId || null]
  );
  return rows.map(workOrderDto);
}

async function getWorkOrder(pool, id) {
  const { rows } = await pool.query(
    `SELECT w.*, a.id AS equipment_id, a.code AS equipment_code, a.name AS equipment_name
     FROM work_orders w LEFT JOIN assets a ON a.id=w.asset_id
     WHERE w.id=$1 AND w.deleted_at IS NULL`,
    [id]
  );
  if (!rows[0]) throw coded(404, 'RECORD_NOT_FOUND');
  return workOrderDto(rows[0]);
}

async function issuedPermit(client, permitId, workOrderId) {
  if (!permitId) return null;
  const { rows } = await client.query(
    'SELECT * FROM permits WHERE id=$1 AND wo_id=$2 FOR UPDATE', [String(permitId), workOrderId]
  );
  if (!rows[0]) throw coded(422, 'WORK_PERMIT_NOT_LINKED');
  return rows[0];
}

function permitIsIssued(permit, now = Date.now()) {
  if (!permit || permit.status !== 'active' || !permit.approved_at) return false;
  const startsAt = permit.from_at ? Date.parse(permit.from_at) : null;
  const expiresAt = permit.to_at ? Date.parse(permit.to_at) : null;
  if (startsAt != null && (!Number.isFinite(startsAt) || startsAt > now)) return false;
  if (expiresAt != null && (!Number.isFinite(expiresAt) || expiresAt < now)) return false;
  return true;
}

async function updateWorkOrder(pool, user, id, input) {
  const rowVersion = versionOf(input.rowVersion);
  return withTransaction(pool, async client => {
    const current = await lockRow(client, 'work_orders', id);
    if (LOCKED_WORK_ORDER.has(current.status)) throw coded(409, 'RECORD_LOCKED');
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    const assetId = input.assetId === undefined ? current.asset_id : (input.assetId || null);
    await requireEquipment(client, assetId, false);
    const assignee = input.assignee === undefined ? current.assignee : await requireUser(client, input.assignee || null);
    const descr = String(input.descr ?? current.descr ?? '').trim();
    if (!descr) throw coded(422, 'DESCRIPTION_REQUIRED');
    let status = current.status;
    if (current.status === 'open' && assignee) status = 'assigned';
    const requiredParts = input.requiredParts === undefined ? asArray(current.required_parts) : await normalizeRequiredParts(client, input.requiredParts);
  let ptw = input.ptwRequired === undefined && input.ptw === undefined ? current.ptw === true : (input.ptwRequired === true || input.ptw === true);
  if (current.ptw === true && !ptw) throw coded(409, 'PTW_REQUIREMENT_CANNOT_BE_REMOVED');
  let ptwId = current.ptw_id || null;
    let permitStatus = ptw ? (current.ptw === true && current.permit_status && current.permit_status !== 'not_required' ? current.permit_status : 'pending_issuance') : 'not_required';
    if (input.permitId !== undefined) {
      if (!ptw) throw coded(422, 'PERMIT_NOT_REQUIRED');
      const permit = await issuedPermit(client, input.permitId, id);
      ptwId = permit.id;
      permitStatus = permitIsIssued(permit) ? 'issued' : 'pending_issuance';
    } else if (!ptw) {
      ptwId = null;
    }
    const probableCauses = input.probableCauses === undefined && input.probableCause === undefined
      ? asArray(current.probable_causes)
      : textList(input.probableCauses ?? input.probableCause);
    const updated = await writeUpdate(client, 'work_orders', id, rowVersion, user.id, {
      type:input.workOrderType || input.type || current.type,
      asset_id:assetId,
      descr,
      priority:input.priority || current.priority,
      assignee,
      status,
      ptw,
      ptw_id:ptwId,
      permit_status:permitStatus,
      failure_type:input.failureType === undefined ? current.failure_type : (String(input.failureType || '').trim() || null),
      probable_causes:JSON.stringify(probableCauses),
      confirmed_root_cause:input.confirmedRootCause === undefined ? current.confirmed_root_cause : (String(input.confirmedRootCause || '').trim() || null),
      recommended_action:input.recommendedAction === undefined ? current.recommended_action : (String(input.recommendedAction || '').trim() || null),
      performed_action:input.performedAction === undefined ? current.performed_action : (String(input.performedAction || '').trim() || null),
      required_parts:JSON.stringify(requiredParts),
      est:input.est === undefined ? current.est : Number(input.est) > 0 ? Number(input.est) : null
    });
    await linkWorkOrderAsset(client, id, assetId);
    await audit(client, user, 'edit', 'work_order', id, current, updated, 'ویرایش دستورکار');
    await publish(client, user, {
      type:'work_order.updated', aggregateType:'work_order', aggregateId:id, permission:'work_order.view',
      equipmentId:assetId, payload:{ id, no:updated.no, status:updated.status, assetId, rowVersion:Number(updated.row_version) }
    });
    return workOrderDto(updated);
  });
}

async function linkWorkOrderPermit(pool, user, id, input) {
  const rowVersion = versionOf(input.rowVersion);
  return withTransaction(pool, async client => {
    const current = await lockRow(client, 'work_orders', id);
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    if (LOCKED_WORK_ORDER.has(current.status)) throw coded(409, 'RECORD_LOCKED');
    if (current.ptw !== true) throw coded(422, 'PERMIT_NOT_REQUIRED');
    const permit = await issuedPermit(client, input.permitId, id);
    const updated = await writeUpdate(client, 'work_orders', id, rowVersion, user.id, {
      ptw_id:permit.id,
      permit_status:permitIsIssued(permit) ? 'issued' : 'pending_issuance'
    });
    await audit(client, user, 'link-permit', 'work_order', id, current, updated, permit.no || permit.id);
    await publish(client, user, {
      type:'work_order.permit_linked', aggregateType:'work_order', aggregateId:id, permission:'work_order.view',
      equipmentId:current.asset_id, payload:{ id, permitId:permit.id, permitStatus:updated.permit_status, rowVersion:Number(updated.row_version) }
    });
    return workOrderDto(updated);
  });
}

async function transitionWorkOrder(pool, user, id, input) {
  const rowVersion = versionOf(input.rowVersion);
  const status = String(input.status || '');
  return withPmTransaction(pool, async client => {
    const current = await lockRow(client, 'work_orders', id);
    const currentVersion = Number(current.row_version);
    const samePmRetry = current.occurrence_id && current.status === status && ['doing','done'].includes(status);
    if (samePmRetry && currentVersion >= rowVersion && currentVersion - rowVersion <= 1) {
      const context = await lockPmWorkOrderContext(client, current);
      if (status === 'doing') assertPmStartConsistency(current, context.occurrence);
      else assertPmCompletionConsistency(current, context);
      return workOrderDto(current);
    }
    if (currentVersion !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    assertTransition(WORK_ORDER_FLOW, current.status, status);

    let permitStatus = current.permit_status || (current.ptw ? 'pending_issuance' : 'not_required');
    if (status === 'doing' && current.ptw === true) {
      if (!current.ptw_id) throw coded(409, 'WORK_PERMIT_REQUIRED');
      const permit = await issuedPermit(client, current.ptw_id, id);
      if (!permitIsIssued(permit)) throw coded(409, 'WORK_PERMIT_REQUIRED');
      permitStatus = 'issued';
    }

    const existingStart = Boolean(asObject(current.times).start);
    const times = asObject(current.times);
    const report = asObject(current.report);
    const transitionAt = ['doing','done'].includes(status) ? new Date().toISOString() : null;
    if (status === 'seen' && !times.seen) times.seen = transitionAt || new Date().toISOString();
    if (status === 'doing' && !times.start) times.start = transitionAt;
    if (status === 'hold') current.hold_reason = reasonOf(input.reason, 'HOLD_REASON_REQUIRED');
    if (status === 'done') {
      const text = String(input.report?.text || '').trim();
      if (!text) throw coded(422, 'REPORT_REQUIRED');
      if (current.occurrence_id && times.end) throw coded(409, 'WORK_ORDER_COMPLETION_INCONSISTENT');
      times.end = transitionAt;
      const template = asArray(report.pmChecklist);
      if (template.length) {
        report.pmChecklistResults = pmPlanning.completionResults(template, input.report.pmChecklistResults);
        const photos = [...new Set(report.pmChecklistResults.map(item => item.photoId).filter(Boolean))];
        if (photos.length) {
          const {rows} = await client.query(
            `SELECT id FROM work_order_files WHERE work_order_id=$1 AND id=ANY($2::uuid[])
             AND deleted_at IS NULL AND media_type LIKE 'image/%'`, [current.id, photos]
          );
          if (rows.length !== photos.length) throw coded(422, 'PM_CHECKLIST_PHOTO_REQUIRED');
        }
      }
      report.text = text;
      report.cause = input.report.cause || null;
      current.performed_action = text;
      report.by = user.id;
      report.at = transitionAt;
    }
    if (status === 'closed' && !hasExecutionHistory({ ...current, times, report })) throw coded(409, 'WORK_ORDER_NOT_EXECUTED');

    let pmContext = null;
    if (current.occurrence_id && ['doing','done','closed'].includes(status)) {
      pmContext = await lockPmWorkOrderContext(client, current);
      const occurrence = pmContext.occurrence;
      if (status === 'doing') {
        if (PM_OCCURRENCE_FINAL_STATES.has(occurrence.status)) throw coded(409, 'PM_OCCURRENCE_NOT_STARTABLE');
        if (occurrence.status === 'work_order_generated') {
          if (occurrence.started_at || existingStart) throw coded(409, 'PM_START_INCONSISTENT');
        } else if (occurrence.status === 'in_progress') {
          if (current.status !== 'hold') throw coded(409, 'PM_START_INCONSISTENT');
          assertPmStartConsistency(current, occurrence);
        } else {
          throw coded(409, 'PM_OCCURRENCE_NOT_STARTABLE');
        }
      } else if (status === 'done') {
        if (occurrence.status === 'completed' || PM_OCCURRENCE_FINAL_STATES.has(occurrence.status)) {
          throw coded(409, 'PM_OCCURRENCE_ALREADY_FINAL');
        }
        if (occurrence.status !== 'in_progress') throw coded(409, 'PM_OCCURRENCE_NOT_IN_PROGRESS');
        assertPmStartConsistency(current, occurrence);
      } else {
        assertPmCompletionConsistency(current, pmContext);
        report.pmSupervisorApproval = {userId:user.id,name:user.name||user.username,at:new Date().toISOString()};
      }
    }

    if (status === 'done' && input.report?.createDefectRequest === true) {
      const defective = asArray(report.pmChecklistResults).flatMap((result, index) =>
        result.status === 'defective' ? [{ title:report.pmChecklist[index].title, notes:result.notes }] : []);
      if (!pmContext || !defective.length) throw coded(422, 'PM_DEFECT_REQUIRED');
      await assertEquipmentScope(client, user, current.asset_id);
      const request = await createRequestInTransaction(client, user, {
        assetId:current.asset_id, type:'repair',
        descr:`پیگیری عیب از دستورکار PM ${current.no}: ${defective.map(item => item.title + ' — ' + item.notes).join('؛ ').slice(0,6000)}`,
        form:{ pmSourceWorkOrderId:current.id, pmPlanId:current.pm_id, targetNodeId:report.pmTargetNodeId || null }
      });
      report.pmFollowUpRequestId = request.id;
    }

    const updated = await writeUpdate(client, 'work_orders', id, rowVersion, user.id, {
      status,
      times: JSON.stringify(times),
      report: JSON.stringify(report),
      performed_action: current.performed_action,
      permit_status: permitStatus,
      hold_reason: current.hold_reason
    });

    let updatedOccurrence = null;
    let updatedPlan = null;
    if (status === 'doing' && pmContext?.occurrence.status === 'work_order_generated') {
      const { rows } = await client.query(
        `UPDATE pm_occurrences SET status='in_progress',started_at=$3,updated_at=now(),updated_by=$4,row_version=row_version+1
         WHERE id=$1 AND row_version=$2 AND status='work_order_generated' RETURNING *`,
        [pmContext.occurrence.id, Number(pmContext.occurrence.row_version), transitionAt, user.id]
      );
      if (!rows[0]) throw coded(409, 'VERSION_CONFLICT');
      updatedOccurrence = rows[0];
      await audit(client, user, 'start', 'pm_occurrence', updatedOccurrence.id, pmContext.occurrence, updatedOccurrence, 'شروع دستورکار');
      await publish(client, user, {
        type:'pm_occurrence.started', aggregateType:'pm_occurrence', aggregateId:updatedOccurrence.id, permission:'pm.view',
        equipmentId:updatedOccurrence.equipment_id, payload:{ id:updatedOccurrence.id, pmPlanId:updatedOccurrence.pm_plan_id,
          workOrderId:id, status:updatedOccurrence.status, startedAt:updatedOccurrence.started_at }
      });
    }

    if (status === 'done' && pmContext) {
      const completionAt = parsePmTimestamp(asObject(updated.times).end, 'WORK_ORDER_COMPLETION_INCONSISTENT');
      if (!completionAt) throw coded(409, 'WORK_ORDER_COMPLETION_INCONSISTENT');
      const nextDue = calculatePmDue({
        schedule_basis:pmContext.plan.schedule_basis,
        interval_days:pmContext.plan.interval_days,
        last_completed_at:completionAt,
        next_due_at:null,
        tolerance_days:pmContext.plan.tolerance_days, ext:pmContext.plan.ext
      }, completionAt);
      const { rows:occurrenceRows } = await client.query(
        `UPDATE pm_occurrences SET status='completed',completed_at=$3,completion_source='work_order',
           updated_at=now(),updated_by=$4,row_version=row_version+1
         WHERE id=$1 AND row_version=$2 AND status='in_progress' RETURNING *`,
        [pmContext.occurrence.id, Number(pmContext.occurrence.row_version), completionAt, user.id]
      );
      if (!occurrenceRows[0]) throw coded(409, 'VERSION_CONFLICT');
      updatedOccurrence = occurrenceRows[0];
      const { rows:planRows } = await client.query(
        `UPDATE pm_plans SET last_completed_at=$3,next_due_at=$4,updated_at=now(),updated_by=$5,row_version=row_version+1
         WHERE id=$1 AND row_version=$2 AND deleted_at IS NULL RETURNING *`,
        [pmContext.plan.id, Number(pmContext.plan.row_version), completionAt, nextDue.nextDueAt, user.id]
      );
      if (!planRows[0]) throw coded(409, 'VERSION_CONFLICT');
      updatedPlan = planRows[0];
      await audit(client, user, 'complete', 'pm_occurrence', updatedOccurrence.id, pmContext.occurrence, updatedOccurrence, 'تکمیل مستند Work Order');
      await audit(client, user, 'complete', 'pm_plan', updatedPlan.id, pmContext.plan, updatedPlan, id);
      await publish(client, user, {
        type:'pm_occurrence.completed', aggregateType:'pm_occurrence', aggregateId:updatedOccurrence.id, permission:'pm.view',
        equipmentId:updatedOccurrence.equipment_id, payload:{ id:updatedOccurrence.id, pmPlanId:updatedOccurrence.pm_plan_id,
          workOrderId:id, status:updatedOccurrence.status, completedAt:updatedOccurrence.completed_at,
          completionSource:updatedOccurrence.completion_source, nextDueAt:updatedPlan.next_due_at }
      });
    }

    await audit(client, user, 'transition', 'work_order', id, current, updated, status);
    await publish(client, user, {
      type:'work_order.transitioned', aggregateType:'work_order', aggregateId:id, permission:'work_order.view',
      equipmentId:current.asset_id, payload:{ id, status, assetId:current.asset_id, rowVersion:Number(updated.row_version) }
    });
    return workOrderDto(updated);
  });
}

async function archiveWorkOrder(pool, user, id, input) {
  const rowVersion = versionOf(input.rowVersion);
  const reason = reasonOf(input.reason, 'ARCHIVE_REASON_REQUIRED');
  return withTransaction(pool, async client => {
    const current = await lockRow(client, 'work_orders', id);
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    if (hasExecutionHistory(current)) throw coded(409, 'EXECUTED_WORK_ORDER_CANNOT_BE_ARCHIVED');
    const consumed = await client.query('SELECT 1 FROM work_order_parts WHERE work_order_id=$1 LIMIT 1', [id]);
    if (consumed.rows[0]) throw coded(409, 'EXECUTED_WORK_ORDER_CANNOT_BE_ARCHIVED');
    const { rows } = await client.query(
      `UPDATE work_orders SET deleted_at=now(), updated_at=now(), updated_by=$3, row_version=row_version+1
       WHERE id=$1 AND row_version=$2 AND deleted_at IS NULL RETURNING *`,
      [id, rowVersion, user.id]
    );
    if (!rows[0]) throw coded(409, 'VERSION_CONFLICT');
    await audit(client, user, 'archive', 'work_order', id, current, rows[0], reason);
    await publish(client, user, {
      type: 'work_order.archived', aggregateType: 'work_order', aggregateId: id, permission: 'work_order.view',
      equipmentId: current.asset_id, payload: { id, archived: true, assetId: current.asset_id }
    });
    return { archived: true, historyPreserved: true };
  });
}

async function cancelWorkOrder(pool, user, id, input) {
  const rowVersion = versionOf(input.rowVersion);
  const reason = reasonOf(input.reason, 'CANCEL_REASON_REQUIRED');
  return withTransaction(pool, async client => {
    const current = await lockRow(client, 'work_orders', id);
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    if (!CANCELLABLE_WORK_ORDER.has(current.status)) throw coded(409, 'RECORD_LOCKED');
    const updated = await writeUpdate(client, 'work_orders', id, rowVersion, user.id, {
      status: 'cancel',
      cancel_reason: reason,
      cancelled_at: new Date().toISOString(),
      cancelled_by: user.id
    });
    await audit(client, user, 'cancel', 'work_order', id, current, updated, reason);
    await publish(client, user, {
      type: 'work_order.cancelled', aggregateType: 'work_order', aggregateId: id, permission: 'work_order.view',
      equipmentId: current.asset_id, payload: { id, status: 'cancel', assetId: current.asset_id, historyPreserved: true }
    });
    return workOrderDto(updated);
  });
}

async function correctRecord(pool, user, kind, id, input) {
  const rowVersion = versionOf(input.rowVersion);
  const reason = reasonOf(input.reason, 'CORRECTION_REASON_REQUIRED');
  const table = kind === 'request' ? 'requests' : kind === 'work_order' ? 'work_orders' : 'pm_plans';
  const allowed = kind === 'request'
    ? { descr: 'descr', urgency: 'urgency', assetId: 'asset_id' }
    : kind === 'work_order'
      ? { descr: 'descr', priority: 'priority', est: 'est' }
      : { title: 'title', interval: 'interval_days', spec: 'spec' };
  return withTransaction(pool, async client => {
    const current = await lockRow(client, table, id);
    if (kind === 'pm_plan') await assertEquipmentScope(client, user, current.asset_id);
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    const patch = {};
    for (const [key, column] of Object.entries(allowed)) {
      if (input.patch && input.patch[key] !== undefined) patch[column] = key === 'est' || key === 'interval' ? Number(input.patch[key]) : input.patch[key];
    }
    if (patch.asset_id) await requireEquipment(client, patch.asset_id, false);
    if (!Object.keys(patch).length) throw coded(422, 'NO_EDITABLE_FIELDS');
    if (patch.descr !== undefined && !String(patch.descr).trim()) throw coded(422, 'DESCRIPTION_REQUIRED');
    const updated = await writeUpdate(client, table, id, rowVersion, user.id, patch);
    if (updated.status !== current.status) throw coded(409, 'RECORD_LOCKED');
    await client.query(
      `INSERT INTO maintenance_corrections(id,entity_type,entity_id,reason,patch,previous_row_version,created_by)
       VALUES($1,$2,$3,$4,$5,$6,$7)`,
      [crypto.randomUUID(), kind, id, reason, JSON.stringify(patch), rowVersion, user.id]
    );
    await audit(client, user, 'correct', kind, id, current, updated, reason);
    await publish(client, user, {
      type: `${kind}.corrected`, aggregateType: kind, aggregateId: id,
      permission: kind === 'work_order' ? 'work_order.view' : kind === 'request' ? 'request.view' : 'pm.view',
      equipmentId: updated.asset_id, payload: { id, rowVersion: Number(updated.row_version), assetId: updated.asset_id }
    });
    return kind === 'request' ? requestDto(updated) : kind === 'work_order' ? workOrderDto(updated) : pmDto(updated);
  });
}

async function createPmPlan(pool, user, input) {
  const title = String(input.title || '').trim();
  if (!title) throw coded(422, 'TITLE_REQUIRED');
  const scheduleBasis = String(input.scheduleBasis ?? input.schedule_basis ?? 'calendar').trim().toLowerCase();
  if (scheduleBasis !== 'calendar') throw coded(422, 'PM_SCHEDULE_BASIS_UNSUPPORTED');
  const firstDueAt = parsePmTimestamp(input.firstDueAt ?? input.first_due_at, 'PM_FIRST_DUE_AT_INVALID');
  const suppliedNextDueAt = parsePmTimestamp(input.nextDueAt ?? input.next_due_at, 'PM_NEXT_DUE_AT_INVALID');
  const nextDueAt = suppliedNextDueAt || firstDueAt;
  const intervalDays = positiveInteger(input.intervalDays ?? input.interval, 'PM_INTERVAL_DAYS_INVALID') || 30;
  const toleranceDays = nonNegativeInteger(input.toleranceDays ?? input.tolerance_days, 'PM_TOLERANCE_DAYS_INVALID');
  return withPmTransaction(pool, async client => {
    const assetId = input.assetId || null;
    await assertEquipmentScope(client, user, assetId);
    const owner = await requireUser(client, input.owner || null);
    const fields = await pmPlanning.activityFields(client, assetId, input);
    if (Object.hasOwn(input, 'requiredParts')) fields.required_parts = JSON.stringify(await normalizeRequiredParts(client, input.requiredParts, { allowShortage:true }));
    const columns = Object.keys(fields);
    const extraColumns = columns.length ? ',' + columns.join(',') : '';
    const extraValues = columns.map((_, index) => ',$' + (13 + index)).join('');
    const id = crypto.randomUUID();
    const { rows } = await client.query(
      `INSERT INTO pm_plans(id,asset_id,title,interval_days,last_run,spec,owner,kind,checklist,status,
         schedule_basis,first_due_at,next_due_at,last_completed_at,tolerance_days${extraColumns})
       VALUES($1,$2,$3,$4,NULL,$5,$6,$7,$8,'active',$9,$10,$11,NULL,$12${extraValues}) RETURNING *`,
      [id, assetId, title, intervalDays, input.spec || null, owner, input.kind || 'PM', JSON.stringify(pmPlanning.checklist(input.checklist ?? [])),
        scheduleBasis, firstDueAt, nextDueAt, toleranceDays, ...Object.values(fields)]
    );
    await audit(client, user, 'create', 'pm_plan', id, null, rows[0], 'ثبت برنامه PM');
    await publish(client, user, {
      type: 'pm_plan.created', aggregateType: 'pm_plan', aggregateId: id, permission: 'pm.view',
      equipmentId: assetId, payload: { id, title, assetId, status: 'active' }
    });
    return pmDto(rows[0]);
  });
}

async function readScopedPmPlan(pool, user, id, includeArchived = false) {
  const { rows } = await pool.query(
    `SELECT p.*, a.id AS equipment_id, a.code AS equipment_code, a.name AS equipment_name, target.name AS target_name
     FROM pm_plans p LEFT JOIN assets a ON a.id=p.asset_id
     LEFT JOIN assets target ON target.id=p.ext->>'targetNodeId'
     WHERE p.id=$1 AND ($2::boolean OR (p.archived_at IS NULL AND p.deleted_at IS NULL))`,
    [id, includeArchived]
  );
  if (!rows[0]) throw coded(404, 'RECORD_NOT_FOUND');
  await assertEquipmentScope(pool, user, rows[0].asset_id);
  return rows[0];
}

async function pmPartsReadiness(pool, user, id) {
  const plan = await readScopedPmPlan(pool, user, id);
  return Promise.all(asArray(plan.required_parts).filter(part => part?.itemId).map(async part => {
    const row = await readPartAvailability(pool, part.itemId);
    const available = row ? Number(row.available) : null;
    return { ...part, available, shortage:available == null ? null : Math.max(0, part.qty - available) };
  }));
}

async function getPmDue(pool, user, id, input = {}, options = {}) {
  const evaluatedAt = input.evaluatedAt;
  if (evaluatedAt == null || evaluatedAt === '') throw coded(422, 'PM_EVALUATED_AT_REQUIRED');
  const plan = await readScopedPmPlan(pool, user, id, options.includeArchived === true);
  const due = calculatePmDue(plan, evaluatedAt);
  return { evaluatedAt:parsePmTimestamp(evaluatedAt, 'PM_EVALUATED_AT_INVALID'), ...due };
}

async function listPmOccurrences(pool, user, planId, options = {}) {
  const plan = await readScopedPmPlan(pool, user, planId, options.includeArchived === true);
  const { rows } = await pool.query(
    `SELECT o.*, w.id AS linked_work_order_id
     FROM pm_occurrences o LEFT JOIN work_orders w ON w.occurrence_id=o.id
     WHERE o.pm_plan_id=$1 ORDER BY o.due_at,o.created_at`,
    [planId]
  );
  if (rows.some(row => String(row.equipment_id) !== String(plan.asset_id))) throw coded(409, 'PM_OCCURRENCE_LINK_MISMATCH');
  return rows.map(row => occurrenceDto(row));
}

async function getPmOccurrence(pool, user, planId, occurrenceId, options = {}) {
  const { rows } = await pool.query(
    `SELECT o.*, p.asset_id AS plan_asset_id, w.id AS linked_work_order_id
     FROM pm_occurrences o JOIN pm_plans p ON p.id=o.pm_plan_id
     LEFT JOIN work_orders w ON w.occurrence_id=o.id
     WHERE o.id=$1 AND o.pm_plan_id=$2
       AND ($3::boolean OR (p.archived_at IS NULL AND p.deleted_at IS NULL))`,
    [occurrenceId, planId, options.includeArchived === true]
  );
  if (!rows[0]) throw coded(404, 'RECORD_NOT_FOUND');
  await assertEquipmentScope(pool, user, rows[0].plan_asset_id);
  if (String(rows[0].equipment_id) !== String(rows[0].plan_asset_id)) throw coded(409, 'PM_OCCURRENCE_LINK_MISMATCH');
  return occurrenceDto(rows[0]);
}

async function createPmOccurrence(pool, user, planId, input = {}) {
  const rowVersion = versionOf(input.rowVersion);
  const evaluatedAt = input.evaluatedAt;
  if (evaluatedAt == null || evaluatedAt === '') throw coded(422, 'PM_EVALUATED_AT_REQUIRED');
  const evaluationTime = parsePmTimestamp(evaluatedAt, 'PM_EVALUATED_AT_INVALID');
  const requestedPeriodKey = input.periodKey == null ? null : String(input.periodKey).trim();
  return withPmTransaction(pool, async client => {
    const { rows:plans } = await client.query('SELECT * FROM pm_plans WHERE id=$1 FOR UPDATE', [planId]);
    const current = plans[0];
    if (!current) throw coded(404, 'RECORD_NOT_FOUND');
    await assertEquipmentScope(client, user, current.asset_id);
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    if (current.deleted_at || current.archived_at || LOCKED_PM.has(current.status)) throw coded(409, 'RECORD_LOCKED');

    let existing = null;
    if (requestedPeriodKey) {
      const match = requestedPeriodKey.match(/^calendar:(\d{4}-\d{2}-\d{2})$/);
      if (!match || periodKeyForDueDate(match[1], current.schedule_basis) !== requestedPeriodKey) {
        throw coded(422, 'PM_PERIOD_KEY_INVALID');
      }
      existing = await findPmOccurrence(client, planId, requestedPeriodKey);
      if (existing) {
        if (String(existing.equipment_id) !== String(current.asset_id)) throw coded(409, 'PM_OCCURRENCE_LINK_MISMATCH');
        return { occurrence:occurrenceDto(existing), idempotentReplay:true };
      }
    }

    const due = calculatePmDue(current, evaluationTime);
    if (!due.nextDueAt || due.dueStatus === 'insufficient_data') {
      throw Object.assign(coded(422, 'PM_SCHEDULE_DATA_REQUIRED'), { reason:due.reason || 'due_date_unavailable' });
    }
    const periodKey = periodKeyForDueDate(due.nextDueAt, current.schedule_basis);
    if (requestedPeriodKey && requestedPeriodKey !== periodKey) throw coded(422, 'PM_PERIOD_KEY_MISMATCH');
    const occurrence = await findPmOccurrence(client, planId, periodKey);
    if (occurrence) {
      if (String(occurrence.equipment_id) !== String(current.asset_id)) throw coded(409, 'PM_OCCURRENCE_LINK_MISMATCH');
      return { occurrence:occurrenceDto(occurrence), idempotentReplay:true };
    }

    const id = crypto.randomUUID();
    const { rows:inserted } = await client.query(
      `INSERT INTO pm_occurrences(id,pm_plan_id,equipment_id,period_key,due_at,status,provenance_status,row_version,created_by,updated_by)
       VALUES($1,$2,$3,$4,$5,$6,'verified',1,$7,$7)
       ON CONFLICT(pm_plan_id,period_key) DO NOTHING RETURNING *`,
      [id, planId, current.asset_id, periodKey, due.nextDueAt, due.dueStatus, user.id]
    );
    const saved = inserted[0] || await findPmOccurrence(client, planId, periodKey);
    if (!saved) throw coded(409, 'PM_OCCURRENCE_CONFLICT');
    if (String(saved.equipment_id) !== String(current.asset_id)) throw coded(409, 'PM_OCCURRENCE_LINK_MISMATCH');
    if (inserted[0]) {
      await audit(client, user, 'schedule', 'pm_occurrence', saved.id, null, saved, periodKey);
      await publish(client, user, {
        type:'pm_occurrence.scheduled', aggregateType:'pm_occurrence', aggregateId:saved.id, permission:'pm.view',
        equipmentId:current.asset_id, payload:{ id:saved.id, pmPlanId:planId, periodKey, assetId:current.asset_id }
      });
    }
    return { occurrence:occurrenceDto(saved), idempotentReplay:!inserted[0] };
  });
}

async function updatePmOccurrenceDueStatus(pool, user, planId, occurrenceId, input = {}) {
  const rowVersion = versionOf(input.rowVersion);
  const evaluatedAt = input.evaluatedAt;
  if (evaluatedAt == null || evaluatedAt === '') throw coded(422, 'PM_EVALUATED_AT_REQUIRED');
  const evaluationTime = parsePmTimestamp(evaluatedAt, 'PM_EVALUATED_AT_INVALID');
  return withPmTransaction(pool, async client => {
    const { rows:refs } = await client.query('SELECT pm_plan_id FROM pm_occurrences WHERE id=$1', [occurrenceId]);
    if (!refs[0] || String(refs[0].pm_plan_id) !== String(planId)) throw coded(404, 'RECORD_NOT_FOUND');
    const { rows:plans } = await client.query('SELECT * FROM pm_plans WHERE id=$1 FOR UPDATE', [planId]);
    const plan = plans[0];
    if (!plan) throw coded(404, 'RECORD_NOT_FOUND');
    await assertEquipmentScope(client, user, plan.asset_id);
    if (plan.deleted_at || plan.archived_at || LOCKED_PM.has(plan.status)) throw coded(409, 'RECORD_LOCKED');
    const { rows:occurrences } = await client.query(
      'SELECT * FROM pm_occurrences WHERE id=$1 AND pm_plan_id=$2 FOR UPDATE', [occurrenceId, planId]
    );
    const current = occurrences[0];
    if (!current) throw coded(404, 'RECORD_NOT_FOUND');
    if (String(current.equipment_id) !== String(plan.asset_id)) throw coded(409, 'PM_OCCURRENCE_LINK_MISMATCH');
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    if (PM_OCCURRENCE_FINAL_STATES.has(current.status)) throw coded(409, 'PM_OCCURRENCE_FINAL');
    if (!['scheduled','due','overdue'].includes(current.status)) throw coded(409, 'PM_OCCURRENCE_STATUS_LOCKED');
    if (periodKeyForDueDate(current.due_at, plan.schedule_basis) !== current.period_key) throw coded(409, 'PM_PERIOD_KEY_MISMATCH');

    const due = calculatePmDue({
      schedule_basis:plan.schedule_basis, first_due_at:current.due_at,
      last_completed_at:null, next_due_at:null, tolerance_days:plan.tolerance_days
    }, evaluationTime);
    if (!due.nextDueAt || due.dueStatus === 'insufficient_data') {
      throw Object.assign(coded(422, 'PM_SCHEDULE_DATA_REQUIRED'), { reason:due.reason || 'due_date_unavailable' });
    }
    if (current.status === due.dueStatus) {
      return { occurrence:occurrenceDto(current), evaluatedAt:evaluationTime, idempotentReplay:true };
    }
    const { rows:updatedRows } = await client.query(
      `UPDATE pm_occurrences SET status=$3,updated_at=now(),updated_by=$4,row_version=row_version+1
       WHERE id=$1 AND row_version=$2 AND status IN ('scheduled','due','overdue') RETURNING *`,
      [occurrenceId, rowVersion, due.dueStatus, user.id]
    );
    const updated = updatedRows[0];
    if (!updated) throw coded(409, 'VERSION_CONFLICT');
    await audit(client, user, 'evaluate_due', 'pm_occurrence', occurrenceId, current, updated, evaluationTime);
    await publish(client, user, {
      type:'pm_occurrence.due_status_updated', aggregateType:'pm_occurrence', aggregateId:occurrenceId, permission:'pm.view',
      equipmentId:plan.asset_id, payload:{ id:occurrenceId, pmPlanId:planId, status:due.dueStatus, evaluatedAt:evaluationTime }
    });
    return { occurrence:occurrenceDto(updated), evaluatedAt:evaluationTime, idempotentReplay:false };
  });
}

async function reschedulePmPlan(pool, user, id, input) {
  const rowVersion = versionOf(input.rowVersion);
  const nextDueAt = parsePmTimestamp(input.nextDueAt, 'PM_NEXT_DUE_AT_INVALID');
  if (!nextDueAt) throw coded(422, 'PM_NEXT_DUE_AT_INVALID');
  const reason = reasonOf(input.reason, 'PM_RESCHEDULE_REASON_REQUIRED');
  return withPmTransaction(pool, async client => {
    const current = await lockRow(client, 'pm_plans', id);
    await assertEquipmentScope(client, user, current.asset_id);
    if (current.archived_at || LOCKED_PM.has(current.status)) throw coded(409, 'RECORD_LOCKED');
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    const newKey = periodKeyForDueDate(nextDueAt, current.schedule_basis);
    const previousDueAt = nextDueAtForPlan(current);
    if (previousDueAt === nextDueAt) return pmDto(current);
    if (current.last_completed_at && Date.parse(nextDueAt) <= Date.parse(current.last_completed_at)) {
      throw coded(422, 'PM_NEXT_DUE_BEFORE_COMPLETION');
    }
    const previous = previousDueAt && await findPmOccurrence(client, id, periodKeyForDueDate(previousDueAt));
    if (previous && (!['scheduled','due','overdue'].includes(previous.status) || previous.linked_work_order_id)) {
      throw coded(409, 'PM_RESCHEDULE_WORK_ORDER_EXISTS');
    }
    const existing = await findPmOccurrence(client, id, newKey);
    if (existing && existing.id !== previous?.id) throw coded(409, 'PM_OCCURRENCE_CONFLICT');
    const updated = await writeUpdate(client, 'pm_plans', id, rowVersion, user.id, { next_due_at: nextDueAt });
    if (previous) {
      const due = calculatePmDue(updated, new Date());
      const { rows } = await client.query(
        'UPDATE pm_occurrences SET due_at=$2,period_key=$3,status=$4,updated_at=now(),updated_by=$5,row_version=row_version+1 WHERE id=$1 RETURNING *',
        [previous.id, nextDueAt, newKey, due.dueStatus, user.id]
      );
      await audit(client, user, 'reschedule', 'pm_occurrence', previous.id, previous, rows[0], reason);
    }
    await audit(client, user, 'reschedule', 'pm_plan', id, current, updated, reason);
    await publish(client, user, {
      type:'pm_plan.updated', aggregateType:'pm_plan', aggregateId:id, permission:'pm.view',
      equipmentId:current.asset_id, payload:{ id, assetId:current.asset_id, nextDueAt }
    });
    return pmDto(updated);
  });
}

function summarizePmSchedule(rows, evaluatedAt) {
  const excluded = new Set(['cancelled', 'skipped']);
  const planned = rows.filter(row => !excluded.has(row.status));
  const completed = planned.filter(row => row.status === 'completed' && row.completedAt);
  const due = planned.filter(row => Date.parse(row.dueAt) <= evaluatedAt);
  const dueCompleted = due.filter(row => row.status === 'completed' && row.completedAt);
  const overdue = due.filter(row => row.status !== 'completed' && evaluatedAt > Date.parse(row.deadline));
  const onTime = completed.filter(row => Date.parse(row.completedAt) <= Date.parse(row.deadline));
  const sum = (items, key) => {
    const values = items.map(row => row[key]).filter(value => value != null);
    return values.length === items.length && values.length ? values.reduce((a,b) => a+b, 0) : null;
  };
  return {
    planned:planned.length, due:due.length, completed:completed.length, overdue:overdue.length,
    compliance:due.length ? dueCompleted.length / due.length : null,
    onTimeRate:completed.length ? onTime.length / completed.length : null,
    plannedMinutes:sum(planned,'plannedMinutes'), elapsedMinutes:sum(completed,'elapsedMinutes')
  };
}

async function pmScheduleReport(pool, user, filters = {}) {
  const from = parsePmTimestamp(filters.from, 'PM_REPORT_RANGE_INVALID');
  const to = parsePmTimestamp(filters.to, 'PM_REPORT_RANGE_INVALID');
  if (!from || !to || Date.parse(to) <= Date.parse(from) || Date.parse(to) - Date.parse(from) > 367 * 86400000) {
    throw coded(422, 'PM_REPORT_RANGE_INVALID');
  }
  const { rows } = await pool.query(
    `SELECT o.id,o.equipment_id,o.due_at,o.status,o.started_at,o.completed_at,p.id AS plan_id,
       p.title,p.code,p.ext,p.tolerance_days,
       a.name AS equipment_name, target.name AS target_name,
       w.id AS work_order_id, COALESCE(w.est,p.estimated_duration_minutes / 60.0) AS est, COALESCE(w.assignee,p.owner) AS owner_id,
       u.name AS owner_name, location.hall_id, location.hall_name,
       costs.total AS actual_cost, consumed.parts AS consumed_parts,
       COALESCE(cat.factory_asset_id,location.factory_id) AS factory_id
     FROM pm_occurrences o JOIN pm_plans p ON p.id=o.pm_plan_id JOIN assets a ON a.id=o.equipment_id
     LEFT JOIN asset_categories cat ON cat.id=a.category_id
     LEFT JOIN work_orders w ON w.occurrence_id=o.id
     LEFT JOIN users u ON u.id=COALESCE(w.assignee,p.owner)
     LEFT JOIN assets target ON target.id=COALESCE(w.report->>'pmTargetNodeId',p.ext->>'targetNodeId')
     LEFT JOIN LATERAL (
       SELECT SUM(CASE WHEN direction='credit' THEN -amount ELSE amount END) AS total
       FROM work_order_costs WHERE $10::boolean AND work_order_id=w.id AND voided_at IS NULL
     ) costs ON true
     LEFT JOIN LATERAL (
       SELECT jsonb_agg(jsonb_build_object('name',parts.name,'qty',parts.qty,'unit',parts.unit) ORDER BY parts.name) AS parts
       FROM (
         SELECT i.name,i.unit,SUM(CASE WHEN l.movement='return' THEN -l.qty ELSE l.qty END) AS qty
         FROM inventory_ledger l JOIN items i ON i.id=l.item_id
         WHERE $11::boolean AND l.work_order_id=w.id AND
           (l.movement='consume' OR (l.movement='return' AND EXISTS(
             SELECT 1 FROM inventory_ledger original WHERE original.id=l.reverses_entry_id AND original.movement='consume'
           )))
         GROUP BY i.id HAVING SUM(CASE WHEN l.movement='return' THEN -l.qty ELSE l.qty END) > 0
       ) parts
     ) consumed ON true
     LEFT JOIN LATERAL (
       WITH RECURSIVE parents AS (
         SELECT a.id,a.parent,a.name,a.ext->>'nodeKind' AS kind,0 AS depth
         UNION ALL
         SELECT x.id,x.parent,x.name,x.ext->>'nodeKind',parents.depth+1
         FROM assets x JOIN parents ON x.id=parents.parent WHERE parents.depth<32
       )
       SELECT (SELECT id FROM parents WHERE kind='factory' ORDER BY depth LIMIT 1) AS factory_id,
         (SELECT id FROM parents WHERE kind IN ('hall','salon') ORDER BY depth LIMIT 1) AS hall_id,
         (SELECT name FROM parents WHERE kind IN ('hall','salon') ORDER BY depth LIMIT 1) AS hall_name
     ) location ON true
     WHERE o.due_at >= $1 AND o.due_at < $2
       AND a.deleted_at IS NULL
       AND ($3::text IS NULL OR o.equipment_id=$3)
       AND ($4::text IS NULL OR COALESCE(w.assignee,p.owner)=$4)
       AND ($5::text IS NULL OR p.ext->>'activityType'=$5)
       AND ($6::text IS NULL OR COALESCE(cat.factory_asset_id,location.factory_id)=$6)
       AND ($7::text IS NULL OR location.hall_id=$7)
       AND ($8::boolean OR EXISTS (
         SELECT 1 FROM user_scopes s WHERE s.user_id=$9 AND
           (s.scope_type='company' OR (s.scope_type='equipment' AND s.scope_id=o.equipment_id)
             OR (s.scope_type='factory' AND s.scope_id=COALESCE(cat.factory_asset_id,location.factory_id)))
       ))
     ORDER BY o.due_at,o.id LIMIT 5001`,
    [from,to,filters.assetId || null,filters.owner || null,filters.activityType || null,
      filters.factoryId || null,filters.hallId || null,user.role === 'admin',user.id,filters.includeCosts === true,filters.includeParts === true]
  );
  if (rows.length > 5000) throw coded(422, 'PM_REPORT_TOO_MANY_ROWS');
  const evaluatedAt = Date.now();
  const items = rows.map(row => {
    const dueAt = timestampIso(row.due_at);
    const deadline = new Date((Math.floor(Date.parse(dueAt)/86400000) + 1 + Number(row.tolerance_days || 0)) * 86400000 - 1).toISOString();
    const startedAt = timestampIso(row.started_at);
    const completedAt = timestampIso(row.completed_at);
    const elapsed = Date.parse(completedAt) - Date.parse(startedAt);
    return {
      id:row.id, planId:row.plan_id, title:row.title, code:row.code, equipmentId:row.equipment_id,
      equipmentName:row.equipment_name, targetName:row.target_name, ownerId:row.owner_id, ownerName:row.owner_name,
      factoryId:row.factory_id, hallId:row.hall_id, hallName:row.hall_name,
      dueAt, deadline, startedAt, completedAt, status:row.status, activityType:asObject(row.ext).activityType || null,
      workOrderId:row.work_order_id, plannedMinutes:row.est == null ? null : Number(row.est)*60,
      elapsedMinutes:startedAt && completedAt && elapsed >= 0 ? elapsed/60000 : null,
      ...(filters.includeCosts ? {actualCost:row.actual_cost == null ? null : Number(row.actual_cost)} : {}),
      ...(filters.includeParts ? {consumedParts:asArray(row.consumed_parts)} : {})
    };
  });
  const byTechnicianDay = new Map();
  for (const item of items) {
    if (!item.ownerId || PM_OCCURRENCE_FINAL_STATES.has(item.status)) continue;
    const key = JSON.stringify([item.ownerId, item.dueAt.slice(0,10)]);
    const group = byTechnicianDay.get(key) || [];
    group.push(item);
    byTechnicianDay.set(key, group);
  }
  const sharedAssignments = Array.from(byTechnicianDay.values()).filter(group => group.length > 1).map(group => ({
    ownerName:group[0].ownerName, dueAt:group[0].dueAt, count:group.length
  }));
  return { from,to,evaluatedAt:new Date(evaluatedAt).toISOString(),items,sharedAssignments,
    showCosts:filters.includeCosts === true, showParts:filters.includeParts === true, summary:summarizePmSchedule(items,evaluatedAt) };
}

async function listPmPlans(pool, user, filters = {}) {
  const { rows } = await pool.query(
    `SELECT p.*, a.id AS equipment_id, a.code AS equipment_code, a.name AS equipment_name, target.name AS target_name
     FROM pm_plans p LEFT JOIN assets a ON a.id=p.asset_id
     LEFT JOIN assets target ON target.id=p.ext->>'targetNodeId'
     WHERE ($1::boolean OR (p.archived_at IS NULL AND p.deleted_at IS NULL))
       AND ($2::text IS NULL OR p.asset_id=$2)
     ORDER BY p.title LIMIT 500`,
    [filters.includeArchived === true, filters.assetId || null]
  );
  const visible = [];
  for (const row of rows) {
    try {
      await assertEquipmentScope(pool, user, row.asset_id);
      visible.push(row);
    } catch (error) {
      if (!['EQUIPMENT_SCOPE_DENIED','EQUIPMENT_NOT_FOUND'].includes(error.code)) throw error;
    }
  }
  return visible.map(row => pmDto(row));
}

async function getPmPlan(pool, user, id, options = {}) {
  const { rows } = await pool.query(
    `SELECT p.*, a.id AS equipment_id, a.code AS equipment_code, a.name AS equipment_name, target.name AS target_name
     FROM pm_plans p LEFT JOIN assets a ON a.id=p.asset_id
     LEFT JOIN assets target ON target.id=p.ext->>'targetNodeId'
     WHERE p.id=$1 AND ($2::boolean OR (p.archived_at IS NULL AND p.deleted_at IS NULL))`,
    [id, options.includeArchived === true]
  );
  if (!rows[0]) throw coded(404, 'RECORD_NOT_FOUND');
  await assertEquipmentScope(pool, user, rows[0].asset_id);
  return pmDto(rows[0]);
}

async function hasPmOccurrences(client, id) {
  const { rows } = await client.query('SELECT 1 FROM pm_occurrences WHERE pm_plan_id=$1 LIMIT 1', [id]);
  return rows.length > 0;
}

async function updatePmPlan(pool, user, id, input) {
  const rowVersion = versionOf(input.rowVersion);
  return withPmTransaction(pool, async client => {
    const current = await lockRow(client, 'pm_plans', id);
    await assertEquipmentScope(client, user, current.asset_id);
    if (current.deleted_at || current.archived_at || LOCKED_PM.has(current.status)) throw coded(409, 'RECORD_LOCKED');
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    const assetId = input.assetId || current.asset_id;
    if (String(assetId) !== String(current.asset_id)) await assertEquipmentScope(client, user, assetId);
    const title = String(input.title ?? current.title ?? '').trim();
    if (!title) throw coded(422, 'TITLE_REQUIRED');
    if (assetId !== current.asset_id && await hasPmOccurrences(client, id)) throw coded(409, 'PM_EQUIPMENT_HAS_HISTORY');
    const fields = await pmPlanning.activityFields(client, assetId, input, current);
    if (Object.hasOwn(input, 'requiredParts')) fields.required_parts = JSON.stringify(await normalizeRequiredParts(client, input.requiredParts, { allowShortage:true }));
    const owner = Object.hasOwn(input, 'owner') ? await requireUser(client, input.owner || null) : current.owner;
    const previousChecklist = asArray(current.checklist);
    const checklist = Object.hasOwn(input, 'checklist') ? pmPlanning.checklist(input.checklist) : previousChecklist;
    if (Object.hasOwn(input, 'checklist') && input.preserveLegacyChecklist === true) {
      checklist.push(...previousChecklist.filter(item => item && typeof item === 'object' && !item.measurementType));
    }
    const updated = await writeUpdate(client, 'pm_plans', id, rowVersion, user.id, {
      ...fields, asset_id: assetId, title, owner,
      interval_days: positiveInteger(input.intervalDays ?? input.interval ?? current.interval_days, 'PM_INTERVAL_DAYS_INVALID') || 30,
      spec: input.spec === undefined ? current.spec : input.spec,
      checklist: JSON.stringify(checklist)
    });
    await audit(client, user, 'edit', 'pm_plan', id, current, updated, 'ویرایش برنامه PM');
    await publish(client, user, {
      type: 'pm_plan.updated', aggregateType: 'pm_plan', aggregateId: id, permission: 'pm.view',
      equipmentId: assetId, payload: { id, assetId, rowVersion: Number(updated.row_version) }
    });
    return pmDto(updated);
  });
}

async function lockPmPlanForArchive(client, id) {
  const { rows } = await client.query('SELECT * FROM pm_plans WHERE id=$1 FOR UPDATE', [id]);
  if (!rows[0]) throw coded(404, 'RECORD_NOT_FOUND');
  return rows[0];
}

async function requirePmActor(client, user) {
  if (!user || !user.id) throw coded(422, 'ACTOR_REQUIRED');
  const { rows } = await client.query('SELECT id FROM users WHERE id=$1 AND active=true', [user.id]);
  if (!rows[0]) throw coded(403, 'ACTOR_INVALID');
  return rows[0].id;
}

async function assertNoActivePmWork(client, planId) {
  const { rows } = await client.query(
    `SELECT 1 FROM pm_occurrences o
     WHERE o.pm_plan_id=$1 AND o.status='in_progress'
     UNION ALL
     SELECT 1 FROM work_orders w
     LEFT JOIN pm_occurrences o ON o.id=w.occurrence_id
     WHERE w.deleted_at IS NULL AND (w.pm_id=$1 OR o.pm_plan_id=$1)
       AND w.status=ANY($2::text[])
     LIMIT 1`,
    [planId, [...PM_ACTIVE_WORK_ORDER_STATES]]
  );
  if (rows[0]) throw coded(409, 'PM_HAS_ACTIVE_WORK');
}

async function archivePmPlan(pool, user, id, input = {}) {
  const rowVersion = versionOf(input.rowVersion);
  const reason = reasonOf(input.reason, 'ARCHIVE_REASON_REQUIRED');
  return withPmTransaction(pool, async client => {
    const current = await lockPmPlanForArchive(client, id);
    await assertEquipmentScope(client, user, current.asset_id);
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    await requirePmActor(client, user);
    await assertNoActivePmWork(client, id);
    if (current.archived_at || current.deleted_at) return { archived:true, historyPreserved:true, idempotent:true };
    const { rows:clockRows } = await client.query('SELECT clock_timestamp() AS archived_at');
    const archivedAt = clockRows[0]?.archived_at;
    if (!archivedAt) throw coded(500, 'PM_ARCHIVE_TIMESTAMP_UNAVAILABLE');
    const { rows } = await client.query(
      `UPDATE pm_plans
       SET archived_at=$3, archived_by=$4, archive_reason=$5, deleted_at=$3,
           updated_at=$3, updated_by=$4, row_version=row_version+1
       WHERE id=$1 AND row_version=$2 AND archived_at IS NULL AND deleted_at IS NULL
       RETURNING *`,
      [id, rowVersion, archivedAt, user.id, reason]
    );
    if (!rows[0]) throw coded(409, 'VERSION_CONFLICT');
    await audit(client, user, 'archive', 'pm_plan', id, current, rows[0], reason);
    await publish(client, user, {
      type:'pm_plan.archived', aggregateType:'pm_plan', aggregateId:id, permission:'pm.view',
      equipmentId:current.asset_id, payload:{ id, archived:true, assetId:current.asset_id, archivedAt }
    });
    return { archived:true, historyPreserved:true };
  });
}

async function restorePmPlan(pool, user, id, input = {}) {
  const rowVersion = versionOf(input.rowVersion);
  return withPmTransaction(pool, async client => {
    const current = await lockPmPlanForArchive(client, id);
    await assertEquipmentScope(client, user, current.asset_id);
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    await requirePmActor(client, user);
    const isArchived = Boolean(current.archived_at || current.deleted_at);
    if (!isArchived) return { restored:true, historyPreserved:true, idempotent:true };

    if (current.code != null) {
      const { rows:conflicts } = await client.query(
        `SELECT id FROM pm_plans
         WHERE id<>$1 AND asset_id=$2 AND code=$3
           AND archived_at IS NULL AND deleted_at IS NULL
         LIMIT 1`,
        [id, current.asset_id, current.code]
      );
      if (conflicts[0]) throw coded(409, 'PM_CODE_CONFLICT');
    }
    const { rows } = await client.query(
      `UPDATE pm_plans
       SET archived_at=NULL, archived_by=NULL, archive_reason=NULL, deleted_at=NULL,
           updated_at=clock_timestamp(), updated_by=$3, row_version=row_version+1
       WHERE id=$1 AND row_version=$2 AND (archived_at IS NOT NULL OR deleted_at IS NOT NULL)
       RETURNING *`,
      [id, rowVersion, user.id]
    );
    if (!rows[0]) throw coded(409, 'VERSION_CONFLICT');
    await audit(client, user, 'restore', 'pm_plan', id, current, rows[0], 'بازیابی برنامه PM');
    await publish(client, user, {
      type:'pm_plan.restored', aggregateType:'pm_plan', aggregateId:id, permission:'pm.view',
      equipmentId:current.asset_id, payload:{ id, restored:true, assetId:current.asset_id }
    });
    return { restored:true, historyPreserved:true };
  });
}

async function cancelPmPlan(pool, user, id, input) {
  const rowVersion = versionOf(input.rowVersion);
  const reason = reasonOf(input.reason, 'CANCEL_REASON_REQUIRED');
  return withTransaction(pool, async client => {
    const current = await lockRow(client, 'pm_plans', id);
    await assertEquipmentScope(client, user, current.asset_id);
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    if (current.deleted_at || current.archived_at || LOCKED_PM.has(current.status)) throw coded(409, 'RECORD_LOCKED');
    const updated = await writeUpdate(client, 'pm_plans', id, rowVersion, user.id, {
      status: 'cancelled',
      cancel_reason: reason,
      cancelled_at: new Date().toISOString()
    });
    await audit(client, user, 'cancel', 'pm_plan', id, current, updated, reason);
    await publish(client, user, {
      type: 'pm_plan.cancelled', aggregateType: 'pm_plan', aggregateId: id, permission: 'pm.view',
      equipmentId: current.asset_id, payload: { id, status: 'cancelled', assetId: current.asset_id }
    });
    return pmDto(updated);
  });
}

async function generatePmWorkOrder(pool, user, id, input) {
  const rowVersion = versionOf(input.rowVersion);
  return withPmTransaction(pool, async client => {
    const current = await lockRow(client, 'pm_plans', id);
    await assertEquipmentScope(client, user, current.asset_id);
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    if (LOCKED_PM.has(current.status) || current.archived_at || current.deleted_at) throw coded(409, 'RECORD_LOCKED');

    const evaluatedAt = new Date();
    const due = calculatePmDue(current, evaluatedAt);
    if (!due.nextDueAt || due.dueStatus === 'insufficient_data') {
      throw Object.assign(coded(422, 'PM_SCHEDULE_DATA_REQUIRED'), { reason:due.reason || 'due_date_unavailable' });
    }
    const periodKey = periodKeyForDueDate(due.nextDueAt, current.schedule_basis);
    const requestedKey = String(input.idempotencyKey || input.requestId || `pm-generate:${id}:${periodKey}`).trim();
    if (!requestedKey || requestedKey.length > 240) throw coded(422, 'PM_IDEMPOTENCY_KEY_INVALID');
    const requestHash = crypto.createHash('sha256').update(JSON.stringify({ planId:String(id), periodKey })).digest('hex');
    const replay = await reservePmGenerationRequest(client, user.id, requestedKey, requestHash);
    if (replay) return { ...replay, idempotentReplay:true };

    let occurrence = await findPmOccurrence(client, id, periodKey);
    if (!occurrence) {
      const occurrenceId = crypto.randomUUID();
      const inserted = await client.query(
        `INSERT INTO pm_occurrences(id,pm_plan_id,equipment_id,period_key,due_at,status,provenance_status,row_version,created_by,updated_by)
         VALUES($1,$2,$3,$4,$5,$6,'verified',1,$7,$7)
         ON CONFLICT(pm_plan_id,period_key) DO NOTHING RETURNING *`,
        [occurrenceId, id, current.asset_id, periodKey, due.nextDueAt, due.dueStatus, user.id]
      );
      occurrence = inserted.rows[0] || await findPmOccurrence(client, id, periodKey);
      if (!occurrence) throw coded(409, 'PM_OCCURRENCE_CONFLICT');
    }
    if (PM_OCCURRENCE_FINAL_STATES.has(occurrence.status)) throw coded(409, 'PM_OCCURRENCE_NOT_GENERATABLE');

    let workOrder = occurrence.linked_work_order_id
      ? await findPmWorkOrder(client, occurrence.id)
      : null;
    if (occurrence.linked_work_order_id && !workOrder) throw coded(409, 'PM_OCCURRENCE_WORK_ORDER_INCONSISTENT');
    let updatedOccurrence = occurrence;
    if (workOrder) {
      if (occurrence.status !== 'work_order_generated') {
        const { rows } = await client.query(
          `UPDATE pm_occurrences SET status='work_order_generated',generated_at=COALESCE(generated_at,now()),
             updated_at=now(),updated_by=$3,row_version=row_version+1
           WHERE id=$1 AND row_version=$2 RETURNING *`,
          [occurrence.id, Number(occurrence.row_version), user.id]
        );
        if (!rows[0]) throw coded(409, 'VERSION_CONFLICT');
        updatedOccurrence = rows[0];
        await audit(client, user, 'reconcile', 'pm_occurrence', occurrence.id, occurrence, updatedOccurrence, 'بازیابی اتصال دستورکار موجود');
      }
    } else {
      if (occurrence.status === 'work_order_generated') throw coded(409, 'PM_OCCURRENCE_WORK_ORDER_INCONSISTENT');
      if (!PM_OCCURRENCE_STATES.has(occurrence.status) || !['scheduled','due','overdue'].includes(occurrence.status)) {
        throw coded(409, 'PM_OCCURRENCE_NOT_GENERATABLE');
      }
      const workOrderId = crypto.randomUUID();
      const no = await nextNumber(client, 'work_order', 'WO');
      const checklist = asArray(current.checklist);
      const labels = checklist.map(pmPlanning.checklistLabel).filter(Boolean);
      const descr = `${current.title}${labels.length ? ' — ' + labels.join('، ') : ''}`;
      const targetNodeId = asObject(current.ext).targetNodeId || null;
      await pmPlanning.assertPlanTarget(client, current.asset_id, targetNodeId);
      const report = { pmTargetNodeId:targetNodeId, pmChecklist:checklist.filter(item => item && typeof item === 'object' && item.measurementType) };
      const estimatedHours = Number(current.estimated_duration_minutes) > 0
        ? Number(current.estimated_duration_minutes) / 60 : null;
      const created = await client.query(
        `INSERT INTO work_orders(id,no,type,asset_id,descr,priority,assignee,status,pm_id,occurrence_id,due_at,source_ref,times,parts,report,est,ptw,permit_status,required_parts)
         VALUES($1,$2,'PM',$3,$4,'normal',$5,$6,$7,$8,$9,$10,'{}'::jsonb,'[]'::jsonb,$12,$11,$13,$14,$15) RETURNING *`,
        [workOrderId, no, current.asset_id, descr, current.owner || null, current.owner ? 'assigned' : 'open',
          current.id, occurrence.id, occurrence.due_at, `pm:${id}:${periodKey}`, estimatedHours, JSON.stringify(report),
          current.ptw_required === true, current.ptw_required === true ? 'pending_issuance' : 'not_required', JSON.stringify(asArray(current.required_parts))]
      );
      workOrder = created.rows[0];
      await linkWorkOrderAsset(client, workOrderId, current.asset_id);
      if (targetNodeId) await client.query(
        `INSERT INTO work_order_assets(work_order_id,asset_id,relation_type,is_confirmed)
         VALUES($1,$2,'related',true) ON CONFLICT DO NOTHING`, [workOrderId, targetNodeId]
      );
      const { rows } = await client.query(
        `UPDATE pm_occurrences SET status='work_order_generated',generated_at=now(),updated_at=now(),
           updated_by=$3,row_version=row_version+1
         WHERE id=$1 AND row_version=$2 RETURNING *`,
        [occurrence.id, Number(occurrence.row_version), user.id]
      );
      if (!rows[0]) throw coded(409, 'VERSION_CONFLICT');
      updatedOccurrence = rows[0];
      await audit(client, user, 'create', 'pm_occurrence', occurrence.id, null, updatedOccurrence, periodKey);
      await audit(client, user, 'generate', 'pm_plan', id, current, current, no);
      await audit(client, user, 'create', 'work_order', workOrderId, null, workOrder, `صدور از PM ${current.title}`);
      await publish(client, user, {
        type:'pm_plan.generated', aggregateType:'pm_plan', aggregateId:id, permission:'pm.view',
        equipmentId:current.asset_id, payload:{ id, workOrderId, occurrenceId:occurrence.id, periodKey, assetId:current.asset_id }
      });
      await publish(client, user, {
        type:'work_order.created', aggregateType:'work_order', aggregateId:workOrderId, permission:'work_order.view',
        equipmentId:current.asset_id, payload:{ id:workOrderId, no, assetId:current.asset_id, pmId:id, occurrenceId:occurrence.id }
      });
    }

    const result = {
      plan:pmDto(current, evaluatedAt),
      occurrence:occurrenceDto({ ...updatedOccurrence, linked_work_order_id:workOrder.id }),
      workOrder:workOrderDto(workOrder)
    };
    await client.query(
      `UPDATE idempotency_keys SET response_status=201,response_body=$3::jsonb,expires_at=now()+interval '24 hours'
       WHERE user_id=$1 AND idempotency_key=$2 AND request_hash=$4`,
      [user.id, requestedKey, JSON.stringify(result), requestHash]
    );
    return result;
  });
}

async function equipmentLinks(pool, assetId) {
  const equipment = await requireEquipment({ query: (sql, params) => pool.query(sql, params) }, assetId, true);
  const [requests, workOrders, plans] = await Promise.all([
    pool.query('SELECT id, no, status, asset_id FROM requests WHERE asset_id=$1 AND deleted_at IS NULL ORDER BY created_at DESC', [assetId]),
    pool.query('SELECT id, no, status, asset_id, req_id, pm_id FROM work_orders WHERE asset_id=$1 AND deleted_at IS NULL ORDER BY created_at DESC', [assetId]),
    pool.query('SELECT id, title, status, asset_id FROM pm_plans WHERE asset_id=$1 AND deleted_at IS NULL ORDER BY title', [assetId])
  ]);
  return {
    equipment,
    requests: requests.rows,
    workOrders: workOrders.rows,
    pmPlans: plans.rows
  };
}

const MAX_WIZARD_DRAFT_BYTES = 96 * 1024;

function normalizeDraft(value) {
  if (!value || typeof value !== 'object' || Array.isArray(value)) throw coded(422, 'WIZARD_DRAFT_INVALID');
  let serialized;
  try { serialized = JSON.stringify(value); } catch (_) { throw coded(422, 'WIZARD_DRAFT_INVALID'); }
  if (!serialized || Buffer.byteLength(serialized, 'utf8') > MAX_WIZARD_DRAFT_BYTES) throw coded(413, 'WIZARD_DRAFT_TOO_LARGE');
  return JSON.parse(serialized);
}

function wizardDraftDto(row) {
  return {
    id:row.id, wizardType:row.wizard_type, draft:asObject(row.draft), stepId:row.step_id || '',
    status:row.status, targetEntityType:row.target_entity_type || null, targetEntityId:row.target_entity_id || null,
    createdAt:row.created_at, updatedAt:row.updated_at, rowVersion:Number(row.row_version)
  };
}

async function createWizardDraft(pool, user, input = {}) {
  const wizardType = String(input.wizardType || '');
  if (!['request','work_order'].includes(wizardType)) throw coded(422, 'WIZARD_TYPE_INVALID');
  const draft = normalizeDraft(input.draft || {});
  const stepId = String(input.stepId || '').slice(0, 120);
  return withTransaction(pool, async client => {
    const id = crypto.randomUUID();
    const { rows } = await client.query(
      `INSERT INTO maintenance_wizard_drafts(id,wizard_type,draft,step_id,created_by,updated_by)
       VALUES($1,$2,$3,$4,$5,$5) RETURNING *`,
      [id, wizardType, JSON.stringify(draft), stepId, user.id]
    );
    await audit(client, user, 'wizard-draft-create', wizardType, id, null, rows[0], 'ایجاد پیش‌نویس فرم پله‌ای');
    return wizardDraftDto(rows[0]);
  });
}

async function listWizardDrafts(pool, user, wizardType) {
  if (!['request','work_order'].includes(wizardType)) throw coded(422, 'WIZARD_TYPE_INVALID');
  const { rows } = await pool.query(
    `SELECT * FROM maintenance_wizard_drafts
     WHERE created_by=$1 AND wizard_type=$2 AND status='draft' AND deleted_at IS NULL
     ORDER BY updated_at DESC LIMIT 20`,
    [user.id, wizardType]
  );
  return rows.map(wizardDraftDto);
}

async function getWizardDraft(pool, user, id, expectedType = null) {
  const { rows } = await pool.query(
    `SELECT * FROM maintenance_wizard_drafts WHERE id=$1 AND created_by=$2 AND deleted_at IS NULL`, [id,user.id]
  );
  if (!rows[0] || (expectedType && rows[0].wizard_type !== expectedType)) throw coded(404, 'WIZARD_DRAFT_NOT_FOUND');
  return wizardDraftDto(rows[0]);
}

async function updateWizardDraft(pool, user, id, input = {}, expectedType = null) {
  const rowVersion = versionOf(input.rowVersion);
  const draft = normalizeDraft(input.draft || {});
  const stepId = String(input.stepId || '').slice(0, 120);
  return withTransaction(pool, async client => {
    const { rows:locked } = await client.query(
      `SELECT * FROM maintenance_wizard_drafts
       WHERE id=$1 AND created_by=$2 AND status='draft' AND deleted_at IS NULL FOR UPDATE`, [id,user.id]
    );
    const current = locked[0];
    if (!current || (expectedType && current.wizard_type !== expectedType)) throw coded(404, 'WIZARD_DRAFT_NOT_FOUND');
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    const { rows } = await client.query(
      `UPDATE maintenance_wizard_drafts SET draft=$3,step_id=$4,updated_at=now(),updated_by=$5,row_version=row_version+1
       WHERE id=$1 AND row_version=$2 AND created_by=$5 AND status='draft' AND deleted_at IS NULL RETURNING *`,
      [id,rowVersion,JSON.stringify(draft),stepId,user.id]
    );
    if (!rows[0]) throw coded(409, 'VERSION_CONFLICT');
    await audit(client, user, 'wizard-draft-update', current.wizard_type, id, current, rows[0], 'ذخیره پیش‌نویس فرم پله‌ای');
    return wizardDraftDto(rows[0]);
  });
}

async function cancelWizardDraft(pool, user, id, input = {}, expectedType = null) {
  const rowVersion = versionOf(input.rowVersion);
  return withTransaction(pool, async client => {
    const { rows:locked } = await client.query(
      `SELECT * FROM maintenance_wizard_drafts WHERE id=$1 AND created_by=$2 AND status='draft' AND deleted_at IS NULL FOR UPDATE`, [id,user.id]
    );
    const current = locked[0];
    if (!current || (expectedType && current.wizard_type !== expectedType)) throw coded(404, 'WIZARD_DRAFT_NOT_FOUND');
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    const { rows } = await client.query(
      `UPDATE maintenance_wizard_drafts SET status='cancelled',updated_at=now(),updated_by=$3,row_version=row_version+1
       WHERE id=$1 AND row_version=$2 AND created_by=$3 AND status='draft' AND deleted_at IS NULL RETURNING *`,
      [id,rowVersion,user.id]
    );
    if (!rows[0]) throw coded(409, 'VERSION_CONFLICT');
    await audit(client, user, 'wizard-draft-cancel', current.wizard_type, id, current, rows[0], 'انصراف از پیش‌نویس');
    return wizardDraftDto(rows[0]);
  });
}

function wizardOther(answers, key) {
  if (answers[key] === '__other__') return String(answers[key + 'Other'] || 'سایر').trim();
  return answers[key] == null ? '' : String(answers[key]).trim();
}

function wizardDate(value, field) {
  if (value == null || value === '') return null;
  const date = new Date(value);
  if (Number.isNaN(date.getTime())) throw coded(422, `WIZARD_${field.toUpperCase()}_INVALID`);
  return date.toISOString();
}

function requestPayloadFromDraft(draft, user) {
  const answers = asObject(draft.answers);
  const actionType = String(answers.actionType || '');
  if (!['emergency','preventive','service','fab'].includes(actionType)) throw coded(422, 'WIZARD_ACTION_TYPE_REQUIRED');
  const serviceType = wizardOther(answers, 'serviceType');
  if (actionType !== 'fab' && !serviceType) throw coded(422, 'WIZARD_SERVICE_TYPE_REQUIRED');
  const urgency = String(answers.urgency || '');
  if (!['critical','high','normal'].includes(urgency)) throw coded(422, 'WIZARD_URGENCY_INVALID');
  const stopProduction = String(answers.stopProduction || '');
  if (!['yes','no'].includes(stopProduction)) throw coded(422, 'WIZARD_PRODUCTION_IMPACT_REQUIRED');
  const descr = String(answers.description || answers.desc || '').trim();
  if (!descr) throw coded(422, 'DESCRIPTION_REQUIRED');
  const unit = String(answers.unit || user.unit || '').trim();
  if (!unit) throw coded(422, 'WIZARD_UNIT_REQUIRED');
  const subsystemId = answers.subsystemId && answers.subsystemId !== '__none__' ? answers.subsystemId : null;
  const equipmentId = answers.equipmentId && answers.equipmentId !== '__none__' ? answers.equipmentId : null;
  const form = { ...answers,
    actionType,
    serviceType,
    failureType:wizardOther(answers, 'failureType') || null,
    factoryId:answers.factoryId === '__none__' ? null : (answers.factoryId || null),
    categoryId:answers.categoryId === '__all__' ? null : (answers.categoryId || null),
    equipmentId,
    subsystemId,
    failureOccurredAt:wizardDate(answers.failureOccurredAt, 'failure_time'),
    stopOccurredAt:wizardDate(answers.stopOccurredAt, 'stop_time'),
    needBy:wizardDate(answers.needBy, 'need_by'),
    unit,
    phone:String(answers.phone || '').trim(),
    description:descr
  };
  const stopDuration = answers.stopDurationMinutes == null || answers.stopDurationMinutes === '' ? null : Number(answers.stopDurationMinutes);
  if (stopDuration != null && (!Number.isFinite(stopDuration) || stopDuration < 0 || stopDuration > 100000)) throw coded(422, 'WIZARD_STOP_DURATION_INVALID');
  form.stopDurationMinutes = stopDuration;
  delete form.attachments;
  return {
    type:actionType === 'fab' ? 'fab' : actionType === 'service' ? 'service' : 'repair',
    unit,
    assetId:subsystemId || equipmentId,
    descr,
    urgency,
    impact:stopProduction === 'yes',
    form
  };
}

function workOrderPayloadFromDraft(draft) {
  const answers = asObject(draft.answers);
  const requestId = answers.requestId && answers.requestId !== '__none__' ? String(answers.requestId) : null;
  const quantities = asObject(answers.partQuantities);
  const selectedParts = Array.isArray(answers.requiredParts) ? answers.requiredParts : [];
  if (selectedParts.length > 50) throw coded(422, 'TOO_MANY_REQUIRED_PARTS');
  const estimateInput=answers.estimatedHours;
  const estimatedHours=estimateInput==null||estimateInput===''?null:Number(estimateInput);
  if (estimatedHours!=null&&(!Number.isFinite(estimatedHours)||estimatedHours<=0||estimatedHours>100000)) throw coded(422, 'WIZARD_ESTIMATE_INVALID');
  const subsystemId = answers.subsystemId && answers.subsystemId !== '__none__' ? answers.subsystemId : null;
  const equipmentId = answers.equipmentId && answers.equipmentId !== '__none__' ? answers.equipmentId : null;
  const assignee = answers.assignee && answers.assignee !== '__none__' ? answers.assignee : null;
  const workOrderType = String(answers.workOrderType || answers.type || '');
  if (!['BD','CM','PM','SRV','FAB'].includes(workOrderType)) throw coded(422, 'WIZARD_WORK_ORDER_TYPE_REQUIRED');
  const priority = String(answers.priority || '');
  if (!['critical','high','normal'].includes(priority)) throw coded(422, 'WIZARD_PRIORITY_INVALID');
  const ptwChoice = answers.ptwChoice;
  if (!['yes','no'].includes(ptwChoice)) throw coded(422, 'WIZARD_PERMIT_DECISION_REQUIRED');
  const descr = String(answers.workDescription || answers.description || '').trim();
  if (!descr) throw coded(422, 'DESCRIPTION_REQUIRED');
  return {
    requestId,
    rowVersion:Number(answers.requestRowVersion),
    workOrderType,
    type:workOrderType,
    assetId:subsystemId || equipmentId,
    descr,
    priority,
    assignee,
    est:estimatedHours,
    failureType:wizardOther(answers, 'failureType') || null,
    probableCauses:answers.probableCause || '',
    confirmedRootCause:answers.confirmedRootCause || '',
    recommendedAction:answers.recommendedAction || '',
    performedAction:answers.performedAction || '',
    requiredParts:selectedParts.map(itemId => {
      const qty=Number(quantities[itemId]);
      if (!Number.isFinite(qty) || qty <= 0) throw coded(422, 'INVALID_PART_QUANTITY');
      return { itemId, qty };
    }),
    ptwRequired:ptwChoice === 'yes'
  };
}

async function submitWizardDraft(pool, user, id, input = {}, expectedType = null) {
  if (input.confirmed !== true) throw coded(422, 'FINAL_CONFIRMATION_REQUIRED');
  const rowVersion = versionOf(input.rowVersion);
  return withTransaction(pool, async client => {
    const { rows:locked } = await client.query(
      `SELECT * FROM maintenance_wizard_drafts WHERE id=$1 AND created_by=$2 AND deleted_at IS NULL FOR UPDATE`, [id,user.id]
    );
    const current = locked[0];
    if (!current || (expectedType && current.wizard_type !== expectedType)) throw coded(404, 'WIZARD_DRAFT_NOT_FOUND');
    if (current.status === 'submitted') {
      if (current.target_entity_type === 'request') {
        const { rows } = await client.query(
          `SELECT r.*,a.id AS equipment_id,a.code AS equipment_code,a.name AS equipment_name
           FROM requests r LEFT JOIN assets a ON a.id=r.asset_id WHERE r.id=$1`, [current.target_entity_id]
        );
        if (!rows[0]) throw coded(404, 'RECORD_NOT_FOUND');
        return { request:requestDto(rows[0]), draft:wizardDraftDto(current), alreadySubmitted:true };
      }
      if (current.target_entity_type === 'work_order') {
        const { rows } = await client.query(
          `SELECT w.*,a.id AS equipment_id,a.code AS equipment_code,a.name AS equipment_name
           FROM work_orders w LEFT JOIN assets a ON a.id=w.asset_id WHERE w.id=$1`, [current.target_entity_id]
        );
        if (!rows[0]) throw coded(404, 'RECORD_NOT_FOUND');
        return { workOrder:workOrderDto(rows[0]), draft:wizardDraftDto(current), alreadySubmitted:true };
      }
      throw coded(409, 'WIZARD_DRAFT_ALREADY_SUBMITTED');
    }
    if (current.status !== 'draft') throw coded(409, 'WIZARD_DRAFT_NOT_ACTIVE');
    if (Number(current.row_version) !== rowVersion) throw coded(409, 'VERSION_CONFLICT');
    const saved = asObject(current.draft);
    let result, targetType, targetId;
    if (current.wizard_type === 'request') {
      const created = await createRequestInTransaction(client, user, requestPayloadFromDraft(saved, user));
      result = { request:created };
      targetType = 'request';
      targetId = created.id;
    } else if (current.wizard_type === 'work_order') {
      const payload = workOrderPayloadFromDraft(saved);
      if (payload.requestId) {
        if (!Number.isInteger(payload.rowVersion) || payload.rowVersion < 1) throw coded(422, 'REQUEST_VERSION_REQUIRED');
        result = await approveRequestInTransaction(client, user, payload.requestId, payload);
        targetType = 'work_order';
        targetId = result.workOrder.id;
      } else {
        const created = await createWorkOrderInTransaction(client, user, payload);
        result = { workOrder:created };
        targetType = 'work_order';
        targetId = created.id;
      }
    } else {
      throw coded(422, 'WIZARD_TYPE_INVALID');
    }
    const { rows } = await client.query(
      `UPDATE maintenance_wizard_drafts SET status='submitted',target_entity_type=$3,target_entity_id=$4,
         updated_at=now(),updated_by=$5,row_version=row_version+1
       WHERE id=$1 AND row_version=$2 AND created_by=$5 AND status='draft' AND deleted_at IS NULL RETURNING *`,
      [id,rowVersion,targetType,targetId,user.id]
    );
    if (!rows[0]) throw coded(409, 'VERSION_CONFLICT');
    await audit(client, user, 'wizard-draft-submit', current.wizard_type, id, current, rows[0], `${targetType}:${targetId}`);
    return { ...result, draft:wizardDraftDto(rows[0]) };
  });
}

function requestFileDto(row) {
  return { id:row.id, name:row.original_name, mediaType:row.media_type, byteSize:Number(row.byte_size), sha256:row.sha256, createdAt:row.created_at };
}

async function saveRequestFile(pool, user, requestId, file, uploadToken = null) {
  return withTransaction(pool, async client => {
    const { rows:requests } = await client.query(
      'SELECT * FROM requests WHERE id=$1 AND deleted_at IS NULL FOR UPDATE', [requestId]
    );
    const request = requests[0];
    if (!request || (request.requester_id !== user.id && user.role !== 'admin')) throw coded(404, 'RECORD_NOT_FOUND');
    if (uploadToken) {
      const existing = await client.query('SELECT * FROM request_files WHERE request_id=$1 AND upload_token=$2 AND deleted_at IS NULL', [requestId,uploadToken]);
      if (existing.rows[0]) return requestFileDto(existing.rows[0]);
    }
    const { rows:counts } = await client.query('SELECT count(*)::int AS total FROM request_files WHERE request_id=$1 AND deleted_at IS NULL', [requestId]);
    if (Number(counts[0] && counts[0].total) >= 10) throw coded(422, 'ATTACHMENT_LIMIT_REACHED');
    const id = file.id || crypto.randomUUID();
    const { rows } = await client.query(
      `INSERT INTO request_files(id,request_id,original_name,stored_name,media_type,byte_size,sha256,upload_token,created_by,updated_by)
       VALUES($1,$2,$3,$4,$5,$6,$7,$8,$9,$9) RETURNING *`,
      [id,requestId,file.originalName,file.storedName,file.mediaType,file.byteSize,file.sha256,uploadToken,user.id]
    );
    await audit(client, user, 'attachment-create', 'request', requestId, null, rows[0], file.originalName);
    await publish(client, user, {
      type:'request.attachment_added', aggregateType:'request', aggregateId:requestId, permission:'request.view',
      equipmentId:request.asset_id, payload:{ requestId, fileId:id, name:file.originalName }
    });
    return requestFileDto(rows[0]);
  });
}

async function getRequestFileByUploadToken(pool, user, requestId, uploadToken) {
  const { rows } = await pool.query(
    `SELECT f.* FROM request_files f JOIN requests r ON r.id=f.request_id
     WHERE f.request_id=$1 AND f.upload_token=$2 AND f.deleted_at IS NULL
       AND r.deleted_at IS NULL AND (r.requester_id=$3 OR $4='admin')`,
    [requestId,uploadToken,user.id,user.role]
  );
  return rows[0] ? requestFileDto(rows[0]) : null;
}

async function listRequestFiles(pool, requestId) {
  const { rows } = await pool.query(
    'SELECT * FROM request_files WHERE request_id=$1 AND deleted_at IS NULL ORDER BY created_at DESC', [requestId]
  );
  return rows.map(requestFileDto);
}

async function getRequestFile(pool, requestId, fileId) {
  const { rows } = await pool.query(
    'SELECT * FROM request_files WHERE request_id=$1 AND id=$2 AND deleted_at IS NULL', [requestId,fileId]
  );
  if (!rows[0]) throw coded(404, 'FILE_NOT_FOUND');
  return rows[0];
}

module.exports = {
  REQUEST_FLOW,
  WORK_ORDER_FLOW,
  LOCKED_REQUEST,
  LOCKED_WORK_ORDER,
  hasExecutionHistory,
  isRecipientAllowed,
  assertTransition,
  requestDto,
  workOrderDto,
  pmDto,
  calculatePmDue,
  periodKeyForDueDate,
  createRequest,
  listRequests,
  getRequest,
  updateRequest,
  transitionRequest,
  approveRequest,
  archiveRequest,
  createWorkOrder,
  listWorkOrders,
  getWorkOrder,
  updateWorkOrder,
  linkWorkOrderPermit,
  transitionWorkOrder,
  archiveWorkOrder,
  cancelWorkOrder,
  correctRecord,
  createPmPlan,
  listPmPlans,
  reschedulePmPlan,
  pmScheduleReport,
  pmPartsReadiness,
  summarizePmSchedule,
  getPmPlan,
  getPmDue,
  listPmOccurrences,
  getPmOccurrence,
  createPmOccurrence,
  updatePmOccurrenceDueStatus,
  updatePmPlan,
  archivePmPlan,
  restorePmPlan,
  cancelPmPlan,
  generatePmWorkOrder,
  equipmentLinks,
  normalizeRequiredParts,
  technicianSuggestions,
  requestPayloadFromDraft,
  workOrderPayloadFromDraft,
  wizardOther,
  wizardDate,
  createWizardDraft,
  listWizardDrafts,
  getWizardDraft,
  updateWizardDraft,
  cancelWizardDraft,
  submitWizardDraft,
  saveRequestFile,
  getRequestFileByUploadToken,
  listRequestFiles,
  getRequestFile
};
