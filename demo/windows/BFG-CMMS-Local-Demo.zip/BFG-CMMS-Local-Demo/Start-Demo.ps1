param([ValidateRange(1024,65535)][int]$Port = 3000)
$ErrorActionPreference = 'Stop'

function New-DemoSecret([int]$Size) {
    $bytes = New-Object byte[] $Size
    $random = [System.Security.Cryptography.RandomNumberGenerator]::Create()
    try { $random.GetBytes($bytes) } finally { $random.Dispose() }
    return [BitConverter]::ToString($bytes).Replace('-', '').ToLowerInvariant()
}

if (-not (Get-Command docker -ErrorAction SilentlyContinue)) {
    throw 'Install and start Docker Desktop with Linux containers, then run this script again.'
}
docker info --format '{{.OSType}}' | Out-Null
if ($LASTEXITCODE -ne 0) { throw 'Start Docker Desktop, wait until it is running, and try again.' }

Push-Location -LiteralPath $PSScriptRoot
$previousPort = $env:BFG_DEMO_PORT
try {
    if (-not (Test-Path -LiteralPath '.env.demo')) {
        @(
            "DEMO_DB_PASSWORD=$(New-DemoSecret 24)"
            "DEMO_JWT_SECRET=$(New-DemoSecret 32)"
            "DEMO_ADMIN_PASSWORD=$(New-DemoSecret 18)"
        ) | Set-Content -LiteralPath '.env.demo' -Encoding ASCII
    }
    $env:BFG_DEMO_PORT = [string]$Port
    docker compose --env-file .env.demo -p bfg-cmms-local-demo -f compose.demo.yml up --build --detach --wait --wait-timeout 180
    if ($LASTEXITCODE -ne 0) { throw 'Demo startup failed. Review the Docker output above.' }

    $url = "http://127.0.0.1:$Port"
    $health = Invoke-RestMethod -Uri "$url/api/health"
    if ($health.status -ne 'ready') { throw 'The app database is not ready.' }
    $passwordLine = Get-Content -LiteralPath '.env.demo' | Where-Object { $_ -like 'DEMO_ADMIN_PASSWORD=*' }
    Write-Host "Demo URL: $url"
    Write-Host 'Username: admin'
    Write-Host ("Demo password: " + ($passwordLine -replace '^DEMO_ADMIN_PASSWORD=', ''))
    Start-Process $url
} finally {
    $env:BFG_DEMO_PORT = $previousPort
    Pop-Location
}
