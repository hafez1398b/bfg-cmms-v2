/* PostgreSQL-only Equipment Registry adapter. UI preferences may use session state;
   equipment records are never read from or written to browser storage. */
(function(){
  'use strict';

  const hasSession=()=>Boolean(window.BFGBackend&&window.BFGBackend.user);
  async function api(path,options={}){
    if(!hasSession())throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});
    if(typeof window.bfgApi==='function')return window.bfgApi('/api/equipment'+path,options);
    const expectedStatus=Number(options.expectedStatus)||null,requestOptions={...options};delete requestOptions.expectedStatus;
    const headers={'Content-Type':'application/json',...(requestOptions.headers||{})};
    const method=String(requestOptions.method||'GET').toUpperCase();
    if(!['GET','HEAD','OPTIONS'].includes(method)){
      const csrf=String(document.cookie||'').split(';').map(part=>part.trim()).find(part=>part.startsWith('bfg_csrf='));
      if(csrf)headers['x-csrf-token']=decodeURIComponent(csrf.slice('bfg_csrf='.length));
    }
    const response=await fetch('/api/equipment'+path,{...requestOptions,headers,credentials:'same-origin'});
    const payload=await response.json().catch(()=>({}));
    if(!response.ok){throw Object.assign(new Error(payload.error||`HTTP ${response.status}`),{status:response.status,payload});}
    if(expectedStatus&&response.status!==expectedStatus)throw Object.assign(new Error('UNEXPECTED_RESPONSE_STATUS'),{status:response.status,payload:{...payload,error:'UNEXPECTED_RESPONSE_STATUS'}});
    return expectedStatus?{...payload,httpStatus:response.status}:payload;
  }

  const remote={
    source:'postgresql',
    feature:()=>api('/feature'),
    filters:()=>api('/filters'),
    list:query=>api('/?'+new URLSearchParams(Object.entries(query||{}).filter(([,value])=>value!==''&&value!=null))),
    tree:query=>api('/tree?'+new URLSearchParams(Object.entries(query||{}).filter(([,value])=>value!==''&&value!=null))),
    get:id=>api('/'+encodeURIComponent(id)),
    create:data=>api('/',{method:'POST',body:JSON.stringify(data)}),
    update:(id,data)=>api('/'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify(data)}),
    move:(id,data)=>api('/'+encodeURIComponent(id)+'/move',{method:'POST',body:JSON.stringify(data)}),
    remove:(id,reason,rowVersion)=>api('/'+encodeURIComponent(id),{
      method:'DELETE',body:JSON.stringify({reason,rowVersion})
    }),
    structure:(id,options={})=>{
      const query=new URLSearchParams();
      if(options.includeArchived)query.set('includeArchived','true');
      if(options.depth!=null)query.set('depth',String(options.depth));
      const params=query.toString();
      return api('/'+encodeURIComponent(id)+'/structure'+(params?'?'+params:''));
    },
    structureCreate:data=>api('/',{method:'POST',body:JSON.stringify(data),expectedStatus:201}),
    structureUpdate:(id,data)=>api('/'+encodeURIComponent(id),{method:'PATCH',body:JSON.stringify(data),expectedStatus:200}),
    structureMove:(id,data)=>api('/'+encodeURIComponent(id)+'/move',{method:'POST',body:JSON.stringify(data)}),
    structureArchive:(id,reason,rowVersion)=>api('/'+encodeURIComponent(id),{
      method:'DELETE',body:JSON.stringify({reason,rowVersion}),expectedStatus:200
    }),
    structureRestore:(id,data)=>api('/'+encodeURIComponent(id)+'/restore',{method:'POST',body:JSON.stringify(data),expectedStatus:200}),
    structureAdvisor:(id,data)=>api('/'+encodeURIComponent(id)+'/structure/advisor',{method:'POST',body:JSON.stringify(data)}),
    structureReview:(id,stage,data)=>api('/'+encodeURIComponent(id)+'/structure/review/'+stage,{method:'POST',body:JSON.stringify(data)}),
    spares:(id,options={})=>api('/'+encodeURIComponent(id)+'/spares'+(options.includeArchived?'?includeArchived=true':'')),
    spareLink:(id,data)=>api('/'+encodeURIComponent(id)+'/spares',{method:'POST',body:JSON.stringify(data),expectedStatus:201}),
    spareUpdate:(id,itemId,data)=>api('/'+encodeURIComponent(id)+'/spares/'+encodeURIComponent(itemId),{method:'PATCH',body:JSON.stringify(data),expectedStatus:200}),
    spareArchive:(id,itemId,reason,rowVersion,targetId)=>api('/'+encodeURIComponent(id)+'/spares/'+encodeURIComponent(itemId),{
      method:'DELETE',body:JSON.stringify({reason,rowVersion,targetId}),expectedStatus:200
    }),
    spareRestore:(id,itemId,data)=>api('/'+encodeURIComponent(id)+'/spares/'+encodeURIComponent(itemId)+'/restore',{method:'POST',body:JSON.stringify(data),expectedStatus:200}),
    sparesSuggestions:id=>api('/'+encodeURIComponent(id)+'/spares/suggestions',{method:'POST',body:'{}'}),
    inventoryItems:q=>api('/inventory-items?'+new URLSearchParams(q?{q}:{})),
    actionConfirm:id=>api('/actions/drafts/'+encodeURIComponent(id)+'/confirm',{method:'POST',body:'{}'}),
    actionExecute:(id,data)=>api('/actions/drafts/'+encodeURIComponent(id)+'/execute',{method:'POST',body:JSON.stringify(data)}),
    actionReject:id=>api('/actions/drafts/'+encodeURIComponent(id)+'/reject',{method:'POST',body:'{}'})
  };
  const unavailable={
    source:'server-required',
    async feature(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async filters(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async list(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async tree(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async get(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async create(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async update(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async move(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async remove(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async structure(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async structureCreate(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async structureUpdate(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async structureMove(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async structureArchive(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async structureRestore(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async structureAdvisor(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async structureReview(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async spares(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async spareLink(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async spareUpdate(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async spareArchive(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async spareRestore(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async sparesSuggestions(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async inventoryItems(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async actionConfirm(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async actionExecute(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});},
    async actionReject(){throw Object.assign(new Error('SERVER_REQUIRED'),{status:503});}
  };
  window.EquipmentRepository={
    mode:hasSession()?'postgresql':'server-required',
    current(){return hasSession()?remote:unavailable;},
    remote
  };
})();
