/* Comprehensive Equipment Registry and digital dossier. The legacy tree is intentionally not exposed. */
(function(){
  'use strict';

  const STORAGE_KEY='bfg_equipment_ui_state_v2';
  const DEFAULT_COLUMNS=['code','name','factory','location','category','model','maker','status','crit','health','lastPm','nextPm','openWo','cost'];
  const COLUMNS={code:'کد تجهیز',name:'نام تجهیز',factory:'کارخانه',location:'محل',category:'دسته',model:'مدل',maker:'سازنده',status:'وضعیت',crit:'بحرانیت',health:'سلامت',lastPm:'آخرین PM',nextPm:'PM بعدی',openWo:'WO باز',cost:'هزینه نت'};
  const DETAIL_TABS=[
    ['technical','مشخصه فنی'],['structure','ساختار تجهیز'],['spares','قطعات یدکی حیاتی'],
    ['maintenance','برنامه نگهداری'],['history','سوابق'],['calibration','کالیبراسیون'],
    ['instructions','دستورالعمل‌ها'],['documents','اسناد و فایل‌ها'],['transactions','تراکنش‌ها'],
    ['monitoring','پایش تجهیز'],['risk','ریسک و فرصت']
  ];

  const saved=readState();
  const E=window.EQV2={
    view:'list',page:saved.page||1,limit:50,q:saved.q||'',factoryId:saved.factoryId||'',categoryId:saved.categoryId||'',
    status:saved.status||'',criticality:saved.criticality||'',sort:saved.sort||'sortOrder',direction:saved.direction||'asc',
    selected:saved.selected||null,columns:Array.isArray(saved.columns)&&saved.columns.length?saved.columns:DEFAULT_COLUMNS,
    scroll:{list:saved.listScroll||0,window:saved.windowScroll||0},
    tab:'technical',detail:false,detailKey:null,detailId:null,rows:[],pagination:null,
    options:{factories:[],categories:[],locations:[],responsibleUsers:[]},routeBusy:false,
    intakeReturn:null,wizard:null,
    structure:null,structurePanel:[],structureFocus:null,structureSelected:null,structureQuery:'',structureArchived:false,structureLoading:false,
    structureExpanded:{},structureBulkLoading:false,structureBulkNotice:null,structureBulkError:null,structureNodeLoadingId:null,structureNodeLoadError:null,
    structureDrawerView:null,structureInventoryResults:[],structureInventoryTimer:null,structureInventoryRequestId:0,
    structureError:null,structureSuggestNotice:null,structurePendingReject:null,inventoryOptions:[],
    spares:null,sparesError:null,sparesLoading:false,sparesArchived:false,sparesItemResults:[],sparesSearching:false,
    sparesSuggestions:[],sparesSuggestNotice:null,sparesSuggesting:false,sparesPendingReject:null,sparesSuggestBusy:null,
    passport:null,passportError:null,passportLoading:false,batchPrintBusy:false
  };

  // The legacy shell declares MENU with `const`, so it is not available as window.MENU.
  // Update only the existing Equipment entry to make this in-place upgrade visible.
  try{
    const equipmentMenu=typeof MENU!=='undefined'&&Array.isArray(MENU)?MENU.find(item=>item?.id==='equipment'||item?.id==='tree'):null;
    if(equipmentMenu){equipmentMenu.id='equipment';equipmentMenu.t='فهرست جامع تجهیزات';equipmentMenu.ic='⚙️';}
    if(typeof ME!=='undefined'&&ME&&typeof buildMenu==='function')buildMenu();
  }catch(error){console.warn('Equipment menu label was not updated',error);}

  const R=()=>EquipmentRepository.current();
  const canDo=operation=>typeof can!=='function'||can('equipment',operation==='move'?'edit':operation);
  const escText=value=>typeof esc==='function'?esc(value):String(value??'').replace(/[&<>\"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
  const faText=value=>typeof fa==='function'?fa(value):String(value??'');
  const formatDate=value=>value&&typeof jDate==='function'?jDate(value):(value||'—');
  const formatDateTime=value=>value&&typeof jDateTime==='function'?jDateTime(value):(value||'—');
  const statusInfo=a=>typeof AS_ST!=='undefined'&&AS_ST[a.status]?AS_ST[a.status]:[a.status||'—','b-gray'];
  const empty=text=>`<div class="eqv2-empty"><div><i>—</i><div>${escText(text)}</div></div></div>`;
  const structureDrawerController=window.BFGStructureDrawerController&&window.BFGStructureDrawerController.create({
    confirmDiscard:()=>window.confirm('تغییرهای فرم ذخیره نشده‌اند. بدون ذخیره ببندم؟'),
    onStateChange:structureDrawerStateChanged,
    onClose:destroyStructureDrawerView,
    onSaveError:error=>{if(typeof console!=='undefined')console.warn('Equipment structure save failed',error&&error.code||error&&error.message||'request_failed');},
    onSaveSuccess:structureDrawerSaved
  });

  function readState(){try{return JSON.parse(sessionStorage.getItem(STORAGE_KEY)||'{}');}catch(_){return{};}}
  function saveState(){
    try{sessionStorage.setItem(STORAGE_KEY,JSON.stringify({page:E.page,q:E.q,factoryId:E.factoryId,categoryId:E.categoryId,status:E.status,criticality:E.criticality,sort:E.sort,direction:E.direction,selected:E.selected,columns:E.columns,listScroll:E.scroll.list,windowScroll:E.scroll.window}));}catch(_){}
  }
  function captureExplorerState(){
    E.scroll.window=window.scrollY||0;
    const scroller=document.querySelector('.eqv2-table-wrap');
    E.scroll.list=scroller?.scrollTop||0;
    saveState();
  }
  function restoreExplorerScroll(){
    requestAnimationFrame(()=>{
      const scroller=document.querySelector('.eqv2-table-wrap');
      if(scroller)scroller.scrollTop=E.scroll.list||0;
      window.scrollTo(0,E.scroll.window||0);
    });
  }

  function sourceBadge(){const source=R().source;const label=source==='postgresql'?'PostgreSQL · منبع حقیقت':'اتصال به سرور مرکزی لازم است';return`<span class="eqv2-source ${source==='postgresql'?'':'local'}">${label}</span>`;}
  function shell(){
    return`<div class="eqv2" id="eqv2Explorer"><div class="eqv2-head"><div class="eqv2-title"><small>دارایی‌ها › تجهیزات <span class="eqv2-version">Registry 3.0</span></small><h2>فهرست جامع تجهیزات</h2><p class="eqv2-subtitle">تمام تجهیزات ثبت‌شده در یک فهرست واحد؛ برای مشاهده پرونده دیجیتال، تجهیز را انتخاب کنید.</p></div>${sourceBadge()}${canDo('view')?'<button class="btn btn-sm btn-ghost" onclick="eqv2OpenIntake()">ورود هوشمند</button>':''}${canDo('create')?'<button class="btn btn-sm btn-primary" onclick="eqv2Create()">＋ افزودن تجهیز</button>':''}</div>${toolbar()}<div class="eqv2-layout eqv2-list-only"><section class="eqv2-main"><div class="eqv2-loading">در حال دریافت فهرست تجهیزات…</div></section></div></div>`;
  }
  function toolbar(){
    const factories=E.options.factories.map(x=>`<option value="${escText(x.id)}" ${E.factoryId===x.id?'selected':''}>${escText(x.name)}</option>`).join('');
    const categories=E.options.categories.filter(x=>!E.factoryId||x.factory_id===E.factoryId).map(x=>`<option value="${escText(x.id)}" ${E.categoryId===x.id?'selected':''}>${escText(x.name)}</option>`).join('');
    return`<div class="eqv2-toolbar"><div class="eqv2-search"><span>⌕</span><input value="${escText(E.q)}" placeholder="کد، نام، سریال، مدل یا سازنده…" oninput="eqv2Search(this.value)"></div><select aria-label="کارخانه" onchange="eqv2Filter('factoryId',this.value)"><option value="">همه کارخانه‌ها</option>${factories}</select><select aria-label="دسته" onchange="eqv2Filter('categoryId',this.value)"><option value="">همه دسته‌ها</option>${categories}</select><select aria-label="وضعیت" onchange="eqv2Filter('status',this.value)"><option value="">همه وضعیت‌ها</option>${Object.entries(typeof AS_ST==='undefined'?{}:AS_ST).map(([key,value])=>`<option value="${key}" ${E.status===key?'selected':''}>${value[0]}</option>`).join('')}</select><select aria-label="بحرانیت" onchange="eqv2Filter('criticality',this.value)"><option value="">همه بحرانیت‌ها</option>${['A','B','C'].map(x=>`<option ${E.criticality===x?'selected':''}>${x}</option>`).join('')}</select><button class="btn btn-sm btn-ghost" onclick="eqv2Columns()">ستون‌ها</button><button class="btn btn-sm btn-ghost" onclick="eqv2Export()">↓ Excel</button><button class="btn btn-sm btn-ghost" onclick="eqv2BatchPrintModal()">🖨 چاپ گروهی شناسنامه</button></div>`;
  }

  function equipmentModuleAllowed(){return !window.BFGModules||typeof window.BFGModules.allows!=='function'||window.BFGModules.allows('equipment');}
  function page(){
    E.detail=false;E.detailKey=null;E.detailId=null;
    if(!equipmentModuleAllowed())return head('فهرست تجهیزات','ماژول غیرفعال')+'<div class="card empty">ماژول تجهیزات غیرفعال است.</div>';
    if(location.pathname.startsWith('/equipment/'))history.replaceState({equipmentExplorer:true},'','/');
    if(typeof can==='function'&&!can('equipment','view'))return head('فهرست تجهیزات','دسترسی محدود')+'<div class="card empty">اجازه مشاهده تجهیزات را ندارید.</div>';
    setTimeout(()=>initExplorer(true),0);return shell();
  }
  async function initExplorer(restore=false){
    try{
      await R().feature();
      const filters=R().filters?await R().filters():{factories:[],categories:[]};E.options=filters;
      const root=document.getElementById('eqv2Explorer');if(root){const old=root.querySelector('.eqv2-toolbar');if(old)old.outerHTML=toolbar();}
      await load();if(restore)restoreExplorerScroll();
    }catch(error){showError(error);}
  }
  async function load(){E.view='list';const main=document.querySelector('.eqv2-main');if(!main)return;main.innerHTML='<div class="eqv2-loading">در حال بارگذاری…</div>';await loadList();saveState();}

  const valueFor=(a,key)=>({code:a.code,name:a.name,factory:a.factory_name,location:a.location_name,category:a.category_name,model:a.model,maker:a.maker,status:a.status,crit:a.crit,health:a.health_score,lastPm:a.last_run,nextPm:a.next_pm,openWo:a.open_wo,cost:a.maintenance_cost})[key];
  function cell(a,key){const value=valueFor(a,key);if(key==='code')return`<span class="eqv2-code">${escText(value||'—')}</span>`;if(key==='name')return`<b>${escText(value||'—')}</b><div class="muted" style="font-size:9px">${escText(a.cls||'')}</div>`;if(key==='status'){const s=statusInfo(a);return`<span class="badge ${s[1]}"><span class="dot"></span>${escText(s[0])}</span>`;}if(key==='health')return value==null?'<span class="eqv2-na">داده کافی نیست</span>':`<b>${faText(Math.round(value))}</b>/۱۰۰`;if(key==='lastPm'||key==='nextPm')return value?formatDate(value):'<span class="eqv2-na">—</span>';if(key==='openWo')return value?`<span class="badge b-orange">${faText(value)}</span>`:'۰';if(key==='cost')return value==null?'<span class="eqv2-na">N/A</span>':money(value);return escText(value??'—');}
  const sortKey=key=>({crit:'criticality',factory:'name',location:'name',category:'name',maker:'name',model:'name',health:'name',lastPm:'updatedAt',nextPm:'updatedAt',openWo:'updatedAt',cost:'updatedAt'}[key]||key);
  async function loadList(){
    const result=await R().list(E);E.rows=result.data;E.pagination=result.pagination;
    document.querySelector('.eqv2-main').innerHTML=`<div class="eqv2-card-head"><b>فهرست جامع تجهیزات</b><span class="muted">${faText(result.pagination.total)} تجهیز · انتخاب هر ردیف = پرونده دیجیتال</span></div><div class="eqv2-table-wrap"><table><thead><tr>${E.columns.map(key=>`<th onclick="eqv2Sort('${key}')">${COLUMNS[key]} ${sortKey(key)===E.sort?(E.direction==='asc'?'↑':'↓'):''}</th>`).join('')}<th class="eqv2-open-col">پرونده</th></tr></thead><tbody>${result.data.map(a=>`<tr data-equipment-detail="${escText(a.id)}" class="${E.selected===a.id?'sel':''}" tabindex="0" onclick="eqv2OpenDetail('${escText(a.id)}')" onkeydown="if(event.key==='Enter'||event.key===' '){event.preventDefault();eqv2OpenDetail('${escText(a.id)}')}" title="بازکردن پرونده دیجیتال تجهیز">${E.columns.map(key=>`<td>${cell(a,key)}</td>`).join('')}<td class="eqv2-open-col"><button type="button" class="eqv2-open-dossier" aria-label="بازکردن پرونده ${escText(a.name)}">پرونده دیجیتال ←</button></td></tr>`).join('')||`<tr><td colspan="${E.columns.length+1}" class="empty">تجهیزی یافت نشد</td></tr>`}</tbody></table></div>${pager(result.pagination)}`;
  }
  function pager(p){return`<div class="eqv2-pager"><button class="btn btn-sm btn-ghost" ${p.page<=1?'disabled':''} onclick="eqv2Page(${p.page-1})">قبلی</button><span>صفحه ${faText(p.page)} از ${faText(p.pages)} · ${faText(p.total)} رکورد</span><button class="btn btn-sm btn-ghost" ${p.page>=p.pages?'disabled':''} onclick="eqv2Page(${p.page+1})">بعدی</button></div>`;}
  function icon(a){const kind=a?.ext?.nodeKind||a?.nodeKind||a?.type;return kind==='factory'||kind==='site'?'🏭':kind==='location'||kind==='unit'?'📍':'⚙️';}


  async function select(id,resetTab=true){
    if(E.selected!==id&&resetTab)E.tab='technical';E.selected=id;saveState();
    document.querySelectorAll('.eqv2 tbody tr').forEach(x=>x.classList.remove('sel'));
    document.querySelector(`[data-equipment-detail="${CSS.escape(id)}"]`)?.classList.add('sel');
    try{const {data:a}=await R().get(id),panel=document.getElementById('eqv2Summary');if(panel)panel.innerHTML=summary(a);}catch(error){showError(error);}
  }
  function summary(a){const s=statusInfo(a);return`<div class="eqv2-card-head"><b>خلاصه تجهیز</b><button class="btn btn-sm btn-ghost" onclick="eqv2CloseSummary()">×</button></div><div class="eqv2-dossier-in"><div class="eqv2-asset-hero"><div class="eqv2-asset-icon">${icon(a)}</div><div><h3>${escText(a.name)}</h3><small>${escText(a.code)}</small><span class="badge ${s[1]}">${escText(s[0])}</span></div></div>${[['کارخانه',a.factory_name],['دسته',a.category_name],['محل',a.location_name],['مدل',a.model],['بحرانیت',a.crit],['WO باز',faText(a.open_wo||0)]].map(([k,v])=>`<div class="eqv2-kv"><span>${k}</span><b>${escText(v??'—')}</b></div>`).join('')}<button class="btn btn-primary btn-block" style="margin-top:12px" onclick="eqv2OpenDetail('${escText(a.id)}')">بازکردن پرونده کامل</button><div class="muted" style="text-align:center;margin-top:7px">برای بازکردن پرونده، ردیف تجهیز را انتخاب کنید.</div></div>`;}

  function detailHeader(a){
    const s=statusInfo(a),tab=E.tab||'technical';
    return`<header class="eqv2-detail-header eqv2-compact-header">
      <button class="btn btn-ghost eqv2-back" onclick="eqv2BackToEquipment()">← فهرست تجهیزات</button>
      <div class="eqv2-detail-identity">
        <div class="eqv2-header-primary"><span class="eqv2-code">${escText(a.code||'—')}</span><h1>${escText(a.name||'—')}</h1></div>
        <div class="eqv2-header-meta"><span class="badge ${s[1]}">${escText(s[0])}</span>
          <span>${escText(a.factory_name||'کارخانه ثبت نشده')}</span><span>${escText(a.location_name||'محل ثبت نشده')}</span>
          <span>${escText(a.category_name||'دسته ثبت نشده')}</span>
          ${a.responsible_name?`<span>مسئول: ${escText(a.responsible_name)}</span>`:''}
        </div>
      </div>
      <div class="eqv2-detail-actions">
        ${canDo('create')?`<button class="btn btn-sm btn-primary" onclick="eqv2Related('wo','${escText(a.id)}')">＋ دستورکار</button><button class="btn btn-sm btn-ghost" onclick="eqv2Related('request','${escText(a.id)}')">＋ درخواست</button><button class="btn btn-sm btn-ghost" onclick="eqv2Related('pm','${escText(a.id)}')">＋ PM</button>`:''}
        ${canDo('view')?`<button class="btn btn-sm btn-ghost" onclick="eqv2OpenIntake('${escText(a.id)}')">ورود هوشمند</button>`:''}
        ${canDo('view')?`<button class="btn btn-sm btn-ghost" onclick="eqv2QrModal('${escText(a.id)}')" title="QR پرونده دیجیتال تجهیز">▦ QR تجهیز</button><button class="btn btn-sm btn-ghost" onclick="eqv2OpenPassport('${escText(a.code||a.id)}')" title="شناسنامه چاپی در مسیر مستقل /passport">📄 شناسنامه</button><button class="btn btn-sm btn-ghost" onclick="eqv2PrintIdentity('${escText(a.id)}')" title="شناسنامه چاپی A4 از دادهٔ واقعی پرونده">🖨 چاپ شناسنامه</button>`:''}
        ${canDo('edit')?`<button class="btn btn-sm btn-ghost" onclick="eqv2OpenWizard('${escText(a.id)}','initial','${escText(tab)}')">✎ ویرایش</button>`:''}
        ${canDo('delete')?`<button class="btn btn-sm btn-danger" onclick="eqv2Delete('${escText(a.id)}')">بایگانی</button>`:''}
      </div>
    </header>`;
  }
  function breadcrumb(a){
    const path=a.path||[];
    if(!path.length)return'';
    return`<div class="eqv2-breadcrumb" aria-label="مسیر ساختاری این تجهیز">${path.map((item,index)=>`<span class="${index===path.length-1?'current':''}">${escText((item.code?item.code+' — ':'')+item.name)}</span>`).join('<i aria-hidden="true">›</i>')}</div>`;
  }
  function detailPage(a){
    return`<div class="eqv2 eqv2-detail-page" id="eqv2Detail" data-equipment-id="${escText(a.id)}">${detailHeader(a)}${breadcrumb(a)}
      <div class="eqv2-detail-tabs" role="tablist" aria-label="بخش‌های پرونده تجهیز">${DETAIL_TABS.map(([key,label])=>`<button role="tab" aria-selected="${E.tab===key}" class="${E.tab===key?'on':''}" onclick="eqv2DetailTab('${key}')">${label}</button>`).join('')}</div>
      <main class="eqv2-detail-body" id="eqv2DetailBody">${detailBody(a)}</main>
    </div>`;
  }
  function cards(rows){return`<div class="eqv2-detail-grid">${rows.map(([key,value])=>`<div class="eqv2-info-card"><span>${escText(key)}</span><b>${value==null||value===''?'—':value}</b></div>`).join('')}</div>`;}
  function rowsList(rows,render,none){return rows?.length?`<div class="eqv2-record-list">${rows.map(render).join('')}</div>`:empty(none);}
  function woRow(w){return`<article class="clickable" onclick="typeof openWO==='function'&&openWO('${escText(w.id)}')"><div><b>${escText(w.no||'بدون شماره')}</b><span class="muted">${formatDate(w.created_at||w.createdAt)}</span></div><p>${escText(w.descr||w.desc||'بدون شرح')}</p><span class="badge b-gray">${escText(w.status||'—')}</span><span class="eqv2-go">مشاهده، ویرایش یا بایگانی ←</span></article>`;}
  function healthExplanation(a){const health=a.ext?.operationalHealth;if(!health)return'';if(health.score==null)return`<section class="eqv2-health-evidence"><div><b>شاخص سلامت تجهیز</b><span class="badge b-gray">N/A — داده ناکافی</span></div><p>${escText(health.reason||'داده کافی برای محاسبه وجود ندارد.')}</p></section>`;const badge=health.score>=80?'b-green':health.score>=60?'b-blue':health.score>=40?'b-orange':'b-red';return`<section class="eqv2-health-evidence"><div><b>شاخص سلامت قطعی</b><span class="badge ${badge}">${faText(health.score)} از ۱۰۰ · ${faText(health.coverage)} عامل معتبر</span></div><div class="eqv2-health-factors">${(health.evidence||[]).map(factor=>`<article><span>${escText(factor.label)}</span><b>${faText(Math.round(factor.value))}٪</b><small>${escText(factor.evidence)}</small></article>`).join('')}</div><p>این امتیاز توسط موتور قواعد از داده‌های ثبت‌شده محاسبه شده است؛ تشخیص AI مولد محسوب نمی‌شود.</p></section>`;}
  const notRecorded='<span class="eqv2-na">ثبت نشده</span>';
  function detailBody(a){
    const ext=a.ext||{},workOrders=a.work_orders||[],completed=a.maintenance_history||[],plans=a.pm_plans||[];
    const executions=a.checklist_executions||[],failures=a.failures||[];
    if(E.tab==='technical'){
      const rows=[
        ['کد تجهیز',escText(a.code)],['نام تجهیز',escText(a.name)],['کارخانه',a.factory_name?escText(a.factory_name):notRecorded],
        ['دسته',a.category_name?escText(a.category_name):notRecorded],['محل استقرار',escText(ext.locationDescription||a.location_name)],
        ['نوع فعالیت',escText(a.activity_type)],['کلاس',escText(a.cls)],['وضعیت فنی',escText(a.status)],
        ['وضعیت بهره‌برداری',escText(a.operational_status)],['بحرانیت',escText(a.crit)],['سازنده',escText(a.maker)],
        ['کشور سازنده',escText(a.manufacturer_country)],['مدل',escText(a.model)],['سریال',escText(a.serial)],
        ['سال ساخت',escText(a.year)],['تاریخ نصب',a.install_date||a.install?formatDate(a.install_date||a.install):notRecorded],
        ['توان',escText(a.power)],['ظرفیت',escText(ext.capacity)],['مسئول تجهیز',escText(a.responsible_name)],
        ['شرح عملکرد',escText(ext.description)],['مشخصات فنی',escText(ext.technicalSpecification)],
        ['تابلو برق',escText(ext.panelCode)],['نوع مبرد',escText(ext.refrigerant)],
        ['کارکرد روزانه',ext.dailyOperatingHours==null?notRecorded:faText(ext.dailyOperatingHours)+' ساعت'],
        ['امتیاز بحرانی',ext.criticalityScore==null?notRecorded:faText(ext.criticalityScore)+' از ۱۰۰'],
        ['ملاحظات عمومی',escText(a.general_notes)]
      ];
      return`<section class="eqv2-section-heading"><div><span>پرونده دیجیتال تجهیز</span><h2>مشخصه فنی</h2><p>مقادیر از رجیستری PostgreSQL و فیلدهای موجود ext خوانده می‌شوند؛ مقدار ثبت‌نشده حدس زده نمی‌شود.</p></div>${canDo('edit')?`<button class="btn btn-sm btn-primary" onclick="eqv2OpenWizard('${escText(a.id)}','initial','technical')">ویرایش مشخصه فنی</button>`:''}</section>${cards(rows)}`;
    }
    if(E.tab==='structure'){return structureSection(a);}
    if(E.tab==='spares'){return sparesSection(a);}
    if(E.tab==='maintenance'){
      const plansHtml=plans.length?`<div class="eqv2-record-list">${plans.map(plan=>`<article><div><b>${escText((plan.code?plan.code+' — ':'')+(plan.title||'برنامه PM'))}</b><span>${plan.interval_days?faText(plan.interval_days)+' روز':notRecorded}</span></div><p>مسئول: ${escText(plan.owner_role)} · آخرین اجرا: ${plan.last_run?formatDate(plan.last_run):notRecorded} · وضعیت: ${escText(plan.status)}</p>${Array.isArray(plan.checklist)&&plan.checklist.length?`<ul class="eqv2-checklist">${plan.checklist.map(item=>`<li>${escText(typeof item==='string'?item:(item.title||item.text||item.label||''))}</li>`).join('')}</ul>`:''}</article>`).join('')}</div>`:empty('برنامه PM ثبت نشده است.');
      const daily=Array.isArray(ext.dailyInspection)?ext.dailyInspection:[];
      const checklist=daily.length?`<section class="eqv2-subsection"><h3>بازرسی‌های ثبت‌شده در پرونده قدیمی</h3><ul class="eqv2-checklist">${daily.map(item=>`<li>${escText(typeof item==='string'?item:(item.title||item.text||item.label||''))}</li>`).join('')}</ul></section>`:'';
      return`<section class="eqv2-section-heading"><div><span>برنامه‌های واقعی maintenance-service</span><h2>برنامه نگهداری</h2><p>PM و چک‌لیستِ تعریف‌شده نگه داشته می‌شوند؛ اجراهای واقعی در بخش سوابق می‌آیند.</p></div><div class="eqv2-section-actions">${canDo('edit')?`<button class="btn btn-sm btn-ghost" onclick="eqv2OpenWizard('${escText(a.id)}','maintenance','maintenance')">بازبینی در ویزارد تجهیز</button>`:''}${canDo('create')?`<button class="btn btn-sm btn-primary" onclick="eqv2Related('pm','${escText(a.id)}')">＋ برنامه PM</button>`:''}</div></section>${plansHtml}${checklist}`;
    }
    if(E.tab==='history'){
      const woHtml=completed.length?`<section class="eqv2-subsection"><h3>دستورکارهای تکمیل‌شده</h3><div class="eqv2-record-list">${completed.map(woRow).join('')}</div></section>`:'';
      const failureHtml=failures.length?`<section class="eqv2-subsection"><h3>سوابق خرابی ثبت‌شده</h3><div class="eqv2-record-list">${failures.map(failure=>`<article><div><b>${escText(failure.failure_no||failure.id)}</b><span>${formatDate(failure.occurred_at)}</span></div><p>${escText(failure.description||failure.condition||'شرح ثبت نشده')} · ${escText(failure.status||'')}</p>${failure.cause?`<p>علت ثبت‌شده: ${escText(failure.cause)}</p>`:''}</article>`).join('')}</div></section>`:'';
      const executionHtml=executions.length?`<section class="eqv2-subsection"><h3>اجراهای چک‌لیست</h3><div class="eqv2-record-list">${executions.map(run=>`<article><div><b>${escText(run.template_title||'اجرای چک‌لیست')}</b><span>${formatDateTime(run.completed_at||run.started_at)}</span></div><p>وضعیت: ${escText(run.overall_status||run.status||'ثبت نشده')} · منشأ داده: ${escText(run.provenance_status||'ثبت نشده')}</p>${Array.isArray(run.answers)&&run.answers.length?`<details><summary>پاسخ‌ها (${faText(run.answers.length)})</summary><ul class="eqv2-checklist">${run.answers.map(answer=>`<li>${escText(answer.item_key)}: ${escText(answer.result||answer.value_text||answer.value_numeric||'ثبت نشده')}${answer.note?` — ${escText(answer.note)}`:''}</li>`).join('')}</ul></details>`:''}</article>`).join('')}</div></section>`:'';
      const historyRows=(a.movements||[]).map(item=>`<article><div><b>${formatDateTime(item.t||item.at)}</b><span>${escText(item.label||'تغییر ثبت‌شده')}</span></div><p>${escText(item.x||item.note||item.summary||'')}</p></article>`);
      const movementHtml=historyRows.length?`<section class="eqv2-subsection"><h3>تاریخچه و جابه‌جایی ثبت‌شده</h3><div class="eqv2-record-list">${historyRows.join('')}</div></section>`:'';
      return`${woHtml}${failureHtml}${executionHtml}${movementHtml}`||empty('سابقه تعمیر، خرابی، اجرای چک‌لیست یا تغییر ثبت نشده است.');
    }
    if(E.tab==='calibration'){
      const instruments=a.calibration_instruments||[];
      return`<section class="eqv2-section-heading"><div><span>ابزارهای مرتبط واقعی</span><h2>کالیبراسیون</h2><p>گردش و سوابقِ ثبت‌شدهٔ ابزارها نمایش داده می‌شود؛ تاریخچهٔ کالیبراسیون پیشرفته در فاز بعدی است.</p></div></section>${rowsList(instruments,item=>`<article><div><b>${escText(item.code||'')} — ${escText(item.name)}</b><span>${escText(item.type||'')}</span></div><p>دوره: ${item.period_days==null?notRecorded:faText(item.period_days)+' روز'} · آخرین کالیبراسیون: ${item.last_cal?formatDate(item.last_cal):notRecorded} · کلاس: ${escText(item.cls)}</p></article>`,'ابزار کالیبراسیون مرتبط ثبت نشده است.')}`;
    }
    if(E.tab==='instructions'){
      const instructions=Array.isArray(a.instructions)?a.instructions:[];
      return`<section class="eqv2-section-heading"><div><span>محتوای موجود در پرونده</span><h2>دستورالعمل‌ها</h2><p>فقط دستورالعمل‌های واقعاً متصل به تجهیز نمایش داده می‌شوند.</p></div></section>${rowsList(instructions,item=>`<article><div><b>${escText(item.title||item.name||'دستورالعمل')}</b><span>${escText(item.code||item.version||'')}</span></div><p>${escText(item.summary||item.description||item.status||'')}</p></article>`,'دستورالعمل متصل از Backend ثبت نشده است.')}`;
    }
    if(E.tab==='documents'){
      const docs=Array.isArray(a.documents)?a.documents:[];
      return`<section class="eqv2-section-heading"><div><span>اسناد متصل به همین تجهیز</span><h2>اسناد و فایل‌ها</h2><p>فایل خام سلن ذخیره نمی‌شود؛ فقط پیوندهای واقعیِ ثبت‌شده نمایش داده می‌شوند.</p></div></section>${rowsList(docs,document=>`<article><div><b>${escText(document.title||document.name||'سند')}</b><span>${escText(document.code||document.fmt||document.format||'')}</span></div><p>${escText(document.status||document.version||'')}</p></article>`,'سند متصل از Backend ثبت نشده است.')}`;
    }
    if(E.tab==='transactions'){
      const requests=a.requests||[],parts=a.consumed_parts||[],costs=a.cost_entries||[],openOrders=workOrders.filter(item=>!['closed','cancel','done','completed'].includes(item.status));
      const sections=[];
      if(requests.length)sections.push(`<section class="eqv2-subsection"><h3>درخواست‌های مرتبط</h3><div class="eqv2-record-list">${requests.map(request=>`<article class="clickable" onclick="typeof openReq==='function'&&openReq('${escText(request.id)}')"><div><b>${escText(request.no||'درخواست')}</b><span>${formatDate(request.created_at)}</span></div><p>${escText(request.descr||'شرح ثبت نشده')}</p><span class="badge b-gray">${escText(request.status||'')}</span></article>`).join('')}</div></section>`);
      if(openOrders.length)sections.push(`<section class="eqv2-subsection"><h3>دستورکارهای باز (${faText(openOrders.length)})</h3><div class="eqv2-record-list">${openOrders.map(woRow).join('')}</div></section>`);
      if(parts.length)sections.push(`<section class="eqv2-subsection"><h3>قطعات مصرف‌شده</h3><div class="eqv2-record-list">${parts.map(part=>`<article><div><b>${escText(part.item_code)} — ${escText(part.item_name)}</b><span>${faText(part.qty)} ${escText(part.unit)}</span></div><p>دستورکار ${escText(part.wo_no||'—')} · ${formatDate(part.at)}</p></article>`).join('')}</div></section>`);
      if(costs.length)sections.push(`<section class="eqv2-subsection"><h3>هزینه‌های ثبت‌شده</h3><div class="eqv2-total">مجموع هزینهٔ قابل محاسبه از رکوردهای واقعی: <b>${money(costs.reduce((sum,row)=>sum+Number(row.amount||0),0))}</b></div><div class="eqv2-record-list">${costs.map(cost=>`<article><div><b>${escText(cost.wo_no||'دستورکار')}</b><span>${money(cost.amount)}</span></div><p>${formatDate(cost.at)}</p></article>`).join('')}</div></section>`);
      return sections.join('')||empty('تراکنش درخواست، دستورکار، قطعه یا هزینهٔ قابل انتساب ثبت نشده است.');
    }
    if(E.tab==='monitoring'){
      const health=a.health_score==null?notRecorded:`${faText(a.health_score)} از ۱۰۰`;
      const downtime=(a.downtimes||[]).filter(item=>Number.isFinite(Number(item.hours)));
      const reliabilityEnough=failures.length>=2&&downtime.length>=2&&Number(a.hours)>0;
      return`<section class="eqv2-section-heading"><div><span>دادهٔ مشاهده‌شده، بدون شاخص ساختگی</span><h2>پایش تجهیز</h2><p>شاخص‌های قابل محاسبه فقط با شواهد واقعی ارائه می‌شوند؛ در غیر این صورت «ثبت نشده» نمایش داده می‌شود.</p></div></section>${cards([
        ['شاخص سلامت ثبت‌شده',health],['وضعیت بهره‌برداری',escText(a.operational_status)],
        ['دستورکار باز',a.open_wo==null?notRecorded:faText(a.open_wo)],
        ['آخرین اجرای PM',a.last_run?formatDate(a.last_run):notRecorded],
        ['MTBF / MTTR / دسترس‌پذیری',reliabilityEnough?'محاسبهٔ مرحله‌ای در دسترس نیست':'N/A — شواهد زمانی کافی نیست']
      ])}`;
    }
    if(E.tab==='risk'){
      const risks=Array.isArray(ext.risks)?ext.risks:[];
      const opportunities=Array.isArray(ext.opportunities)?ext.opportunities:[];
      const causeItems=failures.filter(item=>item.cause||item.effect||item.risk_score!=null);
      const rcaRows=Array.isArray(a.rca)?a.rca.filter(item=>item.root_cause):[];
      const sections=[];
      if(risks.length)sections.push(`<section class="eqv2-subsection"><h3>ریسک‌های ثبت‌شده</h3><div class="eqv2-record-list">${risks.map(risk=>`<article><div><b>${escText(risk.title||risk.risk||risk)}</b><span>${escText(risk.level||risk.status||'')}</span></div><p>${escText(risk.control||risk.mitigation||'کنترل ثبت نشده')}</p></article>`).join('')}</div></section>`);
      if(opportunities.length)sections.push(`<section class="eqv2-subsection"><h3>فرصت‌های ثبت‌شده</h3><div class="eqv2-record-list">${opportunities.map(item=>`<article><div><b>${escText(item.title||item.opportunity||item)}</b><span>${escText(item.status||'')}</span></div><p>${escText(item.description||item.action||'')}</p></article>`).join('')}</div></section>`);
      if(causeItems.length)sections.push(`<section class="eqv2-subsection"><h3>علل و اثرهای ثبت‌شده در سوابق خرابی</h3><div class="eqv2-record-list">${causeItems.map(item=>`<article><div><b>${escText(item.failure_no||'خرابی')}</b><span>امتیاز ثبت‌شده: ${item.risk_score==null?notRecorded:faText(item.risk_score)}</span></div><p>علت: ${escText(item.cause)} · اثر: ${escText(item.effect)}</p></article>`).join('')}</div></section>`);
      if(rcaRows.length)sections.push(`<section class="eqv2-subsection"><h3>تحلیل علت ریشه‌ای ثبت‌شده در دستورکار</h3><div class="eqv2-record-list">${rcaRows.map(item=>`<article class="clickable" onclick="typeof openWO==='function'&&openWO('${escText(item.wo_id)}')"><div><b>${escText(item.wo_no||'دستورکار')}</b><span>${formatDate(item.at)}</span></div><p>علت ثبت‌شده: ${escText(item.root_cause)}</p>${item.action?`<p>اقدام اصلاحی ثبت‌شده: ${escText(item.action)}</p>`:''}<span class="eqv2-go">بازکردن دستورکار ←</span></article>`).join('')}</div></section>`);
      return sections.join('')||empty('ریسک یا فرصت تأییدشده و متصل به این تجهیز ثبت نشده است.');
    }
    return empty('بخش پرونده در دسترس نیست.');
  }
  /* ---------- Phase 2: internal equipment structure (dossier-scoped only) ---------- */
  const STRUCTURE_CHILD_KINDS={equipment:['subsystem'],subsystem:['main-component'],'main-component':['sub-component'],'sub-component':[]};
  const STRUCTURE_KIND_LABEL={equipment:'تجهیز',subsystem:'زیرسیستم تجهیز','main-component':'قطعه اصلی زیرسیستم','sub-component':'زیرقطعه قطعه اصلی','sub-equipment':'زیرسیستم تجهیز'};
  const STRUCTURE_GUIDE='ساختار مجاز: تجهیز ← زیرسیستم تجهیز ← قطعه اصلی زیرسیستم ← زیرقطعه قطعه اصلی';
  const STRUCTURE_LEGACY_WARNING='رکورد Legacy با نوع و شناسه تاریخی حفظ شده و در این جایگاه به‌عنوان زیرسیستم نمایش داده می‌شود';
  const STRUCTURE_CONFLICT_WARNING='نوع Canonical از جایگاه محاسبه شده است؛ تعارض ذخیره‌شده برای بررسی گزارش شده است';
  const STRUCTURE_DEPTH_WARNING='عمق ساختار بیش از سه سطح است؛ رکورد حفظ شده و فقط گزارش می‌شود';
  const STRUCTURE_MESSAGES={
    INVENTORY_ITEM_REQUIRED:'برای افزودن به قطعات یدکی حیاتی، قلم موجود انبار را انتخاب کنید.',
    SPARE_RESTORE_REQUIRED:'اتصال این قلم بایگانی شده است. آن را از تب قطعات یدکی حیاتی بازیابی کنید.',

    STRUCTURE_PARENT_KIND_INVALID:'سطح انتخاب‌شده برای ثبت این بخش مجاز نیست.',
    SUBSYSTEM_REQUIRED:'برای افزودن قطعه اصلی، یک زیرسیستم تجهیز انتخاب کنید.',
    MAIN_COMPONENT_REQUIRED:'برای افزودن زیرقطعه، یک قطعه اصلی زیرسیستم انتخاب کنید.',
    NAME_REQUIRED:'واردکردن نام الزامی است.',
    IDEMPOTENCY_KEY_REQUIRED:'شناسه یکتای درخواست ساختار ساخته نشد؛ دوباره تلاش کنید.',
    IDEMPOTENCY_KEY_REUSED:'شناسه درخواست قبلاً برای اطلاعات دیگری مصرف شده است؛ دوباره ذخیره کنید.',
    DUPLICATE_REQUEST_PENDING:'درخواست هم‌زمان هنوز نهایی نشده است؛ چند لحظه بعد دوباره تلاش کنید.',
    UNEXPECTED_RESPONSE_STATUS:'پاسخ قطعی ثبت از سرور دریافت نشد؛ فرم باز مانده و اطلاعات حفظ شد.',
    NOT_COMMITTED:'سرور ثبت را تأیید نکرد؛ فرم باز مانده و اطلاعات حفظ شد.',
    EQUIPMENT_API_ERROR:'ثبت ساختار تجهیز انجام نشد؛ اتصال و گزارش سرور را بررسی کنید.',
    INVENTORY_ITEM_NOT_FOUND:'قلم انتخاب‌شده از اطلاعات مرجع انبار موجود نیست؛ فقط قلم موجود قابل اتصال است.',
    REQUIRED_QUANTITY_INVALID:'تعداد باید عددی مثبت یا صفر و در محدوده مجاز باشد.',
    VALIDATION_ERROR:'فیلدهای الزامی یا مقادیر واردشده معتبر نیستند.',
    CODE_REQUIRED:'کد یکتا برای قطعه اصلی زیرسیستم الزامی است.',
    ROW_VERSION_REQUIRED:'نسخه رکورد (row_version) لازم است؛ ساختار تجهیز را تازه‌سازی کنید.',
    MOVE_ENDPOINT_REQUIRED:'تغییر پیوند فقط از عملیات جابه‌جایی مجاز است.',
    NO_EDITABLE_FIELDS:'تغییری برای ذخیره وجود ندارد.',
    STRUCTURE_NODE_KIND_INVALID:'نوع بخش ساختار تجهیز معتبر نیست.',
    NODE_KIND_IMMUTABLE:'نوع ساختاری فقط‌خواندنی است و بر اساس جایگاه بخش تعیین می‌شود.',
    STRUCTURE_DEPTH_EXCEEDED:'ساختار داخلی حداکثر سه سطح دارد؛ این افزودن یا جابه‌جایی انجام نشد.',
    PARENT_OUTSIDE_ROOT_EQUIPMENT:'بخش انتخاب‌شده در ساختار همین تجهیز نیست.',
    TREE_CYCLE:'جابه‌جایی باعث ایجاد چرخه در ساختار می‌شود؛ انجام نشد.',
    DUPLICATE_CODE:'این کد ساختاری در محدوده تجهیز تکراری است.',
    HAS_ACTIVE_CHILDREN:'این بخش دارای بخش‌های فعال است؛ ابتدا وضعیت آن‌ها را مشخص کنید.',
    VERSION_CONFLICT:'رکورد هم‌زمان تغییر کرده است؛ ساختار تجهیز را تازه‌سازی کنید.',
    ARCHIVE_REASON_REQUIRED:'دلیل بایگانی الزامی است.',
    MOVE_REASON_REQUIRED:'دلیل جابه‌جایی الزامی است.',
    RESTORE_REASON_REQUIRED:'دلیل بازیابی الزامی است.',
    CROSS_EQUIPMENT_CONFIRMATION_REQUIRED:'جابه‌جایی بین دو تجهیز به تأیید صریح و مجوز ویژه نیاز دارد.',
    INVENTORY_ITEM_NOT_FOUND:'قلم اطلاعات مرجع انبار وجود ندارد؛ ایجاد خودکار انجام نمی‌شود.',
    PERMISSION_DENIED:'مجوز این عملیات ساختار تجهیز را ندارید.',
    EQUIPMENT_SCOPE_DENIED:'این تجهیز در محدوده دسترسی شما نیست.',
    PARENT_ARCHIVED:'بخش انتخاب‌شده بایگانی شده است؛ ابتدا آن را بازیابی کنید.',
    STRUCTURE_NODE_NOT_FOUND:'بخش ساختار تجهیز پیدا نشد.',
    EQUIPMENT_NOT_FOUND:'این تجهیز در پایگاه‌داده پیدا نشد؛ فهرست تجهیزات را تازه‌سازی کنید.',
    ROOT_EQUIPMENT_NOT_FOUND:'تجهیز انتخاب‌شده پیدا نشد؛ ساختار فقط در پرونده خود تجهیز باز می‌شود.',
    EQUIPMENT_ID_INVALID:'شناسهٔ تجهیز نامعتبر است؛ ساختار فقط با شناسهٔ واقعی رکورد باز می‌شود.',
    STRUCTURE_ROOT_CHANGED:'ساختار هم‌زمان تغییر کرده است؛ دوباره تازه‌سازی کنید.',
    STRUCTURE_DEPTH_INVALID:'سطح بارگذاری ساختار تجهیز معتبر نیست.',
    STRUCTURE_DEPTH_LIMIT_REACHED:'حد بیشینه عمق ساختار تجهیز رسیده است؛ برای ادامه با پشتیبانی تماس بگیرید.',
    STRUCTURE_LAZY_LOAD_STALLED:'بارگذاری سطوح ساختار تجهیز پیشروی نکرد؛ دوباره تازه‌سازی کنید.',
    STRUCTURE_FAILED:'ساختار تجهیز از سرور دریافت نشد؛ دوباره تلاش کنید.',
    SERVER_REQUIRED:'اتصال به سرور برقرار نیست؛ ساختار فقط از سرور خوانده می‌شود.',
    STRUCTURE_NODE_NOT_ARCHIVED:'این بخش بایگانی نشده است.',
    AI_PROVIDER_DISABLED_BY_POLICY:'سرویس تحلیل غیرفعال است؛ پیشنهاد سلن برای ساختار در دسترس نیست. فرم دستی کامل فعال است.',
    AI_PURPOSE_DENIED_BY_POLICY:'سیاست سرور پیشنهاد ساختار را مجاز نکرده است؛ فرم دستی فعال است.',
    CLOUD_CONTEXT_NOT_APPROVED:'ارسال متن به سرویس ابری تأیید نشده است؛ فرم دستی فعال است.',
    NO_CAPABLE_PROVIDER:'N/A — داده کافی برای پیشنهاد ساختار وجود ندارد',
    DRAFT_INCOMPLETE:'پیشنهاد ناقص است؛ فیلدهای لازم را کامل کنید.',
    DRAFT_CONFLICT:'تعارض پیشنهاد حل نشده است.',
    DRAFT_CLOSED:'این پیش‌نویس بسته شده است.',
    CONFIRMATION_REQUIRED:'تأیید کاربر پیش از ثبت الزامی است.',
    CONFIRMATION_EXPIRED:'مهلت تأیید تمام شده است؛ دوباره تأیید کنید.',
    DUPLICATE_REQUEST:'این عملیات قبلاً با همین شناسه انجام شده است.'
  };
  const structureSay=error=>{const code=error&&(error.payload&&error.payload.error||error.message);toast(STRUCTURE_MESSAGES[code]||('عملیات ساختار انجام نشد: '+(code||'REQUEST_FAILED')),1);};
  function structureAllowedChildren(kind,node){
    if(STRUCTURE_CHILD_KINDS[kind])return STRUCTURE_CHILD_KINDS[kind];
    // The equipment root level comes from the Backend, which knows the real record: a legacy
    // equipment row with an unexpected nodeKind value still accepts a subsystem.
    const st=E.structure;
    const isRoot=node?String(node.id)===String(st&&st.rootId):kind==='equipment';
    if(isRoot&&st&&Array.isArray(st.rootAllowedChildren)&&st.rootAllowedChildren.length)return st.rootAllowedChildren;
    return[];
  }
  function flattenStructure(nodes,out=[]){for(const node of nodes||[]){out.push(node);flattenStructure(node.children,out);}return out;}
  function structureNodeById(id){const st=E.structure;if(!st)return null;if(String(st.root&&st.root.id)===String(id))return {id:st.root.id,code:st.root.code,name:st.root.name,nodeKind:'equipment',rowVersion:st.root.rowVersion,children:st.nodes,path:[]};return flattenStructure(st.nodes).find(node=>String(node.id)===String(id))||null;}
  // The dossier is always keyed by the real PostgreSQL assets.id; the API field is
  // rootEquipmentId, so it is normalized here and never re-derived from a code or local cache.
  function normalizeStructure(id,payload){
    const data=payload&&typeof payload==='object'?payload:{};
    const rootId=data.rootEquipmentId||(data.root&&data.root.id)||id;
    return {...data,rootId,rootEquipmentId:rootId,nodes:Array.isArray(data.nodes)?data.nodes:[],
      capabilities:data.capabilities||{},suggestions:Array.isArray(data.suggestions)?data.suggestions:[],
      diagnostics:Array.isArray(data.diagnostics)?data.diagnostics:[]};
  }
  async function loadStructure(id,options={}){
    if(typeof R().structure!=='function'){E.structure=normalizeStructure(id,{error:'SERVER_REQUIRED'});if(E.tab==='structure')await renderCurrentDetail();return;}
    try{
      const requestOptions={includeArchived:E.structureArchived};
      if(options.depth!=null)requestOptions.depth=options.depth;
      const result=await R().structure(id,requestOptions);
      E.structure=normalizeStructure(id,result.data);E.structureError=null;
      if(E.structureSelected){const selected=structureNodeById(E.structureSelected);for(const step of selected?.path||[])if(step&&step.id)E.structureExpanded[step.id]=true;}
      if(!options.keepPanel)E.structurePanel=[];
      if(options.focus&&structureNodeById(options.focus))E.structureFocus=options.focus;
    }catch(error){
      E.structureError=(error.payload&&error.payload.error)||error.message||'STRUCTURE_FAILED';
      E.structure=normalizeStructure(id,{error:E.structureError});
    }
    if(E.tab==='structure')await renderCurrentDetail();
  }
  function queueStructureLoad(id){
    if(E.structureLoading)return;
    E.structureLoading=true;
    setTimeout(()=>{loadStructure(id,{depth:1}).finally(()=>{E.structureLoading=false;});},0);
  }
  function structureCrumb(){
    const st=E.structure;if(!st||!st.root)return'';
    const chain=[{id:st.root.id,name:st.root.name||st.root.code,nodeKind:'equipment'}];
    for(const nodeId of E.structurePanel||[]){const node=structureNodeById(nodeId);if(node)chain.push(node);}
    return`<nav class="eqv2-structure-crumbs" aria-label="مسیر سطح جاری ساختار">${chain.map((node,index)=>`<button type="button" class="${index===chain.length-1?'current':''}" onclick="eqv2StructureCrumb(${index})">${escText(node.name||node.code||'')}</button>`).join('<i aria-hidden="true">›</i>')}</nav>`;
  }
  function structureInventoryCard(node){
    const item=node&&node.inventoryItem;
    if(!node)return'';
    if(!item)return`<div class="eqv2-structure-inventory"><b>اتصال به اطلاعات مرجع انبار</b><span>قلم انبار متصل نشده است؛ اتصال فقط از طریق جستجوی قلم واقعی انجام می‌شود.</span></div>`;
    return`<div class="eqv2-structure-inventory"><b>قلم واقعی انبار: ${escText(item.code||'')} — ${escText(item.name||'')}</b>
      <span>موجودی قابل دسترس (فقط از دفتر انبار): ${faText(item.available==null?0:item.available)} ${escText(item.unit||'')}</span>
      <span>شماره قطعه: ${escText(item.partNumber||'ثبت نشده')} · برند/سازنده: ${escText(item.manufacturer||'ثبت نشده')} · مشخصات: ${escText(item.specification||'ثبت نشده')}</span></div>`;
  }
  const STRUCTURE_COLUMNS=['نام','کد','نوع','برند / سازنده','مدل','شماره قطعه','تعداد','وضعیت','بحرانیت',
    'قلم انبار مرتبط','موجودی واقعی','آخرین خرید','تأمین‌کننده آخرین خرید','عملیات'];
  function structureCell(value){return value==null||value===''?'<span class="eqv2-na">—</span>':escText(String(value));}
  function structureStatusLabel(status){const item=status&&typeof AS_ST!=='undefined'&&AS_ST[status];return Array.isArray(item)?item[0]:(status||null);}
  function structureActiveSectionCount(node){return(node&&node.children||[]).filter(child=>!child.archived).length;}
  function structureAddLabel(kind){return`افزودن ${STRUCTURE_KIND_LABEL[kind]||'بخش ساختار تجهیز'}`;}
  function structureSelectedContextLabel(node){
    if(!node)return'تجهیز انتخاب‌شده';
    const kind=String(node.nodeKind||'');
    if(kind==='equipment')return'تجهیز انتخاب‌شده';
    return`${STRUCTURE_KIND_LABEL[kind]||'بخش'} انتخاب‌شده`;
  }
  function structureUniqueDiagnostics(items){
    const seen=new Set();
    return(items||[]).filter(item=>{
      const key=String(item&&(item.code||item.message)||'').trim();
      if(!key||seen.has(key))return false;
      seen.add(key);return true;
    });
  }
  const STRUCTURE_DIAGNOSTIC_MESSAGES={
    ROOT_PARENT_OUTSIDE_STRUCTURE:'جایگاه مکانی یا دسته‌بندی تجهیز خارج از ساختار تجهیز است و بدون تغییر حفظ می‌شود.',
    STRUCTURE_PARENT_OUTSIDE_SCOPE:'بخش مرتبط با این رکورد در محدوده ساختار تجهیز یافت نشد؛ رکورد حفظ شده است.',
    STRUCTURE_KIND_CONFLICT:STRUCTURE_CONFLICT_WARNING,
    STRUCTURE_DEPTH_EXCEEDED:STRUCTURE_DEPTH_WARNING,
    STRUCTURE_NODE_KIND_MISSING:'نوع ذخیره‌شده خالی است؛ نوع Canonical از عمق واقعی نمایش داده می‌شود.'
  };
  function structureRowWarningLabel(node){
    if(!node)return'';
    if(node.canonicalKind===null)return STRUCTURE_DEPTH_WARNING;
    if(node.conflict||node.validRelation===false)return STRUCTURE_CONFLICT_WARNING;
    if(node.legacy)return STRUCTURE_LEGACY_WARNING;
    return'';
  }
  function structureNotices(st,caps){
    const nodes=flattenStructure(st&&st.nodes||[]);
    const diagnostics=[...(st&&st.diagnostics||[]),...nodes.flatMap(node=>Array.isArray(node.diagnostics)?node.diagnostics:[])];
    const rowWarnings=new Set(['STRUCTURE_PARENT_KIND_INVALID','LEGACY_SUB_EQUIPMENT','STRUCTURE_NODE_KIND_MISSING','STRUCTURE_KIND_CONFLICT','STRUCTURE_DEPTH_EXCEEDED']);
    const notices=structureUniqueDiagnostics(diagnostics).filter(item=>!rowWarnings.has(item.code))
      .map(item=>STRUCTURE_DIAGNOSTIC_MESSAGES[item.code]||String(item.message||'').trim()).filter(Boolean);
    if(!caps.archive&&nodes.length)notices.push('مجوز بایگانی یا بازیابی بخش‌های ساختار تجهیز را ندارید.');
    return[...new Set(notices)];
  }
  function faDate(value){
    if(!value)return null;
    const date=new Date(value);
    if(Number.isNaN(date.getTime()))return null;
    try{return new Intl.DateTimeFormat('fa-IR',{dateStyle:'short'}).format(date);}catch(_){return date.toLocaleDateString();}
  }
  function structureStockCell(node){
    if(!node.inventoryItemId&&!node.inventoryItem)return '<span class="eqv2-na">ثبت نشده</span>';
    const value=node.stockAvailable==null?(node.inventoryItem&&node.inventoryItem.available):node.stockAvailable;
    const unit=(node.inventoryItem&&node.inventoryItem.unit)||node.unit||'';
    if(value==null)return '<span class="eqv2-na">ثبت نشده</span>';
    const reserved=node.stockReserved==null?0:node.stockReserved;
    return `<b>${faText(value)}</b> ${escText(unit)}${reserved?` <span class="muted">(رزرو ${faText(reserved)})</span>`:''}`;
  }
  function structurePurchaseCell(node){
    const purchase=node.lastPurchase;
    if(!purchase||!purchase.at)return '<span class="eqv2-na">ثبت نشده</span>';
    return `${escText(faDate(purchase.at)||'')} <span class="muted">${escText(purchase.entryNo||'')}</span>`;
  }
  function structureSupplierCell(node){
    // A real receipt in inventory_ledger carries no supplier, so nothing is invented.
    if(!node.lastPurchase)return '<span class="eqv2-na">ثبت نشده</span>';
    return node.lastPurchase.supplier?escText(node.lastPurchase.supplier):'<span class="eqv2-na">ثبت نشده</span>';
  }
  function structureInventoryCell(node){
    const item=node.inventoryItem;
    if(!item)return '<span class="eqv2-na">ثبت نشده</span>';
    return `<span title="${escText(item.name||'')}">${escText(item.code||'—')}</span>`;
  }
  function structureRowActions(node,caps,canAdd){
    const id=escText(node.id),name=String(node.name||node.code||'این بخش');
    const archiveReason=String(node.archiveReason||node.archive_reason||'').trim()||'این بخش قابل بایگانی نیست.';
    const cannotArchive=node.canArchive===false||node.can_archive===false;
    const canonicalKind=node.canonicalKind===undefined?node.nodeKind:node.canonicalKind;
    const canOperate=!!canonicalKind&&canonicalKind!=='equipment'&&canonicalKind!=='sub-equipment';
    const menuItems=[];
    const menuButton=(label,tooltip,action)=>`<button type="button" role="menuitem" class="eqv2-structure-action-menu-item eqv2-structure-tooltip" data-tooltip="${escText(tooltip)}" title="${escText(tooltip)}" aria-label="${escText(tooltip)}" onclick="event.stopPropagation();this.closest('details').open=false;eqv2Structure${action}('${id}')">${label}</button>`;
    if(canOperate&&caps.update&&!node.archived)menuItems.push(menuButton('ویرایش',`ویرایش ${name}`,'Edit'));
    if(canOperate&&(caps.move||caps.moveAcrossEquipment)&&!node.archived)menuItems.push(menuButton('جابه‌جایی',`جابه‌جایی ${name}`,'Move'));
    if(canOperate&&!node.archived&&(caps.archive||cannotArchive)){
      if(cannotArchive){
        const reason=escText(archiveReason);
        menuItems.push(`<span class="eqv2-structure-action-menu-item eqv2-structure-action-menu-disabled eqv2-structure-tooltip" role="menuitem" aria-disabled="true" tabindex="0" data-tooltip="${reason}" title="${reason}" aria-label="بایگانی در دسترس نیست: ${reason}">بایگانی</span>`);
      }else menuItems.push(menuButton('بایگانی','بایگانی نرم با دلیل اجباری و تأیید؛ سوابق حفظ می‌شوند','Archive'));
    }
    if(canOperate&&node.archived&&caps.archive)menuItems.push(menuButton('بازیابی',`بازیابی ${name}`,'Restore'));
    const viewTooltip=`مشاهده جزئیات ${name}`;
    const addLabel=structureAddLabel(structureAllowedChildren(node.nodeKind,node)[0]);
    const addTooltip=`${addLabel} برای ${name}`;
    const moreTooltip=`عملیات بیشتر برای ${name}`;
    return `<div class="eqv2-structure-row-actions">
      <button type="button" class="eqv2-structure-icon-button eqv2-structure-view-action eqv2-structure-tooltip" data-tooltip="${escText(viewTooltip)}" title="${escText(viewTooltip)}" aria-label="${escText(viewTooltip)}" onclick="event.stopPropagation();eqv2StructureFocus('${id}')"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M2 12s3.7-7 10-7 10 7 10 7-3.7 7-10 7S2 12 2 12Z"></path><circle cx="12" cy="12" r="3"></circle></svg></button>
      ${canAdd&&!node.archived?`<button type="button" class="eqv2-structure-icon-button eqv2-structure-add-action eqv2-structure-tooltip" data-tooltip="${escText(addTooltip)}" title="${escText(addTooltip)}" aria-label="${escText(addTooltip)}" onclick="event.stopPropagation();eqv2StructureAdd('${id}')"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><path d="M12 5v14M5 12h14"></path></svg></button>`:''}
      ${menuItems.length?`<details class="eqv2-structure-action-menu" ontoggle="eqv2StructureActionMenuToggle(this)" onkeydown="eqv2StructureActionMenuKeydown(event,this)"><summary class="eqv2-structure-icon-button eqv2-structure-menu-trigger eqv2-structure-tooltip" data-tooltip="${escText(moreTooltip)}" title="${escText(moreTooltip)}" aria-label="${escText(moreTooltip)}" aria-haspopup="menu" aria-expanded="false" onclick="event.stopPropagation()"><svg viewBox="0 0 24 24" aria-hidden="true" focusable="false"><circle cx="12" cy="5" r="1.5"></circle><circle cx="12" cy="12" r="1.5"></circle><circle cx="12" cy="19" r="1.5"></circle></svg></summary><div class="eqv2-structure-action-menu-panel" role="menu" aria-label="عملیات ساختار برای ${escText(name)}">${menuItems.join('')}</div></details>`:''}
    </div>`;
  }
  function structureActionMenuToggle(details){
    const summary=details&&details.querySelector('summary'),panel=details&&details.querySelector('.eqv2-structure-action-menu-panel');
    if(!summary||!panel)return;
    summary.setAttribute('aria-expanded',String(!!details.open));
    if(!details.open){panel.style.position='';panel.style.left='';panel.style.top='';panel.style.right='';panel.style.bottom='';return;}
    requestAnimationFrame(()=>{
      if(!details.open)return;
      const rect=summary.getBoundingClientRect(),width=panel.offsetWidth||180,height=panel.offsetHeight||140;
      const viewportWidth=Number(window.innerWidth)||document.documentElement&&document.documentElement.clientWidth||640;
      const viewportHeight=Number(window.innerHeight)||document.documentElement&&document.documentElement.clientHeight||480;
      const left=Math.max(8,Math.min(rect.right-width,viewportWidth-width-8));
      const top=rect.bottom+height+12<=viewportHeight?rect.bottom+4:Math.max(8,rect.top-height-4);
      panel.style.position='fixed';panel.style.left=`${left}px`;panel.style.top=`${top}px`;panel.style.right='auto';panel.style.bottom='auto';
    });
  }
  function structureActionMenuKeydown(event,details){
    if(!event||!details)return;
    const summary=details.querySelector('summary'),items=Array.from(details.querySelectorAll('.eqv2-structure-action-menu-item'));
    if(event.key==='Escape'&&details.open){event.preventDefault();event.stopPropagation();details.open=false;if(summary)summary.focus();return;}
    if(!items.length)return;
    const current=items.indexOf(event.target);
    let next=-1;
    if(event.target===summary&&(event.key==='ArrowDown'||event.key==='ArrowUp')){
      event.preventDefault();details.open=true;next=event.key==='ArrowUp'?items.length-1:0;
    }else if(event.key==='ArrowDown'&&current>=0){event.preventDefault();next=(current+1)%items.length;}
    else if(event.key==='ArrowUp'&&current>=0){event.preventDefault();next=(current+items.length-1)%items.length;}
    else if(event.key==='Home'&&current>=0){event.preventDefault();next=0;}
    else if(event.key==='End'&&current>=0){event.preventDefault();next=items.length-1;}
    if(next>=0)requestAnimationFrame(()=>items[next]&&items[next].focus());
  }
  function structureChildCountLabel(node,count){
    const childLabel={equipment:'زیرسیستم تجهیز',subsystem:'قطعه اصلی زیرسیستم','main-component':'زیرقطعه قطعه اصلی'}[node.nodeKind];
    if(node.nodeKind==='sub-component'||node.canonicalKind===null)return'هیچ سطح پایین‌تری';
    return`${faText(count)} ${childLabel||'بخش پایین‌تر'}`;
  }
  function structureRowCells(node,caps,level,warningState={legacyShown:false}){
    const children=node.children||[];
    const canChild=caps.create&&structureAllowedChildren(node.nodeKind,node).length>0;
    const hasChildren=structureHasChildren(node);
    const expanded=hasChildren&&(!!String(E.structureQuery||'').trim()||structureNodeExpanded(node));
    const activeChildCount=children.filter(child=>!child.archived).length;
    const reportedChildCount=Number(node.childCount??node.childrenCount??node.activeChildCount??node.active_child_count);
    const sectionCount=activeChildCount>0?activeChildCount:(Number.isFinite(reportedChildCount)&&reportedChildCount>0?reportedChildCount:0);
    const loading=String(E.structureNodeLoadingId)===String(node.id);
    const brand=node.brand||node.manufacturer||node.inventoryItem&&node.inventoryItem.manufacturer||node.maker||null;
    const partNumber=node.partNumber||(node.inventoryItem&&node.inventoryItem.partNumber)||null;
    const quantity=node.requiredQuantity==null?null:faText(node.requiredQuantity)+(node.unit?' '+node.unit:'');
    const warningText=structureRowWarningLabel(node);
    const hasConflict=!!node.conflict||node.validRelation===false||node.canonicalKind===null;
    const showRowWarning=!!warningText&&(hasConflict||!warningState.legacyShown);
    const displayedKind=node.canonicalKind===null?`سطح نامعتبر (عمق ${faText(node.level||0)})`:(STRUCTURE_KIND_LABEL[node.nodeKind]||node.nodeKind);
    if(showRowWarning&&!hasConflict)warningState.legacyShown=true;
    return `<tr class="eqv2-structure-tr${node.archived?' is-archived':''}${node.validRelation===false||node.canonicalKind===null?' is-invalid':''}${String(E.structureSelected)===String(node.id)?' is-selected':''}" data-structure-node="${escText(node.id)}" aria-selected="${String(E.structureSelected)===String(node.id)}">
      <td class="eqv2-structure-name" style="--eqv2-level:${Math.max(level,0)}">
        ${hasChildren?`<button type="button" class="eqv2-structure-toggle" aria-expanded="${expanded}" aria-label="${loading?'در حال بارگذاری':expanded?'بستن':'باز کردن'} سطوح پایین‌تر از ${escText(node.name||node.code||'')}" ${loading?'disabled':''} onclick="eqv2StructureToggle('${escText(node.id)}')">${loading?'…':expanded?'▾':'◂'}</button>`:'<span class="eqv2-structure-leaf" aria-hidden="true"></span>'}
        <b>${escText(node.name||'بدون نام')}</b><small class="eqv2-structure-section-count">${escText(structureChildCountLabel(node,sectionCount))}</small>
        ${node.archived?'<span class="badge b-orange">بایگانی</span>':''}
        ${!node.archived&&!hasConflict&&['main-component','sub-component'].includes(node.nodeKind)
          ?node.criticalSpare?'<span class="badge b-red">قطعه یدکی حیاتی</span>'
          :caps.update?`<label class="eqv2-structure-critical"><input type="checkbox" onchange="if(this.checked){this.checked=false;eqv2StructureEdit('${escText(node.id)}',true);}"> افزودن به قطعات یدکی حیاتی</label>`:''
          :''}
        ${showRowWarning?`<span class="badge b-orange eqv2-structure-legacy-warning">${escText(warningText)}</span>`:''}
      </td>
      <td>${structureCell(node.code)}</td>
      <td>${structureCell(displayedKind)}</td>
      <td>${structureCell(brand)}</td>
      <td>${structureCell(node.model)}</td>
      <td>${structureCell(partNumber)}</td>
      <td>${quantity==null?'<span class="eqv2-na">ثبت نشده</span>':escText(quantity)}</td>
      <td>${structureCell(structureStatusLabel(node.status))}</td>
      <td>${structureCell(node.crit)}</td>
      <td>${structureInventoryCell(node)}</td>
      <td class="eqv2-structure-stock">${structureStockCell(node)}</td>
      <td>${structurePurchaseCell(node)}</td>
      <td>${structureSupplierCell(node)}</td>
      <td class="eqv2-structure-actions">${structureRowActions(node,caps,canChild)}</td>
    </tr>${expanded&&children.length?children.map(child=>structureRowCells(child,caps,level+1,warningState)).join(''):''}`;
  }
  function structureTable(nodes,caps,warningAlreadyShown=false){
    const warningState={legacyShown:!!warningAlreadyShown};
    return `<div class="eqv2-structure-table-wrap"><table class="eqv2-structure-table">
      <thead><tr>${STRUCTURE_COLUMNS.map((column,index)=>`<th${index===0?' class="eqv2-structure-name"':''}${index===STRUCTURE_COLUMNS.length-1?' class="eqv2-structure-actions"':''}>${escText(column)}</th>`).join('')}</tr></thead>
      <tbody>${nodes.map(node=>structureRowCells(node,caps,0,warningState)).join('')}</tbody></table></div>`;
  }
  function structureHasChildren(node){
    if(!node||node.canonicalKind===null||Number(node.level)>3)return false;
    if((node.children||[]).some(child=>!child.archived)||((node.children||[]).length>0&&E.structureArchived))return true;
    const expected=Number(node&&(node.childCount??node.childrenCount??node.activeChildCount??node.active_child_count));
    return node&&(node.hasChildren===true||node.has_children===true||node.childrenLoaded===false&&expected>0||Number.isFinite(expected)&&expected>0);
  }
  function structureExpandableNodes(st=E.structure){
    return flattenStructure(st&&st.nodes||[]).filter(structureHasChildren);
  }
  function structureNodeHasLoadedChildren(node){
    const children=node&&node.children||[];
    return E.structureArchived?children.length>0:children.some(child=>!child.archived);
  }
  function structureNodeLevel(node){
    const level=Number(node&&node.level);
    if(Number.isInteger(level)&&level>=0)return level;
    return Math.max(1,Array.isArray(node&&node.path)?node.path.length:1);
  }
  function structureMaxLoadedDepth(st=E.structure){
    return flattenStructure(st&&st.nodes||[]).reduce((max,node)=>Math.max(max,structureNodeLevel(node)),0);
  }
  function structureNodeExpanded(node){
    return Object.prototype.hasOwnProperty.call(E.structureExpanded,node.id)?E.structureExpanded[node.id]!==false:(node.children||[]).length>0;
  }
  function captureStructureViewport(){
    const table=document.querySelector('.eqv2-structure-table-wrap');
    return{x:window.scrollX||0,y:window.scrollY||0,tableTop:table?table.scrollTop:0,tableLeft:table?table.scrollLeft:0,hadTable:!!table};
  }
  async function renderStructurePreservingViewport(){
    const viewport=captureStructureViewport();
    await renderCurrentDetail();
    requestAnimationFrame(()=>{
      window.scrollTo(viewport.x,viewport.y);
      const table=document.querySelector('.eqv2-structure-table-wrap');
      if(table&&viewport.hadTable){table.scrollTop=viewport.tableTop;table.scrollLeft=viewport.tableLeft;}
    });
  }
  async function structureToggle(id){
    const node=structureNodeById(id);
    if(!node||!structureHasChildren(node)){toast('این بخش در ساختار تجهیز سطح پایین‌تری ندارد.',1);return;}
    const shouldOpen=!structureNodeExpanded(node);
    if(!shouldOpen){E.structureExpanded[node.id]=false;if(E.tab==='structure')await renderStructurePreservingViewport();return;}
    if(structureNodeHasLoadedChildren(node)){
      E.structureExpanded[node.id]=true;E.structureNodeLoadError=null;
      if(E.tab==='structure')await renderStructurePreservingViewport();return;
    }
    const previouslyLoadedIds=new Set(flattenStructure(E.structure&&E.structure.nodes||[]).map(item=>String(item.id)));
    E.structureNodeLoadingId=String(node.id);E.structureNodeLoadError=null;
    if(E.tab==='structure')await renderStructurePreservingViewport();
    try{
      const rootId=String(E.structure&&E.structure.rootId||E.detailId||'');
      const depth=Math.min(64,structureNodeLevel(node)+1);
      const response=await R().structure(rootId,{includeArchived:E.structureArchived,depth});
      const latest=normalizeStructure(rootId,response&&response.data);
      if(String(latest.rootId)!==rootId)throw Object.assign(new Error('STRUCTURE_ROOT_CHANGED'),{message:'STRUCTURE_ROOT_CHANGED'});
      E.structure=latest;
      for(const item of flattenStructure(latest.nodes))if(!previouslyLoadedIds.has(String(item.id))&&!Object.prototype.hasOwnProperty.call(E.structureExpanded,item.id))E.structureExpanded[item.id]=false;
      const refreshed=structureNodeById(node.id);
      if(!refreshed||!structureNodeHasLoadedChildren(refreshed)){
        E.structureExpanded[node.id]=false;E.structureNodeLoadError='این بخش در ساختار تجهیز سطح پایین‌تری ندارد.';toast(E.structureNodeLoadError,1);
      }else{E.structureExpanded[node.id]=true;E.structureNodeLoadError=null;}
    }catch(error){
      const code=error&&(error.payload&&error.payload.error||error.code||error.message);
      E.structureNodeLoadError=`بارگذاری بخش از ساختار تجهیز انجام نشد؛ ${STRUCTURE_MESSAGES[code]||'دریافت اطلاعات از سرور ناموفق بود. دوباره تلاش کنید.'}`;
      toast(E.structureNodeLoadError,1);
    }finally{
      E.structureNodeLoadingId=null;
      if(E.tab==='structure')await renderStructurePreservingViewport();
    }
  }
  async function structureToggleAll(expanded){
    if(E.structureBulkLoading)return;
    const expandable=structureExpandableNodes();
    if(!expanded){
      const hasOpen=expandable.some(structureNodeExpanded);
      if(!hasOpen){
        E.structureBulkNotice=expandable.length?'سطوح پایین‌تر از قبل بسته‌اند.':'ساختار تجهیز بخش پایین‌تری ندارد.';
        if(E.tab==='structure')await renderStructurePreservingViewport();
        if(!expandable.length)toast(E.structureBulkNotice,1);
        return;
      }
      for(const node of flattenStructure(E.structure&&E.structure.nodes||[]))E.structureExpanded[node.id]=false;
      E.structurePanel=[];E.structureFocus=null;E.structureBulkNotice=null;E.structureBulkError=null;
      if(E.tab==='structure')await renderStructurePreservingViewport();
      return;
    }
    if(!expandable.length){
      E.structureBulkNotice='ساختار تجهیز بخش پایین‌تری ندارد.';E.structureBulkError=null;
      if(E.tab==='structure')await renderStructurePreservingViewport();
      toast(E.structureBulkNotice,1);return;
    }
    const needsLazyLoad=expandable.some(node=>!structureNodeHasLoadedChildren(node));
    if(!needsLazyLoad){
      for(const node of expandable)E.structureExpanded[node.id]=true;
      E.structureBulkNotice=null;E.structureBulkError=null;E.structureNodeLoadError=null;
      if(E.tab==='structure')await renderStructurePreservingViewport();
      return;
    }
    const rootId=String(E.structure&&E.structure.rootId||E.detailId||'');
    if(!rootId){E.structureBulkError='تجهیز انتخاب‌شده برای بارگذاری ساختار در دسترس نیست.';toast(E.structureBulkError,1);return;}
    E.structureBulkNotice=null;E.structureBulkError=null;E.structureNodeLoadError=null;E.structureBulkLoading=true;
    if(E.tab==='structure')await renderStructurePreservingViewport();
    try{
      if(typeof R().structure!=='function')throw Object.assign(new Error('SERVER_REQUIRED'),{message:'SERVER_REQUIRED'});
      let passes=0;
      while(true){
        const incomplete=structureExpandableNodes().filter(node=>!structureNodeHasLoadedChildren(node));
        if(!incomplete.length)break;
        const nextDepth=Math.max(structureMaxLoadedDepth()+1,...incomplete.map(node=>structureNodeLevel(node)+1));
        if(nextDepth>64)throw Object.assign(new Error('STRUCTURE_DEPTH_LIMIT_REACHED'),{message:'STRUCTURE_DEPTH_LIMIT_REACHED'});
        const loadedBefore=new Set(flattenStructure(E.structure&&E.structure.nodes||[]).map(node=>String(node.id)));
        const previousSignature=incomplete.map(node=>String(node.id)).sort().join('|');
        const response=await R().structure(rootId,{includeArchived:E.structureArchived,depth:nextDepth});
        const latest=normalizeStructure(rootId,response&&response.data);
        if(String(latest.rootId)!==rootId)throw Object.assign(new Error('STRUCTURE_ROOT_CHANGED'),{message:'STRUCTURE_ROOT_CHANGED'});
        E.structure=latest;
        for(const node of flattenStructure(latest.nodes))if(!loadedBefore.has(String(node.id))&&!Object.prototype.hasOwnProperty.call(E.structureExpanded,node.id))E.structureExpanded[node.id]=false;
        const remaining=structureExpandableNodes(latest).filter(node=>!structureNodeHasLoadedChildren(node));
        const nextSignature=remaining.map(node=>String(node.id)).sort().join('|');
        if(nextSignature&&nextSignature===previousSignature)throw Object.assign(new Error('STRUCTURE_LAZY_LOAD_STALLED'),{message:'STRUCTURE_LAZY_LOAD_STALLED'});
        passes+=1;
        if(passes>=64&&remaining.length)throw Object.assign(new Error('STRUCTURE_DEPTH_LIMIT_REACHED'),{message:'STRUCTURE_DEPTH_LIMIT_REACHED'});
      }
      const loadedExpandable=structureExpandableNodes();
      if(!loadedExpandable.length){
        E.structureBulkNotice='ساختار تجهیز بخش پایین‌تری ندارد.';
        toast(E.structureBulkNotice,1);
      }else{
        for(const node of loadedExpandable)E.structureExpanded[node.id]=true;
        E.structureBulkNotice=null;
      }
    }catch(error){
      const code=error&&(error.payload&&error.payload.error||error.code||error.message);
      E.structureBulkError=`بارگذاری سطوح ساختار تجهیز انجام نشد؛ ${STRUCTURE_MESSAGES[code]||'دریافت اطلاعات از سرور ناموفق بود. دوباره تلاش کنید.'}`;
      toast(E.structureBulkError,1);
    }finally{
      E.structureBulkLoading=false;
      if(E.tab==='structure')await renderStructurePreservingViewport();
    }
  }
  function structureFilterNodes(nodes,query){
    const needle=String(query||'').trim().toLocaleLowerCase();
    if(!needle)return nodes||[];
    return(nodes||[]).map(node=>{
      const own=`${node.name||''} ${node.code||''}`.toLocaleLowerCase().includes(needle);
      if(own)return node;
      const children=structureFilterNodes(node.children,needle);
      return children.length?{...node,children}:null;
    }).filter(Boolean);
  }
  async function structureSearch(value){
    E.structureQuery=String(value||'');
    clearTimeout(E.structureSearchTimer);
    E.structureSearchTimer=setTimeout(async()=>{
      const input=document.getElementById('eqv2StructureSearch'),cursor=input&&input.selectionStart;
      try{await renderCurrentDetail();const next=document.getElementById('eqv2StructureSearch');if(next){next.focus({preventScroll:true});if(Number.isInteger(cursor))next.setSelectionRange(cursor,cursor);}}catch(error){showError(error);}
    },180);
  }
  function structureEmptyState(caps){
    return `<div class="eqv2-empty eqv2-structure-empty"><div><i>—</i>
      <div>هنوز بخشی در ساختار این تجهیز ثبت نشده است.</div>
      <div class="muted">ساختار تجهیز به‌صورت خودکار ساخته نمی‌شود؛ اولین بخش را خودتان ثبت کنید.</div>
      <div class="muted">قطعات یدکی مرتبط در بخش «قطعات یدکی حیاتی» همین پرونده دیده می‌شوند و خودکار به ساختار تجهیز تبدیل نمی‌شوند.</div>
      ${caps.create?`<button type="button" class="btn btn-primary" onclick="eqv2StructureAddRoot()">افزودن زیرسیستم تجهیز</button>`:''}</div></div>`;
  }
  function structureAddRoot(){
    const st=E.structure;
    if(!st||!st.root)return;
    structureAdd(st.root.id);
  }
  function structureSuggestionPanel(){
    const st=E.structure;if(!st)return'';
    const caps=st.capabilities||{};
    if(!caps.suggest&&!caps.approveAi)return'';
    return `<bfg-structure-review class="eqv2-subsection" data-id="${escText(st.rootId)}" ${caps.approveAi?'can-confirm':''}></bfg-structure-review>`;
  }
  function structureSection(a){
    const st=E.structure;
    const structureId=E.detailId||a.id;
    if(!st||String(st.rootId)!==String(structureId)){
      queueStructureLoad(structureId);
      return`<section class="eqv2-section-heading"><div><span>ساختار تجهیز</span><h2>ساختار تجهیز</h2><p>${STRUCTURE_GUIDE}</p></div></section><div class="eqv2-loading">در حال دریافت ساختار تجهیز…</div>`;
    }
    if(st.error){
      return`<section class="eqv2-section-heading"><div><span>ساختار تجهیز</span><h2>ساختار تجهیز</h2><p>${STRUCTURE_GUIDE}</p><p>${escText(STRUCTURE_MESSAGES[st.error]||'ساختار تجهیز از سرور دریافت نشد؛ دوباره تلاش کنید.')}</p></div></section>${empty('ساختار تجهیز در دسترس نیست.')}`;
    }
    const caps=st.capabilities||{};
    const focusNode=E.structureFocus?structureNodeById(E.structureFocus):null;
    const focusPathNodes=(focusNode&&Array.isArray(focusNode.path)?focusNode.path:[]).slice().reverse().map(step=>structureNodeById(step&&step.id||step)).filter(Boolean);
    const focusWarningNode=focusNode&&(focusNode.legacy||focusNode.validRelation===false)?focusNode:focusPathNodes.find(node=>node.legacy||node.validRelation===false)||null;
    const levelNode=focusNode||structureNodeById((E.structurePanel||[]).at(-1))||{id:st.root.id,children:st.nodes,nodeKind:'equipment',name:st.root.name};
    const levelChildren=levelNode.children||[];
    const visibleChildren=structureFilterNodes(levelChildren,E.structureQuery);
    const expandable=structureExpandableNodes(st);
    const canCollapseAll=expandable.some(structureNodeExpanded);
    const bulkStatus=E.structureBulkLoading?'در حال بارگذاری سطوح ساختار…':E.structureBulkError||E.structureNodeLoadError||E.structureBulkNotice||(!expandable.length?'ساختار تجهیز بخش پایین‌تری ندارد.':'');
    const addKind=structureAllowedChildren(levelNode.nodeKind,levelNode)[0];
    const heading=`<section class="eqv2-section-heading"><div><span>ساختار تجهیز</span><h2>ساختار تجهیز</h2><p>${STRUCTURE_GUIDE}</p></div>
      <div class="eqv2-section-actions">
        ${caps.create?(levelNode.nodeKind==='equipment'?`<button type="button" class="btn btn-sm btn-primary" onclick="eqv2StructureAddRoot()">＋ افزودن زیرسیستم تجهیز</button><button type="button" class="btn btn-sm btn-ghost" onclick="eqv2StructureAddMain()">＋ افزودن قطعه اصلی زیرسیستم</button>`:addKind?`<button type="button" class="btn btn-sm btn-primary" onclick="eqv2StructureAdd('${escText(levelNode.id)}')">＋ ${structureAddLabel(addKind)}</button>`:''):''}
        ${caps.archive?`<button type="button" class="btn btn-sm btn-ghost" onclick="eqv2StructureArchivedToggle()">${E.structureArchived?'نمایش بخش‌های فعال':'نمایش بایگانی'}</button>`:''}
      </div></section><div class="eqv2-structure-tools"><label class="eqv2-structure-search"><span>جستجوی نام یا کد</span><input id="eqv2StructureSearch" type="search" value="${escText(E.structureQuery)}" placeholder="نام یا کد ساختار تجهیز…" oninput="eqv2StructureSearch(this.value)"></label><div class="eqv2-structure-tools-actions"><button type="button" class="btn btn-sm btn-ghost" onclick="eqv2StructureExpandAll(true)" ${E.structureBulkLoading||!expandable.length?'disabled title="ساختار تجهیز بخش پایین‌تری ندارد"':''}>بازکردن همه</button><button type="button" class="btn btn-sm btn-ghost" onclick="eqv2StructureExpandAll(false)" ${E.structureBulkLoading||!canCollapseAll?'disabled title="سطح بازی برای بستن وجود ندارد"':''}>بستن همه</button></div>${bulkStatus?`<span class="eqv2-structure-bulk-status" role="status" aria-live="polite">${escText(bulkStatus)}</span>`:''}</div>`;
    const focusCard=focusNode?`<section class="eqv2-structure-panel" aria-label="پنل جزئیات جزء ساختاری">
      <div class="eqv2-structure-panel-head"><b>جزئیات: ${escText(focusNode.name||focusNode.code||'')}</b>
        <button type="button" class="btn btn-sm btn-ghost" onclick="eqv2StructureClose()">بستن / بازگشت به سطح قبلی</button></div>
      ${focusWarningNode?`<span class="badge b-orange eqv2-structure-legacy-warning">${escText(structureRowWarningLabel(focusWarningNode))}</span>`:''}
      <div class="eqv2-detail-grid">
        ${[['نوع',focusNode.canonicalKind===null?`سطح نامعتبر (عمق ${faText(focusNode.level||0)})`:(STRUCTURE_KIND_LABEL[focusNode.nodeKind]||focusNode.nodeKind)],['کد',focusNode.code],['نام',focusNode.name],
          ['آخرین تأیید سلن',focusNode.review?(Number(focusNode.review.version)===focusNode.rowVersion?'تأییدشده':'نسخهٔ قبلی تأیید شده'):null],['منشأ',focusNode.review?.sourceType],['شاهد',focusNode.review?.evidenceType],['شناسه ممیزی',focusNode.review?.id],['نوع قطعه',focusNode.componentType],['برند',focusNode.brand],['سازنده',focusNode.manufacturer||focusNode.maker],
          ['مدل',focusNode.model],['شماره قطعه',focusNode.partNumber],['تعداد',focusNode.requiredQuantity==null?null:faText(focusNode.requiredQuantity)+(focusNode.unit?' '+focusNode.unit:'')],
          ['وضعیت',structureStatusLabel(focusNode.status)],['بحرانیت',focusNode.crit],['تعداد بخش فعال',faText(structureActiveSectionCount(focusNode))],
          ['قلم انبار مرتبط',focusNode.inventoryItem?`${focusNode.inventoryItem.code||''} — ${focusNode.inventoryItem.name||''}`:null],
          ['موجودی واقعی (از دفتر انبار)',focusNode.stockAvailable==null?null:faText(focusNode.stockAvailable)+((focusNode.inventoryItem&&focusNode.inventoryItem.unit)?' '+(focusNode.inventoryItem.unit||''):'')],
          ['آخرین خرید',focusNode.lastPurchase?faDate(focusNode.lastPurchase.at):null],
          ['تأمین‌کننده آخرین خرید',focusNode.lastPurchase?focusNode.lastPurchase.supplier:null]
        ].map(([key,value])=>`<div class="eqv2-info-card"><span>${escText(key)}</span><b>${value==null||value===''?'—':escText(value)}</b></div>`).join('')}
      </div>
      <div class="eqv2-detail-grid"><div class="eqv2-info-card"><span>مشخصات فنی</span><b>${escText(focusNode.technicalSpecification||'ثبت نشده')}</b></div>
        <div class="eqv2-info-card"><span>توضیحات</span><b>${escText(focusNode.structureNotes||'ثبت نشده')}</b></div></div>
      ${structureInventoryCard(focusNode)}
    </section>`:'';
    const notices=structureNotices(st,caps);
    const rootNotes=notices.length?`<div class="eqv2-wizard-note">${notices.map(escText).join(' ')}</div>`:'';
    return`${heading}${rootNotes}${structureCrumb()}${focusCard}
      <div class="eqv2-structure-level"><b>سطح جاری: ${escText(STRUCTURE_KIND_LABEL[levelNode.nodeKind]||levelNode.nodeKind||'')} — ${escText(levelNode.name||levelNode.code||'')}</b>
      <span class="muted">${faText((levelNode.children||[]).length)} بخش در این سطح</span></div>
      ${visibleChildren.length?structureTable(visibleChildren,caps,!!focusWarningNode):(String(E.structureQuery||'').trim()?empty('با این نام یا کد، جزئی ساختاری پیدا نشد.'):(E.structureArchived?empty('جزء بایگانی‌شده‌ای ثبت نشده است.'):structureEmptyState(caps)))}
      ${structureSuggestionPanel()}`;
  }
  async function refreshStructure(options={}){
    const rootId=(E.structure&&E.structure.rootId)||E.detailId;
    const depth=options.depth==null?Math.max(1,structureMaxLoadedDepth()):options.depth;
    if(rootId)await loadStructure(rootId,{depth,keepPanel:true,...options});
  }
  const STRUCTURE_FORM_LABELS={
    name:'نام',code:'کد',requiredQuantity:'تعداد',componentType:'نوع قطعه',inventoryItemId:'قلم انبار',status:'وضعیت',crit:'بحرانیت',
    manufacturer:'سازنده',brand:'برند',model:'مدل',partNumber:'شماره فنی',unit:'واحد شمارش',structureNotes:'توضیحات',technicalSpecification:'مشخصات فنی'
  };
  function structureDrawerParentText(parent){
    if(!parent)return'تجهیز انتخاب‌شده تعیین نشده است';
    const label=structureSelectedContextLabel(parent);
    return`${label}: ${parent.code?parent.code+' — ':''}${parent.name||'بدون نام'} (${STRUCTURE_KIND_LABEL[parent.nodeKind]||parent.nodeKind})`;
  }
  function structureFormStatusOptions(selected){
    const options=Object.entries(typeof AS_ST==='undefined'?{}:AS_ST).map(([value,item])=>({value,label:item[0]}));
    if(selected&&!options.some(item=>String(item.value)===String(selected)))options.push({value:selected,label:selected});
    return`<option value="">— انتخاب کنید —</option>${options.map(item=>`<option value="${escText(item.value)}" ${String(selected||'')===String(item.value)?'selected':''}>${escText(item.label)}</option>`).join('')}`;
  }
  function structureFormCritOptions(selected){return`<option value="">— انتخاب کنید —</option>${['A','B','C'].map(value=>`<option value="${value}" ${String(selected||'')===value?'selected':''}>${value}</option>`).join('')}`;}
  function structureInventoryChoices(state){
    const items=[...(E.structureInventoryResults||[])];
    const linked=state.node&&state.node.inventoryItem;
    if(linked&&String(linked.id)===String(state.values.inventoryItemId||'')&&!items.some(item=>String(item.id)===String(linked.id)))items.unshift(linked);
    const selected=String(state.values.inventoryItemId||'');
    return`<option value="">— بدون اتصال —</option>${items.map(item=>{
      const label=`${item.code||'بدون کد'} — ${item.name||'بدون نام'} · موجودی واقعی: ${faText(item.available==null?0:item.available)} ${item.unit||''}`;
      return`<option value="${escText(item.id)}" ${selected===String(item.id)?'selected':''}>${escText(label)}</option>`;
    }).join('')}`;
  }
  function structureDrawerFieldHtml(field,state){
    const value=state.values[field.id]==null?'':state.values[field.id];
    const id=`eqv2-structure-${field.id}`,required=field.required?' required aria-required="true"':'';
    if(field.kind==='checkbox')return`<div class="eqv2-structure-field"><label for="${id}"><input id="${id}" data-structure-field="${field.id}" type="checkbox" ${value===true?'checked':''}> ${escText(field.label)}</label><small>برای افزودن، قلم واقعی انبار را در همین فرم انتخاب کنید.</small></div>`;
    if(field.kind==='inventory')return`<div class="eqv2-structure-field eqv2-structure-inventory-field">
      <label for="${id}-search">جستجوی قلم موجود (کد، نام، شماره فنی یا برند)</label>
      <div class="eqv2-structure-inventory-search"><input id="${id}-search" type="search" data-structure-inventory-search placeholder="ابتدا قلم واقعی انبار را جستجو کنید…"><button type="button" class="btn btn-sm btn-ghost" data-structure-action="inventory-search">جستجو</button></div>
      <label for="${id}">اتصال اختیاری به قلم موجود</label><select id="${id}" data-structure-field="inventoryItemId">${structureInventoryChoices(state)}</select>
      <small data-inventory-results>اطلاعات مرجع انبار و موجودی فقط خوانده می‌شوند؛ این فرم قلم یا موجودی جدید نمی‌سازد.</small></div>`;
    if(field.kind==='select'){
      const options=field.id==='status'?structureFormStatusOptions(value):field.id==='crit'?structureFormCritOptions(value):'<option value="">— انتخاب کنید —</option>';
      return`<div class="eqv2-structure-field"><label for="${id}">${escText(field.label)}${required?' *':''}</label><select id="${id}" data-structure-field="${escText(field.id)}"${required}>${options}</select></div>`;
    }
    if(field.kind==='textarea')return`<div class="eqv2-structure-field"><label for="${id}">${escText(field.label)}${required?' *':''}</label><textarea id="${id}" data-structure-field="${escText(field.id)}" maxlength="${field.maxLength||4000}" rows="${field.id==='technicalSpecification'?3:2}"${required}>${escText(value)}</textarea></div>`;
    const type=field.kind==='number'?'number':'text';
    return`<div class="eqv2-structure-field"><label for="${id}">${escText(field.label)}${required?' *':''}</label><input id="${id}" data-structure-field="${escText(field.id)}" type="${type}" value="${escText(value)}" maxlength="${field.maxLength||120}"${field.min!=null?` min="${field.min}"`:''}${field.step!=null?` step="${field.step}"`:''}${required}></div>`;
  }
  function structureParentPickerHtml(){
    const subsystems=flattenStructure(E.structure&&E.structure.nodes||[]).filter(node=>node.nodeKind==='subsystem'&&!node.archived);
    const choices=subsystems.map(node=>`<option value="${escText(node.id)}">${escText((node.code?node.code+' — ':'')+(node.name||'بدون نام'))}</option>`).join('');
    return`<div class="eqv2-structure-parent-picker"><p>برای افزودن قطعه اصلی زیرسیستم، یک زیرسیستم تجهیز را انتخاب کنید.</p>
      <label for="eqv2StructureParentChoice">زیرسیستم تجهیز *</label><select id="eqv2StructureParentChoice"><option value="">— انتخاب زیرسیستم تجهیز —</option>${choices}</select>
      <div class="eqv2-structure-parent-picker-actions"><button type="button" class="btn btn-primary" data-structure-action="parent-continue" disabled>ادامه با این زیرسیستم تجهیز</button></div></div>`;
  }
  function structureAdvisorMarkup(){
    if(!E.structure?.capabilities?.suggest)return'';
    return`<details class="eqv2-structure-advisor">
      <summary>مشاوره با سلن برای این سطح از ساختار</summary>
      <label for="eqv2StructureQuestion">پرسش یا توضیح شما</label>
      <textarea id="eqv2StructureQuestion" rows="3" maxlength="4000" placeholder="مثلاً برای این زیرسیستم چه قطعات اصلی پیشنهاد می‌کنی؟"></textarea>
      <label for="eqv2StructureAttachment">فایل یا تصویر تکمیلی (حداکثر ۸ مگابایت)</label>
      <input id="eqv2StructureAttachment" type="file" accept=".txt,.md,.csv,.xlsx,.docx,.pdf,.jpg,.jpeg,.png,.webp">
      <button type="button" class="btn btn-sm btn-primary" data-structure-action="advise">تحلیل و پیشنهاد</button>
      <p data-structure-advisor-status role="status"></p>
      <div data-structure-advisor-results></div>
    </details>`;
  }
  const structureAdvisorMessages={
    NO_CAPABLE_PROVIDER:'برای این ورودی سرویس تحلیل فعال نیست. تحلیل تصویر به مدلی با پشتیبانی تصویر نیاز دارد.',
    STRUCTURE_ADVISOR_PROVIDER_POLICY:'سیاست سلن اجازهٔ این تحلیل را به سرویس پیکربندی‌شده نمی‌دهد.',
    STRUCTURE_ADVISOR_ATTACHMENT_TYPE:'نوع فایل پشتیبانی نمی‌شود.',
    STRUCTURE_ADVISOR_ATTACHMENT_INVALID:'فایل معتبر نیست یا بیش از ۸ مگابایت است.',
    STRUCTURE_ADVISOR_NO_TEXT:'متنی از فایل استخراج نشد. برای PDF اسکن‌شده، تصویر صفحهٔ مربوط را بارگذاری کنید.',
    STRUCTURE_ADVISOR_INPUT_REQUIRED:'پرسش یا فایل تکمیلی را وارد کنید.',
    STRUCTURE_ADVISOR_RESPONSE_INVALID:'پاسخ قابل استفاده‌ای از سرویس سلن دریافت نشد.',
    STRUCTURE_ADVISOR_FAILED:'سرویس سلن پاسخ نداد. دوباره تلاش کنید.'
  };
  async function structureDrawerAdvise(view,button){
    const root=view.root,state=structureDrawerController.state;
    const question=root.querySelector('#eqv2StructureQuestion').value.trim();
    const file=root.querySelector('#eqv2StructureAttachment').files[0];
    const status=root.querySelector('[data-structure-advisor-status]');
    const results=root.querySelector('[data-structure-advisor-results]');
    results.replaceChildren();view.suggestions=[];
    if(!question&&!file){status.textContent=structureAdvisorMessages.STRUCTURE_ADVISOR_INPUT_REQUIRED;return;}
    if(file&&file.size>8*1024*1024){status.textContent=structureAdvisorMessages.STRUCTURE_ADVISOR_ATTACHMENT_INVALID;return;}
    status.textContent='سلن در حال تحلیل پرونده و ورودی شماست…';
    button.disabled=true;
    try{
      const attachment=file?{name:file.name,base64:await new Promise((resolve,reject)=>{
        const reader=new FileReader();
        reader.onerror=reject;
        reader.onload=()=>resolve(String(reader.result).split(',')[1]);
        reader.readAsDataURL(file);
      })}:null;
      if(E.structureDrawerView!==view)return;
      const response=await R().structureAdvisor(state.rootEquipmentId,{kind:state.kind,parentId:state.selectedParentId,nodeId:state.node?.id,question,attachment,formDraft:structureDrawerCollectValues(root)});
      if(E.structureDrawerView!==view)return;
      view.suggestions=response.data.suggestions;
      const fields=window.BFGStructureDrawerController.formFields(state.kind);
      const descriptions=view.suggestions.map((suggestion,index)=>{
        const values=fields.filter(field=>Object.hasOwn(suggestion.fields,field.id));
        return `<article class="eqv2-structure-advisor-result">
          <ul>${values.map(field=>`<li><b>${escText(field.label)}</b> ${escText(field.id==='status'?structureStatusLabel(suggestion.fields[field.id]):suggestion.fields[field.id])}</li>`).join('')}</ul>
          ${[suggestion.reason,suggestion.source,suggestion.uncertainty].filter(Boolean).map(line=>`<p>${escText(line)}</p>`).join('')}
          <button type="button" class="btn btn-sm btn-ghost" data-structure-action="apply-advice" data-index="${index}">انتقال به فیلدهای فرم</button></article>`;
      });
      results.innerHTML=descriptions.join('');
      status.textContent=[structureAdvisorMessages[response.data.notice],descriptions.length?'پیشنهاد را بررسی و برای انتقال به فرم انتخاب کنید.':'سلن برای این سطح پیشنهاد قابل استفاده‌ای پیدا نکرد.'].filter(Boolean).join(' ');
    }catch(error){
      const code=error.payload?.error||error.message;
      status.textContent=structureAdvisorMessages[code]||STRUCTURE_MESSAGES[code]||'تحلیل سلن انجام نشد.';
    }finally{button.disabled=false;}
  }
  function structureDrawerApplyAdvice(view,index){
    if(structureDrawerController.state.saving)return;
    const suggestion=view.suggestions?.[index];
    if(!suggestion)return;
    const current=structureDrawerCollectValues(view.root);
    const entries=Object.entries(suggestion.fields);
    if(entries.some(([key,value])=>current[key]!==''&&String(current[key])!==String(value))
      &&!window.confirm('بعضی فیلدها مقدار دارند. مقادیر پیشنهادی جایگزین شوند؟'))return;
    for(const [key,value] of entries){
      const field=view.root.querySelector(`[data-structure-field="${CSS.escape(key)}"]`);
      if(field)field.value=value;
    }
    structureDrawerController.setValues(structureDrawerCollectValues(view.root));
    view.root.querySelector('[data-structure-advisor-status]').textContent='پیشنهاد به فرم منتقل شد. پس از بررسی یا ویرایش، ذخیره را بزنید.';
  }
  function structureDrawerMarkup(state){
    const kindLabel=STRUCTURE_KIND_LABEL[state.kind]||'جزء ساختاری';
    const title=state.mode==='parent-picker'?'انتخاب زیرسیستم تجهیز':`${state.mode==='edit'?'ویرایش':'افزودن'} ${kindLabel}`;
    const content=state.mode==='parent-picker'?structureParentPickerHtml():`<div class="eqv2-structure-parent-banner"><b>${escText(structureDrawerParentText(state.parent))}</b></div>
      <div class="eqv2-structure-kind-readonly" aria-label="نوع ساختاری فقط‌خواندنی"><span>نوع ساختاری · تعیین‌شده بر اساس جایگاه</span><b>${escText(kindLabel)}</b></div>
      ${structureAdvisorMarkup()}
      <form id="eqv2StructureForm" class="eqv2-structure-form" novalidate>${window.BFGStructureDrawerController.formFields(state.kind).map(field=>structureDrawerFieldHtml(field,state)).join('')}</form>`;
    const actions=state.mode==='parent-picker'?`<button type="button" class="btn btn-ghost" data-structure-action="cancel">انصراف</button><button type="button" class="btn btn-ghost" data-structure-action="close">بستن</button>`:
      `<button type="button" class="btn btn-primary" data-structure-action="save" ${state.saving?'disabled':''}>${state.saving?'در حال ذخیره…':'ذخیره'}</button><button type="button" class="btn btn-ghost" data-structure-action="cancel" ${state.saving?'disabled':''}>انصراف</button><button type="button" class="btn btn-ghost" data-structure-action="close" ${state.saving?'disabled':''}>بستن</button>`;
    return`<div id="eqv2StructureDrawer" class="eqv2-structure-drawer-backdrop" role="presentation"><aside class="eqv2-structure-drawer" role="dialog" aria-modal="true" aria-labelledby="eqv2StructureDrawerTitle" dir="rtl">
      <header class="eqv2-structure-drawer-head"><div><small>پرونده تجهیز · ساختار</small><h2 id="eqv2StructureDrawerTitle">${escText(title)}</h2></div><button type="button" class="eqv2-structure-drawer-x" aria-label="بستن فرم" data-structure-action="close">×</button></header>
      <div class="eqv2-structure-drawer-body">${content}<div class="eqv2-structure-drawer-error" data-structure-error role="alert" aria-live="assertive" hidden></div></div>
      <footer class="eqv2-structure-drawer-actions">${actions}</footer></aside></div>`;
  }
  function structureDrawerMessage(error){
    if(!error)return'';
    const code=error.payload&&error.payload.error||error.code||error.message||'EQUIPMENT_API_ERROR';
    if(code==='VALIDATION_ERROR'){
      const fields=Array.isArray(error.fields)?error.fields:(error.payload&&error.payload.fields)||[];
      const labels=fields.map(field=>STRUCTURE_FORM_LABELS[field]||field).join('، ');
      return labels?`این فیلدها را بررسی کنید: ${labels}`:STRUCTURE_MESSAGES[code];
    }
    return STRUCTURE_MESSAGES[code]||'ثبت ساختار در Backend انجام نشد؛ اطلاعات فرم حفظ شده است. اتصال و گزارش سرور را بررسی کنید.';
  }
  function structureDrawerStateChanged(state){
    if(!state.open){destroyStructureDrawerView({state});return;}
    let view=E.structureDrawerView;
    if(!view||view.mode!==state.mode||view.kind!==state.kind){mountStructureDrawer(state);view=E.structureDrawerView;}
    if(!view)return;
    const root=view.root,errorNode=root.querySelector('[data-structure-error]'),saveButton=root.querySelector('[data-structure-action="save"]');
    if(errorNode){errorNode.hidden=!state.error;errorNode.textContent=structureDrawerMessage(state.error);}
    if(saveButton){saveButton.disabled=!!state.saving;saveButton.textContent=state.saving?'در حال ذخیره…':'ذخیره';}
    root.querySelectorAll('[data-structure-action="cancel"],[data-structure-action="close"],.eqv2-structure-drawer-x').forEach(button=>button.disabled=!!state.saving);
  }
  function mountStructureDrawer(state){
    if(!document.body||typeof document.body.insertAdjacentHTML!=='function')return;
    destroyStructureDrawerView();
    const previousFocus=document.activeElement;
    const pageLock={scrollX:window.scrollX||0,scrollY:window.scrollY||0,
      bodyOverflow:document.body.style?document.body.style.overflow:undefined,htmlOverflow:document.documentElement&&document.documentElement.style?document.documentElement.style.overflow:undefined};
    document.body.insertAdjacentHTML('beforeend',structureDrawerMarkup(state));
    const root=document.getElementById('eqv2StructureDrawer');if(!root)return;
    const view={root,mode:state.mode,kind:state.kind,previousFocus,pageLock,selectedParentId:'',handlers:null};
    view.handlers={
      click:event=>{
        if(event.target===root){void structureDrawerController.close('backdrop');return;}
        const button=event.target&&event.target.closest&&event.target.closest('[data-structure-action]');
        if(!button||!root.contains(button))return;
        const action=button.dataset.structureAction;
        if(action==='close'||action==='cancel'){void structureDrawerController.close(action);return;}
        if(action==='parent-continue'){void structureDrawerUseSelectedParent(root);return;}
        if(action==='advise'){void structureDrawerAdvise(view,button);return;}
        if(action==='apply-advice'){structureDrawerApplyAdvice(view,Number(button.dataset.index));return;}
        if(action==='inventory-search'){void structureDrawerSearchInventory(root);return;}
        if(action==='save'){void structureDrawerSubmit(root);}
      },
      input:event=>{
        const search=event.target&&event.target.closest&&event.target.closest('[data-structure-inventory-search]');
        if(search&&root.contains(search)){clearTimeout(E.structureInventoryTimer);E.structureInventoryTimer=setTimeout(()=>structureDrawerSearchInventory(root),220);return;}
        const field=event.target&&event.target.closest&&event.target.closest('[data-structure-field]');
        if(field&&root.contains(field))structureDrawerController.setValues(structureDrawerCollectValues(root));
      },
      change:event=>{
        const field=event.target&&event.target.closest&&event.target.closest('[data-structure-field]');
        if(field&&root.contains(field))structureDrawerController.setValues(structureDrawerCollectValues(root));
        if(event.target&&event.target.id==='eqv2StructureParentChoice'){
          view.selectedParentId=event.target.value;
          const button=root.querySelector('[data-structure-action="parent-continue"]');if(button)button.disabled=!view.selectedParentId;
          const errorNode=root.querySelector('[data-structure-error]');if(errorNode){errorNode.hidden=true;errorNode.textContent='';}
        }
      },
      submit:event=>{if(event.target&&event.target.id==='eqv2StructureForm'){event.preventDefault();void structureDrawerSubmit(root);}},
      keydown:event=>{
        if(event.key!=='Escape')return;
        event.preventDefault();event.stopPropagation();void structureDrawerController.close('escape');
      }
    };
    root.addEventListener('click',view.handlers.click);
    root.addEventListener('input',view.handlers.input);
    root.addEventListener('change',view.handlers.change);
    root.addEventListener('submit',view.handlers.submit);
    document.addEventListener('keydown',view.handlers.keydown,true);
    E.structureDrawerView=view;
    if(document.body.style)document.body.style.overflow='hidden';
    if(document.documentElement&&document.documentElement.style)document.documentElement.style.overflow='hidden';
    const focus=root.querySelector('[data-autofocus]')||root.querySelector('.eqv2-structure-form input:not([type=hidden]),.eqv2-structure-form select,.eqv2-structure-form textarea,#eqv2StructureParentChoice');
    if(focus)focus.focus({preventScroll:true});
  }
  function destroyStructureDrawerView({state}={}){
    const view=E.structureDrawerView;if(!view)return;
    clearTimeout(E.structureInventoryTimer);
    view.root.removeEventListener('click',view.handlers.click);
    view.root.removeEventListener('input',view.handlers.input);
    view.root.removeEventListener('change',view.handlers.change);
    view.root.removeEventListener('submit',view.handlers.submit);
    document.removeEventListener('keydown',view.handlers.keydown,true);
    E.structureInventoryRequestId=(Number(E.structureInventoryRequestId)||0)+1;
    view.root.remove();E.structureDrawerView=null;
    if(state&&state.closeReason!=='saved'&&E.structurePendingReject)E.structurePendingReject=null;
    if(document.body&&document.body.style)document.body.style.overflow=view.pageLock?view.pageLock.bodyOverflow:'';
    if(document.documentElement&&document.documentElement.style)document.documentElement.style.overflow=view.pageLock?view.pageLock.htmlOverflow:'';
    if(view.previousFocus&&view.previousFocus.isConnected&&typeof view.previousFocus.focus==='function')view.previousFocus.focus({preventScroll:true});
    if(view.pageLock)window.scrollTo(view.pageLock.scrollX,view.pageLock.scrollY);
  }
  function structureDrawerCollectValues(root){
    const values={};
    root.querySelectorAll('[data-structure-field]').forEach(field=>{
      values[field.dataset.structureField]=field.type==='checkbox'?field.checked:field.value;
    });
    const query=root.querySelector('[data-structure-inventory-search]');if(query)values.inventoryQuery=query.value;
    return values;
  }
  function structureDrawerRenderInventory(root){
    const state=structureDrawerController.state,select=root.querySelector('[data-structure-field="inventoryItemId"]');
    if(select){const selected=state.values.inventoryItemId||select.value;select.innerHTML=structureInventoryChoices({...state,values:{...state.values,inventoryItemId:selected}});select.value=selected;}
    const result=root.querySelector('[data-inventory-results]');if(result)result.textContent=E.structureInventoryResults.length?`${faText(E.structureInventoryResults.length)} قلم موجود؛ موجودی فقط خواندنی است.`:'قلمی پیدا نشد. قلم جدید در اطلاعات مرجع انبار ساخته نمی‌شود.';
  }
  async function structureDrawerSearchInventory(root){
    const query=String(root.querySelector('[data-structure-inventory-search]')?.value||'').trim();
    const requestId=E.structureInventoryRequestId=(Number(E.structureInventoryRequestId)||0)+1;
    if(!query){E.structureInventoryResults=[];structureDrawerRenderInventory(root);return;}
    const result=root.querySelector('[data-inventory-results]');if(result)result.textContent='در حال جستجوی قلم موجود…';
    try{
      const response=await R().inventoryItems(query);
      if(requestId!==E.structureInventoryRequestId||root!==E.structureDrawerView?.root)return;
      E.structureInventoryResults=Array.isArray(response.data)?response.data:[];structureDrawerRenderInventory(root);
    }catch(error){
      if(requestId!==E.structureInventoryRequestId||root!==E.structureDrawerView?.root)return;
      E.structureInventoryResults=[];if(result)result.textContent='جستجوی انبار در دسترس نیست؛ هیچ قلمی ساخته نشده است.';
    }
  }
  async function structureDrawerUseSelectedParent(root){
    const id=String(root.querySelector('#eqv2StructureParentChoice')?.value||'');
    const parent=structureNodeById(id);
    if(!id||!window.BFGStructureDrawerController.isValidParent('main-component',parent)){
      const message=root.querySelector('[data-structure-error]');if(message){message.hidden=false;message.textContent=STRUCTURE_MESSAGES.SUBSYSTEM_REQUIRED;}return;
    }
    await structureDrawerController.close('parent-selected');
    openStructureForm({mode:'create',kind:'main-component',parent});
  }
  function structureDrawerOpen(config={}){
    if(!structureDrawerController){toast('فرم مستقل ساختار تجهیز بارگذاری نشده است.',1);return;}
    E.structureInventoryResults=[];
    const rootEquipmentId=config.rootEquipmentId??((E.structure&&E.structure.rootId)||E.detailId||'');
    const parent=config.parent||null;
    const selectedParentId=config.selectedParentId??(parent&&parent.id!=null?String(parent.id):null);
    if(!structureDrawerController.open({...config,rootEquipmentId:String(rootEquipmentId||''),selectedParentId,parent}))return;
  }
  function structureDrawerEntitySnapshot(node){
    if(!node)return null;
    const snapshot={
      id:String(node.id),code:node.code||null,name:node.name||null,nodeKind:node.nodeKind||node.node_kind||null,
      rowVersion:Number(node.rowVersion??node.row_version)||null,row_version:Number(node.row_version??node.rowVersion)||null,
      parentId:node.parentId||node.parent_id||node.parent||null,rootEquipmentId:node.rootEquipmentId||E.structure&&E.structure.rootId||null,
      archived:!!node.archived,is_active:node.is_active,isActive:node.isActive,status:node.status,
      path:Array.isArray(node.path)?node.path.map(step=>typeof step==='object'?{...step,id:String(step.id||step)}:{id:String(step)}):[]
    };
    if(node.inventoryItem)snapshot.inventoryItem={...node.inventoryItem};
    return snapshot;
  }
  function structureFormInitialValues(mode,kind,node,prefill){
    if(mode==='edit')return{
      name:node.name||'',code:node.code||'',componentType:node.componentType||'',brand:node.brand||'',
      manufacturer:node.manufacturer||node.maker||'',model:node.model||'',partNumber:node.partNumber||'',serial:node.serial||'',
      requiredQuantity:node.requiredQuantity==null?'':node.requiredQuantity,unit:node.unit||'',status:node.status||'',crit:node.crit||'',
      technicalSpecification:node.technicalSpecification||'',structureNotes:node.structureNotes||'',inventoryItemId:node.inventoryItemId||'',addCriticalSpare:prefill?.addCriticalSpare===true
    };
    return{status:'active',...(kind==='subsystem'?{}:{inventoryItemId:''}),...(prefill||{})};
  }
  function openStructureForm({mode='create',kind,parent,node=null,prefill=null}={}){
    const st=E.structure,contract=window.BFGStructureDrawerController;
    if(!st||!contract||!contract.formFields(kind)){toast('ساختار تجهیز یا فرم مستقل در دسترس نیست.',1);return;}
    if(mode==='create'&&!contract.isValidParent(kind,parent)){toast(STRUCTURE_MESSAGES.STRUCTURE_PARENT_KIND_INVALID,1);return;}
    if(mode==='edit'&&(!node||node.archived||String(node.nodeKind)!==String(kind))){toast(STRUCTURE_MESSAGES.STRUCTURE_NODE_NOT_FOUND,1);return;}
    const values=structureFormInitialValues(mode,kind,node,prefill);
    if(prefill&&prefill.inventoryItemId)values.inventoryItemId=prefill.inventoryItemId;
    if(E.structurePendingReject&&!prefill)E.structurePendingReject=null;
    const parentSnapshot=structureDrawerEntitySnapshot(parent),nodeSnapshot=structureDrawerEntitySnapshot(node);
    structureDrawerOpen({mode,kind,parent:parentSnapshot,node:nodeSnapshot,values,rootEquipmentId:String(st.rootId||st.rootEquipmentId||E.detailId||''),selectedParentId:parentSnapshot&&parentSnapshot.id||null});
  }
  function structureDrawerRequestParentPath(parent){
    const path=(parent&&parent.nodeKind==='equipment'?[]:(parent&&parent.path||[])).map(item=>String(item.id||item));
    E.structurePanel=path;E.structureFocus=null;
    if(parent&&parent.nodeKind!=='equipment')E.structureExpanded[parent.id]=true;
  }
  async function structureDrawerSaved(result,state){
    const node=result.data;
    if(E.structurePendingReject){const draftId=E.structurePendingReject;E.structurePendingReject=null;await R().actionReject(draftId).catch(()=>{});}
    if(state.values.addCriticalSpare)E.spares=null;
    E.structureSelected=String(node.id);E.structureQuery='';E.tab='structure';
    structureDrawerRequestParentPath(state.mode==='edit'?(structureNodeById(node.parent)||state.parent):state.parent);
    toast(state.mode==='edit'?'ویرایش جزء ساختاری پس از commit در PostgreSQL ثبت شد.':'جزء ساختاری پس از پاسخ 201 و commit در PostgreSQL ثبت شد.');
    await refreshStructure({keepPanel:true});
    requestAnimationFrame(()=>{
      const row=document.querySelector(`[data-structure-node="${CSS.escape(String(node.id))}"]`);
      if(row&&typeof row.scrollIntoView==='function')row.scrollIntoView({block:'nearest'});
    });
  }
  async function structureDrawerSubmit(root){
    const contract=window.BFGStructureDrawerController,state=structureDrawerController.state;
    if(state.mode==='parent-picker')return;
    const values=structureDrawerCollectValues(root);structureDrawerController.setValues(values);
    const errors=contract.validate(state.kind,values);
    if(errors.length){state.error={code:'VALIDATION_ERROR',fields:errors};structureDrawerStateChanged(state);return;}
    let payload,save,expectedStatus;
    try{
      if(state.mode==='edit'){
        payload=contract.updatePayload({rootEquipmentId:state.rootEquipmentId,node:state.node,kind:state.kind,values});
        expectedStatus=200;
        save=()=>R().structureUpdate(state.node.id,payload);
      }else{
        if(!state.rootEquipmentId||!state.parent||String(state.selectedParentId)!==String(state.parent.id))throw Object.assign(new Error('STRUCTURE_PARENT_KIND_INVALID'),{code:'STRUCTURE_PARENT_KIND_INVALID'});
        const clean=contract.cleanValues(state.kind,values);
        const fingerprint=contract.stableStringify({rootEquipmentId:state.rootEquipmentId,parentId:state.selectedParentId,nodeKind:state.kind,...clean});
        const requestId=structureDrawerController.requestIdFor(fingerprint,window.crypto);
        payload=contract.createPayload({rootEquipmentId:state.rootEquipmentId,parent:state.parent,kind:state.kind,values,requestId});
        if(String(payload.parentId)!==String(state.selectedParentId))throw Object.assign(new Error('STRUCTURE_PARENT_KIND_INVALID'),{code:'STRUCTURE_PARENT_KIND_INVALID'});
        expectedStatus=201;
        save=()=>R().structureCreate(payload);
      }
    }catch(error){state.error=error;structureDrawerStateChanged(state);return;}
    await structureDrawerController.submit({payload,save,expectedStatus,validationErrors:[]});
  }
  function structureAdd(parentId){
    const st=E.structure;if(!st||!st.capabilities.create){toast('مجوز ایجاد جزء ساختاری را ندارید',1);return;}
    const parent=structureNodeById(parentId);if(!parent){structureSay({message:'STRUCTURE_PARENT_KIND_INVALID'});return;}
    const childKind=structureAllowedChildren(parent.nodeKind,parent)[0];
    if(!childKind){structureSay({message:'STRUCTURE_PARENT_KIND_INVALID'});return;}
    openStructureForm({mode:'create',kind:childKind,parent});
  }
  function structureAddRoot(){
    const st=E.structure;if(!st||!st.capabilities.create){toast('مجوز افزودن زیرسیستم تجهیز را ندارید.',1);return;}
    const parent=structureNodeById(st.root&&st.root.id);
    if(!parent||!window.BFGStructureDrawerController.isValidParent('subsystem',parent)){structureSay({message:'STRUCTURE_PARENT_KIND_INVALID'});return;}
    openStructureForm({mode:'create',kind:'subsystem',parent});
  }
  function structureAddMainComponent(){
    if(!E.structure||!E.structure.capabilities.create){toast('مجوز افزودن قطعه اصلی زیرسیستم را ندارید.',1);return;}
    const candidates=flattenStructure(E.structure.nodes).filter(node=>node.nodeKind==='subsystem'&&!node.archived);
    if(!candidates.length){toast(STRUCTURE_MESSAGES.SUBSYSTEM_REQUIRED,1);return;}
    const selected=structureNodeById(E.structureSelected);
    const parent=selected&&window.BFGStructureDrawerController.isValidParent('main-component',selected)?selected:candidates.length===1?candidates[0]:null;
    if(parent){openStructureForm({mode:'create',kind:'main-component',parent});return;}
    structureDrawerOpen({mode:'parent-picker',kind:'main-component',parent:null,values:{}});
  }
  function structureEdit(nodeId,addCriticalSpare=false){
    const st=E.structure;if(!st||!st.capabilities.update){toast('مجوز ویرایش ساختار را ندارید',1);return;}
    const node=structureNodeById(nodeId);if(!node)return;
    const parent=structureNodeById(node.parentId);if(!parent)return;
    openStructureForm({mode:'edit',kind:node.nodeKind,node,parent,prefill:addCriticalSpare?{addCriticalSpare:true}:null});
  }
  function structureMoveModal(nodeId){
    const st=E.structure;if(!st)return;
    const node=structureNodeById(nodeId);if(!node)return;
    const candidates=[{id:st.root.id,name:st.root.name||st.root.code,nodeKind:'equipment',path:[]},...flattenStructure(st.nodes)]
      .filter(item=>structureAllowedChildren(item.nodeKind).includes(node.nodeKind))
      .filter(item=>String(item.id)!==String(node.id))
      .filter(item=>!(item.path||[]).some(step=>String(step.id||step)===String(node.id)))
      .filter(item=>!item.archived);
    modal(mhead('جابه‌جایی بخش ساختار تجهیز')+`<div class="m-body">
      <div class="eqv2-wizard-note">سطح بخش مقصد باید مجاز باشد و چرخه‌ای در ساختار تجهیز ایجاد نکند. جابه‌جایی در Audit ثبت می‌شود و سوابق حفظ می‌شوند.</div>
      <div class="field"><label>بخش مقصد *</label><select id="stMoveParent">${candidates.map(item=>`<option value="${escText(item.id)}">${escText((item.code?item.code+' — ':'')+item.name)} (${escText(STRUCTURE_KIND_LABEL[item.nodeKind]||item.nodeKind)})</option>`).join('')||'<option value="">بخش سازگار پیدا نشد</option>'}</select></div>
      ${st.capabilities.moveAcrossEquipment?`<label class="checkline"><input type="checkbox" id="stMoveCross"> انتقال به تجهیز دیگر (مجوز ویژه + تأیید صریح)</label>
      <div class="field"><label>کد یا نام تجهیز مقصد</label><input id="stMoveCrossQuery" placeholder="جستجوی تجهیز مقصد…"><button type="button" class="btn btn-sm btn-ghost" onclick="eqv2StructureCrossSearch()">جستجو</button></div>
      <div class="field"><label>تجهیز مقصد</label><select id="stMoveCrossRoot"><option value="">— تجهیز جاری —</option></select></div>
      <label class="checkline"><input type="checkbox" id="stMoveCrossConfirm"> انتقال بین دو تجهیز را صریحاً تأیید می‌کنم</label>`:''}
      <div class="field"><label>دلیل جابه‌جایی *</label><textarea id="stMoveReason" rows="2"></textarea></div>
      <div class="m-foot"><button class="btn btn-primary" onclick="eqv2StructureMoveSubmit('${escText(node.id)}')">ثبت جابه‌جایی</button><button class="btn btn-ghost" onclick="closeModal()">انصراف</button></div></div>`,true);
  }
  async function structureCrossSearch(){
    const q=String(document.getElementById('stMoveCrossQuery')?.value||'').trim();
    if(!q)return;
    try{
      const result=await R().list({q,limit:10});
      const select=document.getElementById('stMoveCrossRoot');
      if(select)select.innerHTML='<option value="">— تجهیز جاری —</option>'+(result.data||[]).map(row=>`<option value="${escText(row.id)}">${escText(row.code+' — '+row.name)}</option>`).join('');
    }catch(error){structureSay(error);}
  }
  async function structureMoveSubmit(nodeId){
    const st=E.structure;if(!st)return;
    const node=structureNodeById(nodeId);if(!node)return;
    const reason=String(document.getElementById('stMoveReason')?.value||'').trim();
    const cross=document.getElementById('stMoveCross')?.checked;
    const crossRoot=document.getElementById('stMoveCrossRoot')?.value||'';
    const payload={rowVersion:Number(node.rowVersion),reason};
    if(cross&&crossRoot){
      if(!document.getElementById('stMoveCrossConfirm')?.checked){toast(STRUCTURE_MESSAGES.CROSS_EQUIPMENT_CONFIRMATION_REQUIRED,1);return;}
      try{
        const other=await R().structure(crossRoot);
        const candidates=[{id:other.data.root.id,nodeKind:'equipment',path:[]},...flattenStructure(other.data.nodes)];
        const select=window.prompt('شناسه بخش مقصد را از ساختار تجهیز مقصد وارد کنید:','');
        const parent=candidates.find(item=>String(item.id)===String(select));
        if(!parent){toast('بخش مقصد در تجهیز مقصد پیدا نشد.',1);return;}
        payload.parentId=parent.id;payload.confirmCrossEquipment=true;
      }catch(error){structureSay(error);return;}
    }else{
      payload.parentId=document.getElementById('stMoveParent')?.value||'';
    }
    if(!payload.parentId){toast('بخش مقصد را انتخاب کنید.',1);return;}
    try{
      await R().structureMove(node.id,payload);
      closeModal();toast('جابه‌جایی در Backend ثبت شد و روابط تاریخی حفظ ماند.');
      await refreshStructure({keepPanel:true});
    }catch(error){structureSay(error);}
  }
  async function structureArchive(nodeId){
    const st=E.structure;if(!st)return;
    const node=structureNodeById(nodeId);
    if(!node){toast('بخش انتخاب‌شده در ساختار تجهیز پیدا نشد؛ ساختار را تازه‌سازی کنید.',1);return;}
    if(node.archived){toast('این بخش از قبل بایگانی شده است؛ برای بازگرداندن آن از بازیابی استفاده کنید.',1);return;}
    if(!st.capabilities||!st.capabilities.archive){toast('مجوز بایگانی ساختار تجهیز را ندارید.',1);return;}
    if(node.canArchive===false||node.can_archive===false){toast(String(node.archiveReason||node.archive_reason||'این بخش قابل بایگانی نیست.'),1);return;}
    const entered=window.prompt('دلیل بایگانی الزامی است:');
    if(entered===null)return;
    const reason=String(entered).trim();
    if(!reason){toast('دلیل بایگانی الزامی است؛ هیچ تغییری انجام نشد.',1);return;}
    if(!window.confirm(`آیا «${node.name||node.code||'این بخش'}» را بایگانی نرم می‌کنید؟ سوابق حفظ می‌شوند و بخش از نمای فعال برداشته می‌شود.`))return;
    try{
      const result=await R().structureArchive(node.id,reason,Number(node.rowVersion));
      if(!result||result.archived!==true||result.historyPreserved!==true||!result.data)throw Object.assign(new Error('NOT_COMMITTED'),{payload:{error:'NOT_COMMITTED'}});
      if(!E.structureArchived&&String(E.structureSelected)===String(node.id))E.structureSelected=null;
      if(String(E.structureFocus)===String(node.id))E.structureFocus=null;
      E.structurePanel=(E.structurePanel||[]).filter(id=>String(id)!==String(node.id));
      toast('بایگانی نرم با دلیل ثبت شد؛ سوابق و Audit حفظ شدند.');
      await refreshStructure({keepPanel:true});
    }catch(error){structureSay(error);}
  }
  async function structureRestore(nodeId){
    const st=E.structure;if(!st)return;
    const node=structureNodeById(nodeId);
    if(!node){toast('بخش انتخاب‌شده در ساختار تجهیز پیدا نشد؛ ساختار را تازه‌سازی کنید.',1);return;}
    if(!node.archived){toast('این بخش بایگانی نشده است.',1);return;}
    if(!st.capabilities||!st.capabilities.archive){toast('مجوز بازیابی ساختار تجهیز را ندارید.',1);return;}
    const entered=window.prompt('دلیل بازیابی الزامی است:');
    if(entered===null)return;
    const reason=String(entered).trim();
    if(!reason){toast('دلیل بازیابی الزامی است؛ هیچ تغییری انجام نشد.',1);return;}
    if(!window.confirm(`آیا «${node.name||node.code||'این بخش'}» را با حفظ سوابق بازیابی می‌کنید؟`))return;
    try{
      const result=await R().structureRestore(node.id,{reason,rowVersion:Number(node.rowVersion)});
      if(!result||result.committed!==true||result.restored!==true||result.historyPreserved!==true||!result.data)throw Object.assign(new Error('NOT_COMMITTED'),{payload:{error:'NOT_COMMITTED'}});
      toast('بخش با مجوز، دلیل و Audit بازیابی شد.');
      await refreshStructure({keepPanel:true});
    }catch(error){structureSay(error);}
  }
  function structureFocusNode(id){
    const node=structureNodeById(id);if(!node)return;
    E.structurePanel=((node.path||[]).map(step=>step.id||step).filter(stepId=>String(stepId)!==String(id)));
    E.structureFocus=id;
    renderCurrentDetail().catch(showError);
  }
  function structureClosePanel(){
    if(E.structureFocus){E.structureFocus=null;}
    else E.structurePanel=(E.structurePanel||[]).slice(0,-1);
    renderCurrentDetail().catch(showError);
  }
  function structureCrumbTo(index){
    E.structurePanel=(E.structurePanel||[]).slice(0,index);
    E.structureFocus=null;
    renderCurrentDetail().catch(showError);
  }
  async function structureArchivedToggle(){
    E.structureArchived=!E.structureArchived;
    await refreshStructure({keepPanel:true});
  }

  /* ---------- Mission D4 / Phase 3: critical spare parts (real inventory links only) ---------- */
  const SPARE_MESSAGES={
    INVENTORY_ITEM_REQUIRED:'ابتدا یک قلم واقعی انبار را جستجو و انتخاب کنید؛ قلم جدید اینجا ساخته نمی‌شود.',
    INVENTORY_ITEM_NOT_FOUND:'قلم انتخاب‌شده از اطلاعات مرجع انبار موجود نیست؛ فقط قلم موجود قابل اتصال است.',
    SPARE_RELATION_TYPE_INVALID:'نوع اتصال قطعه یدکی معتبر نیست.',
    SPARE_LINK_EXISTS:'این قلم قبلاً به پرونده همین تجهیز متصل شده است؛ از ویرایش همان ردیف استفاده کنید.',
    SPARE_LINK_NOT_FOUND:'اتصال قطعه یدکی پیدا نشد؛ فهرست را تازه‌سازی کنید.',
    SPARE_LINK_ALREADY_ARCHIVED:'این اتصال قبلاً بایگانی شده است؛ برای استفاده دوباره آن را بازیابی کنید.',
    SPARE_LINK_NOT_ARCHIVED:'این اتصال بایگانی نشده است.',
    REQUIRED_QUANTITY_INVALID:'تعداد موردنیاز باید عددی مثبت یا صفر و در محدوده مجاز باشد.',
    NO_EDITABLE_FIELDS:'تغییری برای ذخیره وجود ندارد.',
    ROW_VERSION_REQUIRED:'نسخه رکورد (row_version) لازم است؛ فهرست قطعات را تازه‌سازی کنید.',
    VERSION_CONFLICT:'این اتصال هم‌زمان تغییر کرده است؛ فهرست قطعات را تازه‌سازی کنید.',
    ARCHIVE_REASON_REQUIRED:'دلیل بایگانی الزامی است؛ هیچ تغییری انجام نشد.',
    RESTORE_REASON_REQUIRED:'دلیل بازیابی الزامی است؛ هیچ تغییری انجام نشد.',
    VALIDATION_ERROR:'فیلدهای الزامی یا مقادیر واردشده معتبر نیستند.',
    PERMISSION_DENIED:'مجوز این عملیات قطعات یدکی را ندارید.',
    EQUIPMENT_SCOPE_DENIED:'این تجهیز در محدوده دسترسی شما نیست.',
    EQUIPMENT_NOT_FOUND:'این تجهیز در پایگاه‌داده پیدا نشد؛ فهرست تجهیزات را تازه‌سازی کنید.',
    ROOT_EQUIPMENT_NOT_FOUND:'تجهیز انتخاب‌شده پیدا نشد؛ قطعات یدکی فقط در پرونده خود تجهیز مدیریت می‌شوند.',
    NOT_COMMITTED:'سرور ثبت را تأیید نکرد؛ فرم باز مانده و اطلاعات حفظ شد.',
    SERVER_REQUIRED:'اتصال به سرور برقرار نیست؛ قطعات یدکی فقط از سرور خوانده می‌شوند.',
    SPARES_FAILED:'فهرست قطعات یدکی از سرور دریافت نشد؛ دوباره تلاش کنید.'
  };
  const spareSay=error=>{const code=error&&(error.payload&&error.payload.error||error.code||error.message);toast(SPARE_MESSAGES[code]||('عملیات قطعات یدکی انجام نشد: '+(code||'REQUEST_FAILED')),1);};
  const spareRelationLabel=value=>{const found=((E.spares&&E.spares.relationTypes)||[]).find(item=>item.value===value);return found?found.label:(value==='key-spare'?'قطعه یدکی حیاتی':value==='general-spare'?'قطعه یدکی عمومی':(value||''));};
  function normalizeSpares(id,payload){
    const data=payload&&typeof payload==='object'?payload:{};
    return{equipmentId:(data.equipment&&data.equipment.id)||id,equipment:data.equipment||null,
      parts:Array.isArray(data.parts)?data.parts:[],relationTypes:Array.isArray(data.relationTypes)?data.relationTypes:[],
      targets:Array.isArray(data.targets)?data.targets:[],
      capabilities:data.capabilities||{},includeArchived:!!data.includeArchived};
  }
  async function loadSpares(id){
    if(typeof R().spares!=='function'){E.spares=normalizeSpares(id,{});E.sparesError='SERVER_REQUIRED';if(E.tab==='spares')await renderCurrentDetail();return;}
    try{
      const result=await R().spares(id,{includeArchived:E.sparesArchived});
      E.spares=normalizeSpares(id,result.data);E.sparesError=null;
    }catch(error){
      E.sparesError=(error.payload&&error.payload.error)||error.message||'SPARES_FAILED';
      E.spares=normalizeSpares(id,{});
    }
    if(E.tab==='spares')await renderCurrentDetail();
  }
  function queueSparesLoad(id){
    if(E.sparesLoading)return;
    E.sparesLoading=true;
    setTimeout(()=>{loadSpares(id).finally(()=>{E.sparesLoading=false;});},0);
  }
  function spareShortage(part){
    if(part.quantityRequired==null||part.stockAvailable==null)return false;
    return Number(part.stockAvailable)<Number(part.quantityRequired);
  }
  function spareStockCell(part){
    if(part.stockAvailable==null)return notRecorded;
    const shortage=spareShortage(part);
    return`<div class="eqv2-spare-stock${shortage?' is-short':''}">
      <b>${faText(part.stockAvailable)} ${escText(part.unit||'')}</b>
      <small>در دست: ${part.stockOnHand==null?'—':faText(part.stockOnHand)} · رزرو: ${part.stockReserved==null?'—':faText(part.stockReserved)}</small>
      ${shortage?'<span class="badge b-red">کسری نسبت به نیاز تجهیز</span>':''}
    </div>`;
  }
  function sparePurchaseCell(part){
    const purchase=part.lastPurchase;
    if(!purchase||!purchase.at)return notRecorded;
    return`<div><b>${formatDate(purchase.at)}</b><small class="muted">رسید ${escText(purchase.entryNo||'—')} · ${purchase.qty==null?'—':faText(purchase.qty)} ${escText(part.unit||'')}</small></div>`;
  }
  function sparesSection(a){
    const equipmentId=E.detailId||a.id;
    const sp=E.spares;
    const ext=a.ext||{},keyParts=Array.isArray(ext.keyParts)?ext.keyParts:[];
    const noted=keyParts.length?`<section class="eqv2-subsection"><h3>قطعات کلیدیِ متنی در پرونده قدیمی</h3><p class="muted">این متن از ext آمده و قلم انبار یا موجودی محسوب نمی‌شود؛ برای اتصال واقعی، قلم را از جستجوی انبار اضافه کنید.</p><div class="eqv2-parts-chips">${keyParts.map(part=>`<span>${escText(part)}</span>`).join('')}</div></section>`:'';
    const heading=(actions='')=>`<section class="eqv2-section-heading"><div><span>اتصال واقعی به قلم انبار · موجودی فقط از دفتر انبار</span><h2>قطعات یدکی حیاتی</h2><p>فقط لینک‌های واقعی asset_spare_parts و items نمایش داده می‌شوند؛ موجودی تایپ‌کردنی نیست و قلم جدید خودکار ساخته نمی‌شود.</p></div><div class="eqv2-section-actions">${actions}</div></section>`;
    if(!sp||String(sp.equipmentId)!==String(equipmentId)){
      queueSparesLoad(equipmentId);
      return`${heading()}<div class="eqv2-loading">در حال دریافت قطعات یدکی حیاتی…</div>${noted}`;
    }
    if(E.sparesError){
      return`${heading(`<button class="btn btn-sm btn-ghost" onclick="eqv2SparesRefresh()">تلاش دوباره</button>`)}<div class="eqv2-wizard-note">${escText(SPARE_MESSAGES[E.sparesError]||SPARE_MESSAGES.SPARES_FAILED)}</div>${empty('فهرست قطعات یدکی در دسترس نیست.')}${noted}`;
    }
    const caps=sp.capabilities||{};
    const actions=`${caps.create&&!E.sparesArchived?`<button class="btn btn-sm btn-primary" onclick="eqv2SpareAdd()">＋ افزودن قطعه یدکی</button>`:''}
      ${caps.suggest?`<button class="btn btn-sm btn-ghost" onclick="eqv2SpareSuggest()" ${E.sparesSuggesting?'disabled':''}>${E.sparesSuggesting?'در حال تحلیل…':'✦ پیشنهاد سلن'}</button>`:''}
      ${caps.archive?`<button class="btn btn-sm btn-ghost" onclick="eqv2SparesArchivedToggle()">${E.sparesArchived?'نمایش قطعات فعال':'نمایش بایگانی'}</button>`:''}
      <button class="btn btn-sm btn-ghost" onclick="eqv2SparesRefresh()">تازه‌سازی</button>`;
    const parts=sp.parts||[];
    const table=parts.length?`<div class="eqv2-table-wrap eqv2-spares-wrap"><table class="eqv2-spares-table"><thead><tr>
        <th>کد قلم</th><th>نام قلم</th><th>هدف اتصال</th><th>نوع اتصال</th><th>تعداد موردنیاز</th><th>موجودی قابل دسترس</th><th>حداقل موجودی</th><th>آخرین خرید</th><th>ملاحظات</th><th>عملیات</th>
      </tr></thead><tbody>${parts.map(part=>`<tr data-spare-item="${escText(part.itemId)}" data-spare-target="${escText(part.targetId||'')}" class="${part.archived?'is-archived':''}">
        <td><span class="eqv2-code">${escText(part.code||'—')}</span></td>
        <td><b>${escText(part.name||'—')}</b>${part.partNumber?`<div class="muted">شماره فنی: ${escText(part.partNumber)}</div>`:''}${part.brand?`<div class="muted">برند: ${escText(part.brand)}</div>`:''}${part.itemArchived?'<span class="badge b-orange">قلم انبار بایگانی شده</span>':''}</td>
        <td>${spareTargetCell(part)}</td>
        <td><span class="badge ${part.relationType==='key-spare'?'b-red':'b-gray'}">${escText(part.relationLabel||spareRelationLabel(part.relationType))}</span></td>
        <td>${part.quantityRequired==null?notRecorded:faText(part.quantityRequired)+' '+escText(part.unit||'')}</td>
        <td>${spareStockCell(part)}</td>
        <td>${part.minStock==null?notRecorded:faText(part.minStock)}</td>
        <td>${sparePurchaseCell(part)}</td>
        <td>${part.notes?escText(part.notes):notRecorded}${part.archived&&part.deleteReason?`<div class="muted">دلیل بایگانی: ${escText(part.deleteReason)}</div>`:''}</td>
        <td class="eqv2-spare-actions">${part.archived
          ?(caps.archive?`<button class="btn btn-sm btn-ghost" onclick="eqv2SpareRestore('${escText(part.itemId)}','${escText(part.targetId||'')}')">بازیابی</button>`:'')
          :`${caps.update?`<button class="btn btn-sm btn-ghost" onclick="eqv2SpareEdit('${escText(part.itemId)}','${escText(part.targetId||'')}')">ویرایش</button>`:''}${caps.archive?`<button class="btn btn-sm btn-danger" onclick="eqv2SpareArchive('${escText(part.itemId)}','${escText(part.targetId||'')}')">بایگانی</button>`:''}`}
          ${part.archived?'<span class="badge b-gray">بایگانی‌شده</span>':''}</td>
      </tr>`).join('')}</tbody></table></div>`
      :empty(E.sparesArchived?'اتصال بایگانی‌شده‌ای ثبت نشده است.':'هنوز قطعه یدکی به قلم واقعی انبار متصل نشده است؛ با «افزودن قطعه یدکی» فقط قلم موجود انبار را جستجو و متصل کنید.');
    return`${heading(actions)}${sparesSuggestionPanel()}${table}${noted}`;
  }
  function spareTargetCell(part){
    const target=part.target||{};
    const label=target.label||target.kind||'';
    const name=target.name||target.code||(target.id&&String(target.id)===String(E.spares&&E.spares.equipmentId)?'خود تجهیز':'');
    if(!name&&!label)return notRecorded;
    return`<div><b>${escText(name||'—')}</b>${label?`<div class="muted">${escText(label)}</div>`:''}</div>`;
  }
  function spareTargetOptions(selected){
    const targets=(E.spares&&E.spares.targets)||[];
    if(!targets.length)return'<option value="">هدفی در ساختار ثبت نشده است</option>';
    return targets.map(target=>{
      const name=target.name||target.code||target.id;
      const label=`${name} — ${target.label||target.kind||''}`;
      return`<option value="${escText(target.id)}" ${String(selected||targets[0].id)===String(target.id)?'selected':''}>${escText(label)}</option>`;
    }).join('');
  }
  function spareRelationOptions(selected,targetId){
    const types=(E.spares&&E.spares.relationTypes&&E.spares.relationTypes.length)?E.spares.relationTypes:[{value:'key-spare',label:'قطعه یدکی حیاتی'},{value:'general-spare',label:'قطعه یدکی عمومی'}];
    const targets=(E.spares&&E.spares.targets)||[];
    const target=targets.find(item=>String(item.id)===String(targetId))||targets[0]||null;
    const criticalAllowed=target?target.criticalAllowed!==false:true;
    const allowed=types.filter(item=>item.value!=='key-spare'||criticalAllowed);
    const fallback=allowed.some(item=>item.value===selected)?selected:(allowed[0]?allowed[0].value:'general-spare');
    return allowed.map(item=>`<option value="${escText(item.value)}" ${String(fallback)===item.value?'selected':''}>${escText(item.label)}</option>`).join('');
  }
  function spareItemOptions(){
    const items=E.sparesItemResults||[];
    if(!items.length)return'<option value="">قلمی یافت نشد؛ عبارت دیگری را جستجو کنید</option>';
    return'<option value="">— انتخاب قلم واقعی —</option>'+items.map(item=>{
      const label=`${item.code||'بدون کد'} — ${item.name||'بدون نام'} · موجودی قابل دسترس: ${faText(item.available==null?0:item.available)} ${item.unit||''}`;
      return`<option value="${escText(item.id)}">${escText(label)}</option>`;
    }).join('');
  }
  function spareFormModal(mode,part){
    const isEdit=mode==='edit';
    const targets=(E.spares&&E.spares.targets)||[];
    const defaultTarget=targets[0]?targets[0].id:'';
    const editTargetId=isEdit?(part.targetId||(part.target&&part.target.id)||defaultTarget):defaultTarget;
    const targetField=isEdit
      ?`<div class="field"><label>هدف اتصال (غیرقابل تغییر)</label><input value="${escText(spareTargetLabel(editTargetId))}" disabled></div>`
      :`<div class="field"><label>هدف اتصال *</label><select id="spareTarget" onchange="eqv2SpareTargetChanged()">${spareTargetOptions(defaultTarget)}</select><small>قطعه حیاتی فقط برای «جزء اصلی» و «جزء فرعی» مجاز است؛ خود تجهیز و زیرسیستم فقط قطعه یدکی عمومی می‌پذیرند.</small></div>`;
    modal(mhead(isEdit?'ویرایش اتصال قطعه یدکی':'افزودن قطعه یدکی')+`<div class="m-body">
      <div class="eqv2-wizard-note">فقط قلم واقعی انبار قابل اتصال است؛ موجودی تایپ نمی‌شود و فقط از دفتر انبار خوانده می‌شود. ایجاد قلم جدید فقط از مسیر رسمی انبار انجام می‌شود.</div>
      ${targetField}
      ${isEdit?`<div class="field"><label>قلم انبار (غیرقابل تغییر)</label><input value="${escText((part.code||'')+' — '+(part.name||''))}" disabled></div>`:`
      <div class="field"><label>جستجوی قلم واقعی انبار *</label>
        <div class="eqv2-spare-search"><input id="spareItemQuery" type="search" placeholder="کد، نام، شماره فنی یا برند…" onkeydown="if(event.key==='Enter'){event.preventDefault();eqv2SpareItemSearch()}"><button class="btn btn-sm btn-ghost" onclick="eqv2SpareItemSearch()" ${E.sparesSearching?'disabled':''}>جستجو</button></div>
      </div>
      <div class="field"><label>قلم یافت‌شده *</label><select id="spareItemSelect">${spareItemOptions()}</select><small>اتصال به قلم تکراری مجاز نیست؛ هر قلم یک اتصال فعال در پرونده دارد.</small></div>`}
      <div class="field"><label>نوع اتصال *</label><select id="spareRelation">${spareRelationOptions(isEdit?part.relationType:'key-spare',editTargetId)}</select></div>
      <div class="field"><label>تعداد موردنیاز تجهیز</label><input id="spareQuantity" type="number" min="0" step="0.001" value="${isEdit&&part.quantityRequired!=null?escText(part.quantityRequired):''}" placeholder="خالی = ثبت نشده"></div>
      <div class="field"><label>ملاحظات</label><textarea id="spareNotes" rows="2" maxlength="2000">${isEdit&&part.notes?escText(part.notes):''}</textarea></div>
      <div class="eqv2-spare-form-error" id="spareFormError" hidden></div>
      <div class="m-foot"><button class="btn btn-primary" id="spareSubmitBtn" onclick="eqv2SpareSubmit('${mode}','${isEdit?escText(part.itemId):''}','${isEdit?escText(editTargetId):''}')">${isEdit?'ذخیره تغییرات':'ثبت اتصال'}</button><button class="btn btn-ghost" onclick="closeModal()">انصراف</button></div>
    </div>`,true);
  }
  function spareTargetLabel(targetId){
    const targets=(E.spares&&E.spares.targets)||[];
    const target=targets.find(item=>String(item.id)===String(targetId));
    if(!target)return targetId||'—';
    return`${target.name||target.code||target.id} — ${target.label||target.kind||''}`;
  }
  function spareTargetChanged(){
    const select=document.getElementById('spareTarget');
    const relation=document.getElementById('spareRelation');
    if(select&&relation)relation.innerHTML=spareRelationOptions(relation.value,select.value);
  }
  function spareAdd(){
    if(!E.spares||!E.spares.capabilities.create){toast('مجوز افزودن قطعه یدکی را ندارید.',1);return;}
    E.sparesItemResults=[];
    spareFormModal('create',null);
  }
  function spareEdit(itemId,targetId){
    if(!E.spares||!E.spares.capabilities.update){toast('مجوز ویرایش اتصال قطعه یدکی را ندارید.',1);return;}
    const part=(E.spares.parts||[]).find(item=>String(item.itemId)===String(itemId)&&(!targetId||String(item.targetId||'')===String(targetId)));
    if(!part){spareSay({message:'SPARE_LINK_NOT_FOUND'});return;}
    spareFormModal('edit',part);
  }
  async function spareItemSearch(){
    const query=String(document.getElementById('spareItemQuery')?.value||'').trim();
    if(E.sparesSearching)return;
    E.sparesSearching=true;
    try{
      const result=await R().inventoryItems(query);
      E.sparesItemResults=Array.isArray(result.data)?result.data:[];
      const select=document.getElementById('spareItemSelect');
      if(select)select.innerHTML=spareItemOptions();
    }catch(error){spareSay(error);}finally{E.sparesSearching=false;}
  }
  function spareFormError(code){
    const node=document.getElementById('spareFormError');
    if(node){node.hidden=false;node.textContent=SPARE_MESSAGES[code]||('ثبت انجام نشد: '+(code||'REQUEST_FAILED'));}
    else toast(SPARE_MESSAGES[code]||('ثبت انجام نشد: '+(code||'REQUEST_FAILED')),1);
  }
  async function spareSubmit(mode,itemId,editTargetId){
    const equipmentId=E.detailId;
    if(!equipmentId){spareFormError('EQUIPMENT_NOT_FOUND');return;}
    const quantityRaw=String(document.getElementById('spareQuantity')?.value??'').trim();
    const payload={
      relationType:document.getElementById('spareRelation')?.value||'key-spare',
      quantityRequired:quantityRaw===''?null:Number(quantityRaw),
      notes:String(document.getElementById('spareNotes')?.value||'').trim()||null
    };
    if(payload.quantityRequired!=null&&(!Number.isFinite(payload.quantityRequired)||payload.quantityRequired<0||payload.quantityRequired>1000000000)){spareFormError('REQUIRED_QUANTITY_INVALID');return;}
    try{
      let result;
      if(mode==='edit'){
        const part=(E.spares&&E.spares.parts||[]).find(item=>String(item.itemId)===String(itemId)&&(!editTargetId||String(item.targetId||'')===String(editTargetId)));
        if(!part){spareFormError('SPARE_LINK_NOT_FOUND');return;}
        payload.rowVersion=Number(part.rowVersion);
        payload.targetId=part.targetId||(part.target&&part.target.id)||editTargetId||undefined;
        result=await R().spareUpdate(equipmentId,itemId,payload);
      }else{
        payload.itemId=String(document.getElementById('spareItemSelect')?.value||'');
        if(!payload.itemId){spareFormError('INVENTORY_ITEM_REQUIRED');return;}
        const targetSelect=document.getElementById('spareTarget');
        if(targetSelect&&targetSelect.value)payload.targetId=targetSelect.value;
        result=await R().spareLink(equipmentId,payload);
      }
      if(!result||result.committed!==true)throw Object.assign(new Error('NOT_COMMITTED'),{payload:{error:'NOT_COMMITTED'}});
      closeModal();
      toast(mode==='edit'?'تغییرات اتصال قطعه یدکی پس از commit در PostgreSQL ثبت شد.':'قطعه یدکی پس از پاسخ 201 و commit در PostgreSQL به پرونده متصل شد.');
      await loadSpares(equipmentId);
    }catch(error){
      const code=(error&&error.payload&&error.payload.error)||(error&&error.message)||'REQUEST_FAILED';
      spareFormError(code);
    }
  }
  async function spareArchive(itemId,targetId){
    if(!E.spares||!E.spares.capabilities.archive){toast('مجوز بایگانی اتصال قطعه یدکی را ندارید.',1);return;}
    const part=(E.spares.parts||[]).find(item=>String(item.itemId)===String(itemId)&&(!targetId||String(item.targetId||'')===String(targetId)));
    if(!part){spareSay({message:'SPARE_LINK_NOT_FOUND'});return;}
    if(part.archived){toast(SPARE_MESSAGES.SPARE_LINK_ALREADY_ARCHIVED,1);return;}
    const entered=window.prompt('دلیل بایگانی الزامی است:');
    if(entered===null)return;
    const reason=String(entered).trim();
    if(!reason){toast(SPARE_MESSAGES.ARCHIVE_REASON_REQUIRED,1);return;}
    if(!window.confirm(`آیا اتصال «${part.name||part.code||'این قطعه'}» را بایگانی نرم می‌کنید؟ قلم انبار و سوابق آن حذف نمی‌شوند.`))return;
    try{
      const result=await R().spareArchive(E.detailId,itemId,reason,Number(part.rowVersion),part.targetId||(part.target&&part.target.id)||targetId||undefined);
      if(!result||result.archived!==true||result.historyPreserved!==true)throw Object.assign(new Error('NOT_COMMITTED'),{payload:{error:'NOT_COMMITTED'}});
      toast('اتصال با دلیل بایگانی شد؛ قلم انبار، موجودی و Audit حفظ شدند.');
      await loadSpares(E.detailId);
    }catch(error){spareSay(error);}
  }
  async function spareRestore(itemId,targetId){
    if(!E.spares||!E.spares.capabilities.archive){toast('مجوز بازیابی اتصال قطعه یدکی را ندارید.',1);return;}
    const part=(E.spares.parts||[]).find(item=>String(item.itemId)===String(itemId)&&(!targetId||String(item.targetId||'')===String(targetId)));
    if(!part){spareSay({message:'SPARE_LINK_NOT_FOUND'});return;}
    if(!part.archived){toast(SPARE_MESSAGES.SPARE_LINK_NOT_ARCHIVED,1);return;}
    const entered=window.prompt('دلیل بازیابی الزامی است:');
    if(entered===null)return;
    const reason=String(entered).trim();
    if(!reason){toast(SPARE_MESSAGES.RESTORE_REASON_REQUIRED,1);return;}
    try{
      const result=await R().spareRestore(E.detailId,itemId,{reason,rowVersion:Number(part.rowVersion),targetId:part.targetId||(part.target&&part.target.id)||targetId||undefined});
      if(!result||result.committed!==true||result.restored!==true||result.historyPreserved!==true)throw Object.assign(new Error('NOT_COMMITTED'),{payload:{error:'NOT_COMMITTED'}});
      toast('اتصال قطعه یدکی با مجوز، دلیل و Audit بازیابی شد.');
      await loadSpares(E.detailId);
    }catch(error){spareSay(error);}
  }
  async function sparesArchivedToggle(){
    E.sparesArchived=!E.sparesArchived;
    await loadSpares(E.detailId);
  }

  /* ---------- Mission D4: Selene spare-link suggestions (Analyze→Suggest→Approval→Save) ---------- */
  function sparesSuggestionPanel(){
    const caps=(E.spares&&E.spares.capabilities)||{};
    if(!caps.suggest&&!caps.approveAi)return'';
    const notice=E.sparesSuggestNotice;
    const drafts=E.sparesSuggestions||[];
    const noticeHtml=notice?`<div class="eqv2-wizard-note">${escText(notice)}</div>`:'';
    const cards=drafts.map(draft=>spareSuggestionCard(draft)).join('');
    const body=drafts.length?cards:'<p class="muted">پیشنهادی ثبت نشده است؛ با «پیشنهاد سلن» تحلیل پرونده و انبار را اجرا کنید. هیچ اتصالی بدون تأیید شما ذخیره نمی‌شود.</p>';
    return`<section class="eqv2-subsection eqv2-spares-suggestions"><h3>پیشنهاد سلن برای قطعات یدکی</h3>
      <p class="muted">سلن فقط پیشنهاد می‌دهد؛ هر پیشنهاد پس از تأیید صریح شما و فقط از مسیر Domain API ثبت می‌شود. شواهد، منبع، اطمینان و مدل برای هر پیشنهاد نمایش داده می‌شود.</p>
      ${noticeHtml}${body}</section>`;
  }
  function spareSuggestionCard(draft){
    const proposed=draft.proposed||{},caps=(E.spares&&E.spares.capabilities)||{};
    const busy=E.sparesSuggestBusy===draft.id;
    const targetName=spareTargetLabel(proposed.targetId);
    const itemName=proposed.itemName||proposed.itemId||'—';
    const relation=spareRelationLabel(proposed.relationType||'key-spare');
    const evidence=Array.isArray(draft.evidence)?draft.evidence:[];
    const confidence=draft.confidence==null?'—':faText(Math.round(Number(draft.confidence)*100))+'٪';
    const provenance=draft.source&&draft.source.ref?draft.source.ref:(draft.provenance||'—');
    const statusLabel={pending:'در انتظار تأیید',incomplete:'ناقص',conflict:'دارای تعارض',executed:'اجراشده',rejected:'ردشده',expired:'منقضی'}[draft.status]||draft.status||'—';
    const canApprove=caps.approveAi&&draft.status==='pending';
    const canReject=caps.suggest&&['pending','incomplete','conflict'].includes(draft.status);
    return`<div class="eqv2-suggestion-card" data-suggestion="${escText(draft.id)}">
      <div class="eqv2-suggestion-head"><b>${escText(itemName)}</b><span class="badge ${proposed.relationType==='key-spare'?'b-red':'b-gray'}">${escText(relation)}</span><span class="badge b-gray">${escText(statusLabel)}</span></div>
      <div class="eqv2-suggestion-meta">
        <span>هدف: ${escText(targetName)}</span>
        ${proposed.quantityRequired!=null?`<span>تعداد موردنیاز: ${faText(proposed.quantityRequired)}</span>`:''}
        <span>اطمینان: ${confidence}</span>
        <span>ارائه‌دهنده: ${escText(draft.provider||'—')} / ${escText(draft.model||'—')}</span>
        <span>منبع: ${escText(provenance)}</span>
      </div>
      ${proposed.explanation?`<p class="eqv2-suggestion-explanation">${escText(proposed.explanation)}</p>`:''}
      ${evidence.length?`<ul class="eqv2-suggestion-evidence">${evidence.map(item=>`<li>${escText(typeof item==='string'?item:(item&&item.text)||JSON.stringify(item))}</li>`).join('')}</ul>`:''}
      ${Array.isArray(proposed.missingFields)&&proposed.missingFields.length?`<div class="eqv2-wizard-note">فیلدهای ناقص: ${escText(proposed.missingFields.join('، '))}</div>`:''}
      <div class="eqv2-suggestion-actions">
        ${canApprove?`<button class="btn btn-sm btn-primary" onclick="eqv2SpareApprove('${escText(draft.id)}')" ${busy?'disabled':''}>${busy?'در حال ثبت…':'تأیید و ثبت'}</button>`:''}
        ${canReject?`<button class="btn btn-sm btn-danger" onclick="eqv2SpareReject('${escText(draft.id)}')" ${busy?'disabled':''}>رد</button>`:''}
        <button class="btn btn-sm btn-ghost" onclick="eqv2SpareEditSuggestion('${escText(draft.id)}')">ویرایش و ثبت دستی</button>
      </div>
    </div>`;
  }
  async function spareSuggest(){
    if(!E.spares||!E.spares.capabilities.suggest){toast('مجوز پیشنهاد سلن را ندارید.',1);return;}
    if(E.sparesSuggesting)return;
    E.sparesSuggesting=true;E.sparesSuggestNotice=null;
    await renderCurrentDetail();
    try{
      const result=await R().sparesSuggestions(E.detailId);
      const data=result.data||{};
      E.sparesSuggestions=Array.isArray(data.suggestions)?data.suggestions:[];
      const notices=[];
      if(data.notice)notices.push(SPARE_SUGGEST_NOTICES[data.notice]||data.notice);
      if(data.insufficient)notices.push('دادهٔ کافی برای پیشنهاد قطعه یدکی در پرونده/انبار یافت نشد؛ پیشنهادی ساخته نشد.');
      if(!E.sparesSuggestions.length&&!notices.length)notices.push('سلن پیشنهاد جدیدی تولید نکرد.');
      E.sparesSuggestNotice=notices.join(' ');
      if(E.sparesSuggestions.length)E.sparesSuggestNotice=(data.provider?`ارائه‌دهنده: ${data.provider}${data.model?' / '+data.model:''}. `:'')+E.sparesSuggestNotice;
    }catch(error){
      const code=(error&&error.payload&&error.payload.error)||(error&&error.message)||'REQUEST_FAILED';
      E.sparesSuggestNotice=SPARE_SUGGEST_NOTICES[code]||('پیشنهاد سلن دریافت نشد: '+code);
    }finally{E.sparesSuggesting=false;await renderCurrentDetail();}
  }
  const SPARE_SUGGEST_NOTICES={
    AI_PROVIDER_DISABLED_BY_POLICY:'ارائه‌دهندهٔ هوش مصنوعی طبق سیاست غیرفعال است.',
    AI_PURPOSE_DENIED_BY_POLICY:'این کاربرد طبق سیاست هوش مصنوعی مجاز نیست.',
    CLOUD_CONTEXT_NOT_APPROVED:'ارسال داده به سرویس ابری بدون تأیید سیاست مجاز نیست.',
    NO_CAPABLE_PROVIDER:'ارائه‌دهندهٔ capable در دسترس نیست.',
    SELENE_DRAFTS_UNAVAILABLE:'سرویس پیش‌نویس سلن در دسترس نیست؛ migration مربوطه را اعمال کنید.',
    SERVER_REQUIRED:'اتصال به سرور برقرار نیست.'
  };
  async function spareApprove(draftId){
    if(!E.spares||!E.spares.capabilities.approveAi){toast('مجوز تأیید پیشنهاد سلن را ندارید.',1);return;}
    const draft=(E.sparesSuggestions||[]).find(item=>String(item.id)===String(draftId));
    if(!draft){toast('پیشنهاد پیدا نشد؛ فهرست را تازه‌سازی کنید.',1);return;}
    if(!window.confirm('این پیشنهاد پس از تأیید شما از مسیر Domain API ثبت می‌شود. ادامه می‌دهید؟'))return;
    E.sparesSuggestBusy=draftId;await renderCurrentDetail();
    try{
      const confirmation=await R().actionConfirm(draftId);
      const confirmationId=confirmation&&confirmation.data&&confirmation.data.id;
      if(!confirmationId)throw Object.assign(new Error('CONFIRMATION_NOT_FOUND'),{payload:{error:'CONFIRMATION_NOT_FOUND'}});
      const requestId=window.crypto&&window.crypto.randomUUID?window.crypto.randomUUID():`sp-${draftId}-${Date.now()}`;
      const result=await R().actionExecute(draftId,{confirmationId,requestId});
      if(!result||result.committed!==true)throw Object.assign(new Error('NOT_COMMITTED'),{payload:{error:'NOT_COMMITTED'}});
      toast('پیشنهاد سلن پس از تأیید شما و بررسی دوباره مجوز از مسیر Domain API ثبت شد.');
      E.sparesSuggestions=(E.sparesSuggestions||[]).filter(item=>String(item.id)!==String(draftId));
      await loadSpares(E.detailId);
    }catch(error){
      const code=(error&&error.payload&&error.payload.error)||(error&&error.message)||'REQUEST_FAILED';
      toast(SPARE_MESSAGES[code]||('تأیید پیشنهاد انجام نشد: '+code),1);
    }finally{E.sparesSuggestBusy=null;await renderCurrentDetail();}
  }
  async function spareReject(draftId){
    if(!E.spares||!E.spares.capabilities.suggest){toast('مجوز رد پیشنهاد را ندارید.',1);return;}
    const reason=window.prompt('دلیل رد پیشنهاد (اختیاری):');
    if(reason===null)return;
    E.sparesSuggestBusy=draftId;await renderCurrentDetail();
    try{
      await R().actionReject(draftId);
      E.sparesSuggestions=(E.sparesSuggestions||[]).filter(item=>String(item.id)!==String(draftId));
      toast('پیشنهاد رد شد؛ هیچ اتصالی ثبت نشد.');
    }catch(error){
      const code=(error&&error.payload&&error.payload.error)||(error&&error.message)||'REQUEST_FAILED';
      toast('رد پیشنهاد انجام نشد: '+code,1);
    }finally{E.sparesSuggestBusy=null;await renderCurrentDetail();}
  }
  function spareEditSuggestion(draftId){
    const draft=(E.sparesSuggestions||[]).find(item=>String(item.id)===String(draftId));
    if(!draft){toast('پیشنهاد پیدا نشد.',1);return;}
    const proposed=draft.proposed||{};
    E.sparesItemResults=proposed.itemId?[{id:proposed.itemId,code:proposed.itemCode||'',name:proposed.itemName||proposed.itemId,available:null,unit:''}]:[];
    spareFormModal('create',null);
    const targetSelect=document.getElementById('spareTarget');
    if(targetSelect&&proposed.targetId){targetSelect.value=proposed.targetId;spareTargetChanged();}
    const itemSelect=document.getElementById('spareItemSelect');
    if(itemSelect&&proposed.itemId)itemSelect.value=proposed.itemId;
    const relation=document.getElementById('spareRelation');
    if(relation&&proposed.relationType)relation.value=proposed.relationType;
    const quantity=document.getElementById('spareQuantity');
    if(quantity&&proposed.quantityRequired!=null)quantity.value=proposed.quantityRequired;
    const notes=document.getElementById('spareNotes');
    if(notes&&proposed.explanation)notes.value=proposed.explanation;
  }

  /* ---------- Mission D4 / Phase 11: QR + printable identity card (never a tab) ---------- */
  const IDENTITY_MESSAGES={
    QR_ENCODER_UNAVAILABLE:'موتور ساخت QR بارگذاری نشده است؛ صفحه را تازه‌سازی کنید. کد جعلی نمایش داده نمی‌شود.',
    QR_BASE_UNAVAILABLE:'آدرس مطلق سامانه برای ساخت QR در دسترس نیست؛ از نشانی رسمی سامانه وارد شوید.',
    QR_PAYLOAD_REQUIRED:'پیوند پرونده تجهیز ساخته نشد.',
    EQUIPMENT_KEY_REQUIRED:'کد یا شناسه تجهیز برای ساخت QR موجود نیست.',
    EQUIPMENT_DATA_REQUIRED:'دادهٔ واقعی تجهیز برای چاپ شناسنامه دریافت نشد.',
    IDENTITY_MODULE_UNAVAILABLE:'ماژول شناسنامه چاپی بارگذاری نشده است؛ صفحه را تازه‌سازی کنید.',
    POPUP_BLOCKED:'پنجره چاپ باز نشد؛ اجازه بازشدن پنجره (Pop-up) را برای این سایت فعال کنید.',
    SERVER_REQUIRED:'اتصال به سرور برقرار نیست؛ شناسنامه فقط از دادهٔ واقعی سرور چاپ می‌شود.'
  };
  const identitySay=error=>{const code=error&&(error.payload&&error.payload.error||error.code||error.message);if(typeof console!=='undefined')console.warn('Equipment identity action failed',code||'request_failed');toast(IDENTITY_MESSAGES[code]||('عملیات شناسنامه/QR انجام نشد: '+(code||'REQUEST_FAILED')),1);};
  function identityBase(){
    if(window.BFGRuntime&&typeof window.BFGRuntime.sameOriginBase==='function'){
      const base=window.BFGRuntime.sameOriginBase();
      if(base)return String(base).replace(/\/+$/,'');
    }
    try{if(location&&/^https?:$/.test(location.protocol)&&location.origin)return location.origin;}catch(_){}
    return '';
  }
  function identityFor(asset){
    const identity=window.BFGEquipmentIdentity;
    if(!identity)throw Object.assign(new Error('IDENTITY_MODULE_UNAVAILABLE'),{code:'IDENTITY_MODULE_UNAVAILABLE'});
    const base=identityBase();
    if(!base)throw Object.assign(new Error('QR_BASE_UNAVAILABLE'),{code:'QR_BASE_UNAVAILABLE'});
    const link=identity.dossierLink(base,asset.code||asset.id);
    const qr=identity.qrSvg(link,240);
    return{identity,link,qr};
  }
  function identityOperationalLabel(asset){
    const value=asset.operational_status;
    if(!value)return null;
    const found=OPERATIONAL_OPTIONS.find(item=>item.value===value);
    return found?found.label:value;
  }
  function openPrintWindow(html){
    const win=window.open('','_blank');
    if(!win||!win.document){identitySay({code:'POPUP_BLOCKED'});return false;}
    win.document.open();win.document.write(html);win.document.close();
    try{win.focus();win.print();}catch(_){}
    return true;
  }
  async function qrModal(id){
    try{
      const {data:a}=await R().get(id||E.detailKey);
      const {link,qr}=identityFor(a);
      modal(mhead('QR تجهیز — '+escText(a.name||a.code||''))+`<div class="m-body eqv2-qr-body">
        <div class="eqv2-qr-frame">${qr}</div>
        <div class="eqv2-qr-meta"><b class="eqv2-code">${escText(a.code||'—')}</b><div>${escText(a.name||'')}</div>
          <div class="eqv2-qr-link" dir="ltr">${escText(link)}</div>
          <p class="muted">با اسکن این کد توسط دوربین موبایل، پس از ورود کاربر، پرونده دیجیتال همین تجهیز باز می‌شود.</p></div>
        <div class="m-foot"><button class="btn btn-primary" onclick="eqv2PrintQrLabels('${escText(a.id)}')">🖨 چاپ برچسب QR</button>
          <button class="btn btn-ghost" onclick="eqv2OpenPassport('${escText(a.code||a.id)}')">📄 شناسنامه مستقل</button>
          <button class="btn btn-ghost" onclick="eqv2PrintIdentity('${escText(a.id)}')">🖨 چاپ شناسنامه</button>
          <button class="btn btn-ghost" onclick="closeModal()">بستن</button></div>
      </div>`,true);
    }catch(error){identitySay(error);}
  }
  async function printIdentity(id){
    try{
      const {data:a}=await R().get(id||E.detailKey);
      const {identity,link,qr}=identityFor(a);
      let sparesModel={state:'unavailable',rows:[]};
      if(typeof R().spares==='function'){
        try{
          const result=await R().spares(a.id);
          const parts=((result.data&&result.data.parts)||[]).filter(part=>!part.archived);
          sparesModel={state:parts.length?'ok':'empty',rows:parts};
        }catch(_){sparesModel={state:'unavailable',rows:[]};}
      }
      const html=identity.identityCardHtml({
        asset:a,
        labels:{status:statusInfo(a)[0],operationalStatus:identityOperationalLabel(a),
          installDate:(a.install_date||a.install)?formatDate(a.install_date||a.install):null},
        spares:sparesModel,link,qr,
        printedBy:typeof ME!=='undefined'&&ME?(ME.name||ME.username||null):null,
        printedAt:typeof jDateTime==='function'?jDateTime():null,
        logo:typeof LOGO!=='undefined'?LOGO:null
      });
      openPrintWindow(html);
    }catch(error){identitySay(error);}
  }
  async function printQrLabels(id){
    try{
      const {data:a}=await R().get(id||E.detailKey);
      const {identity,link}=identityFor(a);
      const labelQr=identity.qrSvg(link,120);
      const html=identity.labelsSheetHtml({asset:a,link,qr:labelQr,logo:typeof LOGO!=='undefined'?LOGO:null},3);
      openPrintWindow(html);
    }catch(error){identitySay(error);}
  }

  // Builds the same real-data passport model used by single printing; shared by the in-app
  // passport route and the batch printer so every surface shows identical PostgreSQL facts.
  async function passportModelFor(a){
    const {identity,link,qr}=identityFor(a);
    let sparesModel={state:'unavailable',rows:[]};
    if(typeof R().spares==='function'){
      try{
        const result=await R().spares(a.id);
        const parts=((result.data&&result.data.parts)||[]).filter(part=>!part.archived);
        sparesModel={state:parts.length?'ok':'empty',rows:parts};
      }catch(_){sparesModel={state:'unavailable',rows:[]};}
    }
    return{identity,link,qr,model:{
      asset:a,
      labels:{status:statusInfo(a)[0],operationalStatus:identityOperationalLabel(a),
        installDate:(a.install_date||a.install)?formatDate(a.install_date||a.install):null},
      spares:sparesModel,link,qr,
      printedBy:typeof ME!=='undefined'&&ME?(ME.name||ME.username||null):null,
      printedAt:typeof jDateTime==='function'?jDateTime():null,
      logo:typeof LOGO!=='undefined'?LOGO:null
    }};
  }

  // Independent printable passport route. It renders inside the signed-in app shell and pulls
  // every value through the authenticated Equipment APIs — a scanned link shows nothing before
  // sign-in and never bypasses permission/scope.
  async function openPassport(key,{push=true,fromRoute=false}={}){
    if(!equipmentModuleAllowed())return;
    const content=document.getElementById('content');
    if(content)content.innerHTML='<div class="eqv2-loading">در حال دریافت شناسنامه تجهیز…</div>';
    E.passportLoading=true;E.passportError=null;
    try{
      const {data:a}=await R().get(key);
      const {identity,model}=await passportModelFor(a);
      E.passport={key:a.code||a.id,id:a.id};
      const target='/equipment/'+encodeURIComponent(a.code||a.id)+'/passport';
      if(push&&location.pathname!==target)history.pushState({equipmentPassport:true,key:a.code||a.id},'',target);
      else if(fromRoute&&location.pathname!==target)history.replaceState({equipmentPassport:true,key:a.code||a.id},'',target);
      if(content)content.innerHTML=`<div class="eqv2-passport">
        <div class="eqv2-passport-toolbar noprint">
          <button class="btn btn-ghost" onclick="eqv2OpenDetail('${escText(a.code||a.id)}')">بازگشت به پرونده</button>
          <button class="btn btn-primary" onclick="eqv2PrintIdentity('${escText(a.id)}')">🖨 چاپ شناسنامه A4</button>
        </div>
        <div class="eqv2-passport-sheet">${identity.identitySheetHtml(model)}</div>
      </div>`;
      window.scrollTo(0,0);
    }catch(error){
      E.passportError=(error&&error.payload&&error.payload.error)||(error&&error.message)||'PASSPORT_FAILED';
      if(content)content.innerHTML=`<div class="eqv2-empty"><div><i>⚠️</i><b>شناسنامه تجهیز دریافت نشد</b><div>${escText(E.passportError)}</div><button class="btn btn-ghost" onclick="eqv2BackToEquipment()">بازگشت</button></div></div>`;
    }finally{E.passportLoading=false;}
  }

  // Group A4 printing: fetch each selected passport sequentially through the same authenticated
  // API, then print one real sheet per page. Failures are reported honestly, never invented.
  async function printBatchIdentity(ids){
    const list=Array.isArray(ids)?ids.filter(Boolean):[];
    if(!list.length){toast('تجهیزی برای چاپ گروهی انتخاب نشده است.',1);return;}
    if(list.length>50){toast('حداکثر ۵۰ شناسنامه در هر چاپ گروهی مجاز است.',1);return;}
    if(E.batchPrintBusy)return;
    E.batchPrintBusy=true;
    toast(`در حال دریافت ${faText(list.length)} شناسنامه از سرور…`);
    const models=[],failures=[];
    try{
      const identity=window.BFGEquipmentIdentity;
      if(!identity)throw Object.assign(new Error('IDENTITY_MODULE_UNAVAILABLE'),{code:'IDENTITY_MODULE_UNAVAILABLE'});
      for(const id of list){
        try{
          const {data:a}=await R().get(id);
          const {model}=await passportModelFor(a);
          models.push(model);
        }catch(error){
          const code=(error&&error.payload&&error.payload.error)||(error&&error.message)||'REQUEST_FAILED';
          failures.push(`${id}: ${code}`);
        }
      }
      if(!models.length){toast('هیچ شناسنامه‌ای دریافت نشد؛ چاپ انجام نشد.',1);return;}
      const html=identity.identityBatchHtml(models,failures);
      openPrintWindow(html);
      if(failures.length)toast(`${faText(failures.length)} شناسنامه دریافت نشد و در صفحهٔ پایانی گزارش شد.`,1);
    }catch(error){identitySay(error);}finally{E.batchPrintBusy=false;}
  }
  function batchPrintModal(){
    const rows=E.rows||[];
    if(!rows.length){toast('فهرست تجهیزات خالی است؛ ابتدا تجهیزات را بارگذاری کنید.',1);return;}
    const options=rows.map(a=>`<label class="eqv2-col-opt"><input type="checkbox" value="${escText(a.id)}"> <span class="eqv2-code">${escText(a.code||'—')}</span> — ${escText(a.name||'بدون نام')}</label>`).join('');
    modal(mhead('چاپ گروهی شناسنامه A4')+`<div class="m-body">
      <div class="eqv2-wizard-note">حداکثر ۵۰ شناسنامه در هر چاپ گروهی. هر شناسنامه فقط از دادهٔ واقعی PostgreSQL و پس از دریافت موفق چاپ می‌شود؛ موارد ناموفق به‌صورت صادقانه گزارش می‌شوند.</div>
      <div class="eqv2-check-cols eqv2-batch-list">${options}</div>
      <div class="m-foot"><button class="btn btn-primary" onclick="eqv2BatchPrintRun()">🖨 چاپ انتخاب‌شده‌ها</button><button class="btn btn-ghost" onclick="closeModal()">انصراف</button></div>
    </div>`,true);
  }
  function batchPrintRun(){
    const ids=[...document.querySelectorAll('.eqv2-batch-list input:checked')].map(node=>node.value);
    if(!ids.length){toast('حداقل یک تجهیز را انتخاب کنید.',1);return;}
    closeModal();
    printBatchIdentity(ids);
  }

  function routeKey(){const match=location.pathname.match(/^\/equipment\/([^/]+)\/?$/);return match?decodeURIComponent(match[1]):null;}
  function passportRouteKey(){const match=location.pathname.match(/^\/equipment\/([^/]+)\/passport\/?$/);return match?decodeURIComponent(match[1]):null;}
  async function openDetail(idOrCode,{push=true,fromRoute=false}={}){
    if(!equipmentModuleAllowed())return;
    if(E.routeBusy)return;E.routeBusy=true;
    try{
      if(!E.detail)captureExplorerState();
      E.detail=true;E.tab='technical';
      const content=document.getElementById('content');if(content)content.innerHTML='<div class="eqv2-loading">در حال بازکردن پرونده تجهیز…</div>';
      const {data:a}=await R().get(idOrCode);E.selected=a.id;
      // detailKey stays the routing/URL key (code when present); detailId is always the real
      // PostgreSQL assets.id that every structure call must use.
      E.detailId=a.id;E.detailKey=a.code||a.id;saveState();
      const target='/equipment/'+encodeURIComponent(E.detailKey);
      if(push&&location.pathname!==target)history.pushState({equipment:true,key:E.detailKey},'',target);
      else if(fromRoute&&location.pathname!==target)history.replaceState({equipment:true,key:E.detailKey},'',target);
      if(content)content.innerHTML=detailPage(a);window.scrollTo(0,0);
    }catch(error){E.detail=false;showError(error);}finally{E.routeBusy=false;}
  }
  function openIntake(equipmentId=E.selected||null){
    if(!equipmentModuleAllowed())return;
    const main=document.querySelector('.eqv2-main')||document.getElementById('content');if(!main)return;
    E.intakeReturn={detail:E.detail,detailKey:E.detailKey,tab:E.tab||'technical'};
    main.innerHTML='<div id="seleneMount" class="selene-mount"></div>';
    if(window.BFGSelene)window.BFGSelene.mount(document.getElementById('seleneMount'),{equipmentId:equipmentId||null});
  }
  async function renderCurrentDetail(){
    if(!E.detailKey)return;
    const {data:a}=await R().get(E.detailKey),body=document.getElementById('eqv2DetailBody');
    if(a&&a.id&&E.detailId!==a.id)E.detailId=a.id;
    if(body)body.innerHTML=detailBody(a);
    const header=document.querySelector('.eqv2-detail-header');if(header)header.outerHTML=detailHeader(a);
    document.querySelectorAll('.eqv2-detail-tabs button').forEach((button,index)=>{
      const on=DETAIL_TABS[index]?.[0]===E.tab;button.classList.toggle('on',on);button.setAttribute('aria-selected',String(on));
    });
  }
  async function backToEquipment({historyMode='push'}={}){
    E.detail=false;E.detailKey=null;E.detailId=null;E.view='list';if(historyMode==='push')history.pushState({equipmentExplorer:true},'','/');
    const content=document.getElementById('content');if(!content)return;content.innerHTML=shell();await initExplorer(true);restoreExplorerScroll();
  }
  async function restoreRoute(){
    if(!equipmentModuleAllowed())return false;
    const signedIn=typeof ME!=='undefined'&&ME;
    if(!signedIn)return false;
    const passportKey=passportRouteKey();
    const key=passportKey||routeKey();
    if(!key)return false;
    if(typeof CUR!=='undefined')CUR='equipment';
    if(typeof buildMenu==='function')buildMenu();
    document.getElementById('sidebar')?.classList.remove('open');
    if(passportKey)await openPassport(passportKey,{push:false,fromRoute:true});
    else await openDetail(key,{push:false,fromRoute:true});
    return true;
  }

  function filter(key,value){E[key]=value;if(key==='factoryId')E.categoryId='';E.page=1;saveState();const toolbarNode=document.querySelector('.eqv2-toolbar');if(toolbarNode)toolbarNode.outerHTML=toolbar();load().then(restoreExplorerScroll).catch(showError);}
  function view(){captureExplorerState();E.view='list';E.page=1;saveState();document.getElementById('content').innerHTML=shell();initExplorer(true);}
  function pageTo(value){E.page=Math.max(1,value);saveState();load().then(restoreExplorerScroll).catch(showError);}
  function search(value){clearTimeout(search.timer);E.q=value;E.page=1;saveState();search.timer=setTimeout(()=>load().then(restoreExplorerScroll).catch(showError),250);}
  function sortBy(key){const mapped=sortKey(key);E.direction=E.sort===mapped&&E.direction==='asc'?'desc':'asc';E.sort=mapped;saveState();load().catch(showError);}
  function closeSummary(){E.selected=null;saveState();const panel=document.getElementById('eqv2Summary');if(panel)panel.innerHTML=empty('تجهیزی انتخاب نشده است.');}

  const WIZARD_STEPS=[
    {id:'initialDetails',title:'مشخصات اولیه'},
    {id:'structure',title:'ساختار داخلی'},
    {id:'maintenance',title:'برنامه نگهداری'}
  ];
  const NODE_OPTIONS=[
    {value:'equipment',label:'تجهیز'}, {value:'sub-equipment',label:'زیرتجهیز'},
    {value:'subsystem',label:'زیرسیستم'}, {value:'main-component',label:'جزء اصلی'},
    {value:'sub-component',label:'جزء فرعی'}
  ];
  const OPERATIONAL_OPTIONS=[
    {value:'in_service',label:'در سرویس'}, {value:'standby',label:'آماده‌به‌کار'},
    {value:'out_of_service',label:'خارج از سرویس'}, {value:'reserved',label:'رزرو'},
    {value:'decommissioned',label:'از رده خارج'}
  ];
  const pad=value=>String(value).padStart(2,'0');
  function dateAnswer(value){
    const engine=window.BFGStepWizard;if(!value||!engine)return{date:''};
    const text=String(value).trim();
    const isoDate=text.match(/^(\d{4}-\d{2}-\d{2})/);
    if(isoDate)return engine.isoToJalaliInput(isoDate[1]);
    if(engine.parseJalaliDate(text))return{date:engine.toPersianDigits(text.replace(/-/g,'/'))};
    return{date:''};
  }
  function dateToIso(value){
    const engine=window.BFGStepWizard,parts=engine&&value&&engine.parseJalaliDate(value.date||'');
    if(!parts)return null;
    return`${parts.year}-${pad(parts.month)}-${pad(parts.day)}`;
  }
  function arrayText(value){return Array.isArray(value)?value.join('، '):String(value||'');}
  function splitParts(value){return String(value||'').split(/[،,\n]/).map(item=>item.trim()).filter(Boolean).slice(0,40);}
  function asNum(value){return value===''||value==null?null:Number(value);}
  function canonicalFromAsset(asset){
    const ext=asset.ext||{},factoryFromPath=(asset.path||[]).find(item=>(item.nodeKind||item.node_kind)==='factory');
    return{
      name:asset.name||'',code:asset.code||'',nodeKind:ext.nodeKind||asset.node_kind||'equipment',
      activityType:asset.activity_type||asset.activityType||'',maker:asset.maker||'',
      manufacturerCountry:asset.manufacturer_country||asset.manufacturerCountry||'',model:asset.model||'',
      serial:asset.serial||'',year:asset.year||'',installDate:asset.install_date||asset.installDate||null,
      power:asset.power||'',hours:asset.hours==null?'':String(asset.hours),cls:asset.cls||'',status:asset.status||'',
      operationalStatus:asset.operational_status||asset.operationalStatus||'',crit:asset.crit||'',
      capacity:ext.capacity||asset.capacity||'',locationDescription:ext.locationDescription||'',
      functionDescription:ext.description||'',technicalSpecification:ext.technicalSpecification||'',
      panelCode:ext.panelCode||'',refrigerant:ext.refrigerant||'',
      dailyOperatingHours:ext.dailyOperatingHours==null?'':String(ext.dailyOperatingHours),
      criticalityScore:ext.criticalityScore==null?'':String(ext.criticalityScore),keyParts:arrayText(ext.keyParts),
      generalNotes:asset.general_notes||asset.generalNotes||'',responsibleUserId:asset.responsible_user_id||asset.responsibleUserId||'',
      factoryId:asset.factory_id||asset.factoryId||factoryFromPath?.id||'',
      categoryId:asset.category_id||asset.categoryId||'',locationId:asset.parent||asset.parentId||''
    };
  }
  function answersFromAsset(asset,record){
    const answers=canonicalFromAsset(asset||{});
    answers.installDate=dateAnswer(answers.installDate||asset?.install||'');
    if(record){
      const suggested={
        name:record.name,code:record.code,nodeKind:record.nodeKind,activityType:record.activityType,
        maker:record.maker,manufacturerCountry:record.manufacturerCountry,model:record.model,serial:record.serial,
        year:record.year,power:record.power,cls:record.cls,status:record.status,
        operationalStatus:record.operationalStatus,crit:record.crit,capacity:record.capacity,
        locationDescription:record.location,functionDescription:record.notes,
        technicalSpecification:record.technicalSpecification,panelCode:record.panelCode,refrigerant:record.refrigerant,
        dailyOperatingHours:record.dailyOperatingHours,criticalityScore:record.criticalityScore,
        keyParts:record.keyParts==null?undefined:arrayText(record.keyParts),hours:record.hours,
        generalNotes:record.generalNotes
      };
      for(const [key,value] of Object.entries(suggested))if(value!=null&&value!=='')answers[key]=value;
      const rawDate=record.installDate||record.install;
      if(rawDate){const converted=dateAnswer(rawDate);if(converted.date)answers.installDate=converted;else answers.__rawInstallDate=String(rawDate);}
    }
    if(!answers.nodeKind)answers.nodeKind='equipment';
    if(!asset&&answers.factoryId==null)answers.factoryId='';
    if(!asset&&answers.categoryId==null)answers.categoryId='';
    if(!asset&&answers.locationId==null)answers.locationId='';
    return answers;
  }
  function payloadFromAnswers(answers,isNew){
    const payload={
      nodeKind:String(answers.nodeKind||'equipment'),name:String(answers.name||'').trim(),code:String(answers.code||'').trim(),
      activityType:answers.activityType||null,maker:answers.maker||null,manufacturerCountry:answers.manufacturerCountry||null,
      model:answers.model||null,serial:answers.serial||null,year:answers.year||null,
      installDate:dateToIso(answers.installDate),power:answers.power||null,hours:asNum(answers.hours),
      cls:answers.cls||null,status:answers.status||null,operationalStatus:answers.operationalStatus||null,
      crit:answers.crit||null,capacity:answers.capacity||null,locationDescription:answers.locationDescription||null,
      functionDescription:answers.functionDescription||null,technicalSpecification:answers.technicalSpecification||null,
      panelCode:answers.panelCode||null,refrigerant:answers.refrigerant||null,
      dailyOperatingHours:asNum(answers.dailyOperatingHours),criticalityScore:asNum(answers.criticalityScore),
      keyParts:splitParts(answers.keyParts),generalNotes:answers.generalNotes||null,
      responsibleUserId:answers.responsibleUserId||null,
      factoryId:answers.factoryId||null,categoryId:answers.categoryId||null,
      locationId:answers.locationId||answers.factoryId||null
    };
    if(isNew)payload.recordStatus='complete';
    return payload;
  }
  function baselineField(asset,key){
    const ext=asset.ext||{};
    const map={
      activityType:asset.activity_type,manufacturerCountry:asset.manufacturer_country,installDate:asset.install_date,
      operationalStatus:asset.operational_status,generalNotes:asset.general_notes,responsibleUserId:asset.responsible_user_id,
      capacity:ext.capacity,locationDescription:ext.locationDescription,functionDescription:ext.description,
      technicalSpecification:ext.technicalSpecification,panelCode:ext.panelCode,refrigerant:ext.refrigerant,
      dailyOperatingHours:ext.dailyOperatingHours,criticalityScore:ext.criticalityScore,keyParts:ext.keyParts,
      factoryId:asset.factory_id,categoryId:asset.category_id,locationId:asset.parent||asset.factory_id
    };
    return map[key]!==undefined?map[key]:asset[key];
  }
  function sameValue(a,b){
    if(Array.isArray(a)||Array.isArray(b))return JSON.stringify(a||[])===JSON.stringify(b||[]);
    if(a==null||a==='')return b==null||b==='';if(b==null||b==='')return a==null||a==='';
    if(typeof a==='number'||typeof b==='number')return Number(a)===Number(b);
    return String(a)===String(b);
  }
  function changedPayload(payload,asset){
    const changed={};
    for(const [key,value] of Object.entries(payload)){
      if(key==='nodeKind')continue;
      if(key==='recordStatus'){
        const current=asset.record_status||asset.recordStatus||'complete';
        if(value==='complete'&&current!=='complete')changed.recordStatus='complete';
        continue;
      }
      if(value==null||value==='')continue;
      if(!sameValue(value,baselineField(asset,key)))changed[key]=value;
    }
    return changed;
  }
  function conflictKeys(answers,current){
    if(!current)return[];
    const proposed=payloadFromAnswers(answers,false),keys=['name','code','maker','model','serial','year','installDate','power','cls','status','crit','locationDescription','functionDescription','technicalSpecification','capacity','panelCode','refrigerant','activityType','manufacturerCountry','operationalStatus','responsibleUserId','generalNotes'];
    return keys.filter(key=>proposed[key]!=null&&proposed[key]!==''&&current[key]!=null&&current[key]!==''&&!sameValue(proposed[key],current[key]));
  }
  function conflictPanel(ctx){
    if(!ctx.selene||!ctx.actionCurrent)return'';
    const fields=conflictKeys(ctx.answers,ctx.actionCurrent);
    if(!fields.length)return'<div class="eqv2-wizard-note">تعارضی با مقدار ثبت‌شده دیده نمی‌شود؛ داده‌های پیشنهادی همچنان نیازمند بازبینی شما هستند.</div>';
    return`<section class="eqv2-conflict-panel"><b>تعارض با رکورد فعلی — تأیید صریح لازم است</b>${fields.map(key=>{
      const label=({name:'نام تجهیز',code:'کد تجهیز',maker:'سازنده',model:'مدل',serial:'سریال',year:'سال ساخت',installDate:'تاریخ نصب',power:'توان',cls:'کلاس',status:'وضعیت فنی',crit:'بحرانیت',locationDescription:'محل توصیفی',functionDescription:'شرح عملکرد',technicalSpecification:'مشخصات فنی',capacity:'ظرفیت',panelCode:'تابلو برق',refrigerant:'نوع مبرد',activityType:'نوع فعالیت',manufacturerCountry:'کشور سازنده',operationalStatus:'وضعیت بهره‌برداری',responsibleUserId:'مسئول تجهیز',generalNotes:'ملاحظات عمومی'})[key]||key;
      const accepted=!!ctx.answers[`acceptConflict:${key}`];
      return`<label class="eqv2-conflict-row"><span><b>${label}</b><small>ثبت‌شده: ${escText(ctx.actionCurrent[key])} · پیشنهادی: ${escText(ctx.answers[key])}</small></span><input type="checkbox" data-sw-field="acceptConflict:${key}" ${accepted?'checked':''}><em>جایگزینی را تأیید می‌کنم</em></label>`;
    }).join('')}</section>`;
  }
  function wizardSteps(ctx){
    const selectedParent=ctx.asset&&ctx.asset.parent?ctx.asset.parent:'';
    const locations=[...(E.options.locations||[])];
    if(selectedParent&&!locations.some(item=>String(item.id)===String(selectedParent)))locations.push({id:selectedParent,name:ctx.asset.parent_name||ctx.asset.location_name||'محل فعلی',factory_id:ctx.asset.factory_id||null,node_kind:'current'});
    const statusOptions=Object.entries(typeof AS_ST==='undefined'?{}:AS_ST).map(([value,row])=>({value,label:row[0]}));
    if(ctx.asset?.status&&!statusOptions.some(item=>item.value===ctx.asset.status))statusOptions.push({value:ctx.asset.status,label:ctx.asset.status});
    const steps=[
      {id:'initialDetails',kind:'group',title:'مشخصات اولیه',description:'نام و کد الزامی است. سایر مشخصات فقط با داده واقعی تکمیل می‌شوند.',fields:[
        {id:'code',kind:'text',label:'کد تجهیز',required:true,maxLength:120},
        {id:'name',kind:'text',label:'نام تجهیز',required:true,maxLength:240},
        {id:'nodeKind',kind:'select',label:'نوع رکورد',required:true,options:()=>NODE_OPTIONS,help:'نوع تجهیز یا جزء ساختاری را با توجه به رکورد واقعی انتخاب کنید.'},
        {id:'activityType',kind:'text',label:'نوع فعالیت',maxLength:180},
        {id:'maker',kind:'text',label:'سازنده',maxLength:180},
        {id:'manufacturerCountry',kind:'text',label:'کشور سازنده',maxLength:120},
        {id:'model',kind:'text',label:'مدل',maxLength:180},
        {id:'serial',kind:'text',label:'شماره سریال',maxLength:180},
        {id:'year',kind:'text',label:'سال ساخت',maxLength:16},
        {id:'installDate',kind:'jalali-date',label:'تاریخ نصب شمسی',help:'در Backend به تاریخ میلادی/DATE تبدیل می‌شود.'},
        {id:'power',kind:'text',label:'توان',maxLength:120},
        {id:'capacity',kind:'text',label:'ظرفیت'},
        {id:'status',kind:'select',label:'وضعیت فنی',options:()=>statusOptions},
        {id:'operationalStatus',kind:'select',label:'وضعیت بهره‌برداری',options:()=>OPERATIONAL_OPTIONS},
        {id:'crit',kind:'select',label:'بحرانیت',options:[{value:'A',label:'A'},{value:'B',label:'B'},{value:'C',label:'C'}]},
        {id:'hours',kind:'number',label:'کارکرد تجمعی',min:0,step:0.1},
        {id:'responsibleUserId',kind:'select',label:'مسئول تجهیز',options:()=>[
          ...(E.options.responsibleUsers||[]).map(user=>({value:user.id,label:`${user.name}${user.role?' — '+user.role:''}`}))
        ]},
        {id:'locationDescription',kind:'text',label:'محل توصیفی',maxLength:1000},
        {id:'functionDescription',kind:'textarea',label:'شرح عملکرد',rows:3,maxLength:1000},
        {id:'technicalSpecification',kind:'textarea',label:'مشخصات فنی',rows:4,maxLength:1000},
        {id:'generalNotes',kind:'textarea',label:'ملاحظات عمومی',rows:3,maxLength:4000},
        {id:'panelCode',kind:'text',label:'کد تابلو برق',maxLength:1000},
        {id:'refrigerant',kind:'text',label:'نوع مبرد',maxLength:1000},
        {id:'dailyOperatingHours',kind:'number',label:'ساعت کارکرد روزانه',min:0,max:24,step:0.1},
        {id:'criticalityScore',kind:'number',label:'امتیاز بحرانی ثبت‌شده',min:0,max:100,step:1},
        {id:'keyParts',kind:'textarea',label:'قطعات کلیدی (متن پرونده، نه قلم انبار)',rows:2,maxLength:1000}
      ],afterRender:wizardContext=>`${ctx.selene?`<div class="eqv2-wizard-evidence"><b>پیشنهاد سلن</b><span>منبع: ${escText(ctx.sourceLabel||'ورودی سلن')} · وضعیت اطمینان: ${ctx.confidence==null?'ثبت نشده':faText(Math.round(ctx.confidence*100))+'٪'}</span><small>هیچ پیشنهادی تا تأیید نهایی شما در تجهیز اعمال نمی‌شود.</small></div>${ctx.rawInstall?`<div class="eqv2-wizard-note">تاریخ استخراج‌شده «${escText(ctx.rawInstall)}» به تاریخ شمسی معتبر تبدیل نشد؛ مقدار در پایگاه تغییر نمی‌کند مگر آن را اصلاح کنید.</div>`:''}${conflictPanel({...ctx,answers:wizardContext.answers})}`:''}`},
      {id:'structure',kind:'group',title:'موقعیت و دسته‌بندی',description:'مسیر و محل فیزیکی تجهیز را انتخاب کنید. اجزای داخلی فقط از تب ساختار و فرم‌های مستقل همان نوع ثبت می‌شوند.',renderOnChange:true,fields:[
        {id:'factoryId',kind:'select',label:'کارخانه',options:()=>[
          ...(E.options.factories||[]).map(factory=>({value:factory.id,label:`${factory.code?factory.code+' — ':''}${factory.name}`}))
        ],renderOnChange:true,onChange:({answers,value,previous})=>{
          if(previous!==value){
            const category=E.options.categories.find(item=>String(item.id)===String(answers.categoryId));
            if(category&&value&&String(category.factory_id)!==String(value))answers.categoryId='';
            const location=locations.find(item=>String(item.id)===String(answers.locationId));
            if(location&&value&&location.factory_id&&String(location.factory_id)!==String(value))answers.locationId='';
          }
        }},
        {id:'categoryId',kind:'select',label:'دسته تجهیز',options:answers=>(E.options.categories||[]).filter(item=>!answers.factoryId||String(item.factory_id)===String(answers.factoryId)).map(item=>({value:item.id,label:`${item.code?item.code+' — ':''}${item.name}`}))},
        {id:'locationId',kind:'select',label:'محل / گره والد موجود',options:answers=>locations.filter(item=>!answers.factoryId||!item.factory_id||String(item.factory_id)===String(answers.factoryId)).map(item=>({value:item.id,label:`${item.code?item.code+' — ':''}${item.name}`}))}
      ],afterRender:()=>`<div class="eqv2-wizard-note">این مرحله فقط جایگاه فیزیکی و دسته تجهیز را تعیین می‌کند. افزودن زیرسیستم، قطعه اصلی و زیرقطعه در تب ساختار و با فرم مستقل انجام می‌شود.</div>`},
      {id:'maintenance',kind:'custom',title:'برنامه نگهداری',description:'مرحله ۳ از ۳ — قابلیت‌های واقعی PM و چک‌لیست فعلی فقط برای بررسی نمایش داده می‌شوند؛ توسعه پیشرفته در فاز بعدی است.',summary:()=>ctx.asset?`${faText((ctx.asset.pm_plans||[]).length)} برنامه واقعی — بدون تغییر`: 'برنامه PM به‌صورت خودکار ساخته نمی‌شود',render:()=>{
        const plans=ctx.asset?.pm_plans||[];
        const html=plans.length?`<div class="eqv2-wizard-pm-list">${plans.map(plan=>`<article><b>${escText(plan.title||'برنامه PM')}</b><span>${plan.interval_days?faText(plan.interval_days)+' روز':notRecorded}</span><small>آخرین اجرا: ${plan.last_run?formatDate(plan.last_run):'ثبت نشده'} · چک‌لیست: ${faText((plan.checklist||[]).length)} مورد</small></article>`).join('')}</div>`:'<div class="eqv2-wizard-note">برای این تجهیز برنامه PM ثبت نشده است.</div>';
        return`<div class="eqv2-wizard-maintenance"><div class="eqv2-wizard-note">در این فاز PM موجود حذف یا بازنویسی نمی‌شود. ویرایش برنامه و اجرای چک‌لیست از مسیرهای فعلی maintenance-service انجام می‌شود.</div>${html}</div>`;
      }}
    ];
    return steps;
  }
  function installWizardCloseGuard(){
    if(!window.__bfgEquipmentWizardCloseGuard&&typeof window.closeModal==='function'){
      const original=window.closeModal;
      const wrapper=function(...args){
        const active=window.EQV2&&window.EQV2.wizard;
        if(active&&!active.allowClose){
          if(!active.closePending&&active.instance){active.closePending=true;Promise.resolve(active.instance.cancel()).catch(()=>{}).finally(()=>{active.closePending=false;});}
          return;
        }
        if(active){active.allowClose=false;active.instance?.destroy();window.EQV2.wizard=null;}
        return original.apply(this,args);
      };
      window.__bfgEquipmentWizardCloseGuard={original,wrapper};window.closeModal=wrapper;
    }
    if(!window.__bfgEquipmentWizardEscapeGuard&&document&&typeof document.addEventListener==='function'){
      const keydown=event=>{
        if(event.key!=='Escape')return;
        const active=window.EQV2&&window.EQV2.wizard;
        if(!active||active.allowClose||!active.instance)return;
        event.preventDefault();event.stopImmediatePropagation?.();
        if(!active.closePending){active.closePending=true;Promise.resolve(active.instance.cancel()).catch(()=>{}).finally(()=>{active.closePending=false;});}
      };
      document.addEventListener('keydown',keydown,true);window.__bfgEquipmentWizardEscapeGuard=keydown;
    }
    E.closeGuardInstalled=true;
  }
  function setWizardMessage(message){
    const active=E.wizard;if(!active?.instance)return;
    active.instance.state.message=message;active.instance.render();
  }
  function acceptedConflicts(answers){
    return Object.keys(answers||{}).filter(key=>key.startsWith('acceptConflict:')&&answers[key]).map(key=>key.slice('acceptConflict:'.length));
  }
  function evidenceForAction(ctx,payload){
    const existing=Array.isArray(ctx.actionDraft?.evidence)?ctx.actionDraft.evidence.slice():[];
    const sourceRef=ctx.actionDraft?.source?.ref||ctx.sessionId||'user-review';
    for(const [field,value] of Object.entries(payload)){
      if(value==null||value==='')continue;
      const previous=existing.find(item=>item.field===field&&sameValue(item.value,value));
      if(!previous)existing.push({field,value,origin:'user-confirmed-form',sourceRef});
    }
    return existing.slice(0,80);
  }
  async function executeSeleneDraft(ctx,payload,answers){
    const currentVersion=ctx.asset?Number(ctx.asset.row_version||ctx.asset.rowVersion):null;
    if(ctx.actionDraft.actionType==='equipment.complete'&&(!Number.isInteger(currentVersion)||currentVersion<1))throw Object.assign(new Error('ROW_VERSION_REQUIRED'),{payload:{error:'ROW_VERSION_REQUIRED'}});
    const update=await window.bfgApi('/api/equipment/actions/drafts/'+encodeURIComponent(ctx.actionDraft.id),{
      method:'PATCH',body:JSON.stringify({
        rowVersion:ctx.actionDraft.rowVersion,proposed:payload,source:ctx.actionDraft.source,
        evidence:evidenceForAction(ctx,payload),confidence:ctx.actionDraft.confidence,
        current:ctx.actionCurrent||null,acceptConflicts:acceptedConflicts(answers),
        targetId:ctx.actionDraft.targetId,recordVersion:currentVersion
      })
    });
    ctx.actionDraft=update.data;
    if(!ctx.actionDraft||ctx.actionDraft.status!=='pending'){
      const code=ctx.actionDraft?.status==='conflict'?'DRAFT_CONFLICT':'DRAFT_INCOMPLETE';
      throw Object.assign(new Error(code),{payload:{error:code}});
    }
    const confirmation=await window.bfgApi('/api/equipment/actions/drafts/'+encodeURIComponent(ctx.actionDraft.id)+'/confirm',{method:'POST',body:'{}'});
    const requestId=window.crypto?.randomUUID?window.crypto.randomUUID():`eq-${ctx.actionDraft.id}-${Date.now()}`;
    const result=await window.bfgApi('/api/equipment/actions/drafts/'+encodeURIComponent(ctx.actionDraft.id)+'/execute',{
      method:'POST',body:JSON.stringify({confirmationId:confirmation.data.id,requestId})
    });
    if(!result||result.committed!==true)throw Object.assign(new Error('NOT_COMMITTED'),{payload:{error:'NOT_COMMITTED'}});
    return result.data;
  }
  async function returnAfterWizard(ctx,saved,isNew){
    const id=saved?.id||ctx.asset?.id;
    if(!id){await backToEquipment();return;}
    const key=saved?.code||ctx.asset?.code||id;
    if(ctx.returnContext.detail||ctx.selene){
      await openDetail(key,{push:!ctx.returnContext.detail,fromRoute:false});
      E.tab=ctx.returnTab||'technical';
      await renderCurrentDetail();
    }else if(isNew){
      await load();
      await openDetail(key,{push:true});
      E.tab='technical';await renderCurrentDetail();
    }else{
      await load();await select(id,false);
    }
  }
  async function openWizard(idOrOptions=null,step='initial',returnTab=null){
    const opts=idOrOptions&&typeof idOrOptions==='object'?idOrOptions:{id:idOrOptions,startStep:step,returnTab};
    const isSelene=opts.source==='selene';
    const existingId=opts.id||opts.targetId||null;
    if(existingId&&!canDo('edit')){toast('مجوز ویرایش تجهیز را ندارید',1);return;}
    if(!existingId&&!isSelene&&!canDo('create')){toast('مجوز ثبت تجهیز را ندارید',1);return;}
    if(R().source!=='postgresql'){toast('برای ثبت یا ویرایش تجهیز اتصال به Backend الزامی است؛ هیچ داده‌ای به‌صورت محلی ذخیره نمی‌شود.',1);return;}
    if(!window.BFGEquipmentWizardAdapter||!window.BFGStepWizard){toast('موتور مشترک ویزارد بارگذاری نشده است.',1);return;}
    if(E.wizard)return;
    try{
      E.options=await R().filters();
      let asset=null;
      if(existingId){asset=opts.asset||null;if(!asset)asset=(await R().get(existingId)).data;}
      const actionDraft=opts.actionDraft||null;
      const actionCurrent=opts.current||null;
      const record=opts.record||null;
      const answers=answersFromAsset(asset,record);
      const startId=opts.startStep==='structure'?'structure':opts.startStep==='maintenance'?'maintenance':'initialDetails';
      const ctx={
        asset,record,selene:isSelene,actionDraft,actionCurrent,sessionId:opts.sessionId||null,
        confidence:record?.confidence??actionDraft?.confidence??null,
        sourceLabel:opts.provider==='column-match'?'ستون‌های فایل':opts.provider==='deepseek'?'پیشنهاد مدل DeepSeek':opts.provider==='local'?'پیشنهاد مدل محلی':'ورودی سلن',
        rawInstall:answers.__rawInstallDate||null,returnTab:opts.returnTab||E.intakeReturn?.tab||E.tab||'technical',
        returnContext:{detail:E.detail,detailKey:E.detailKey,tab:E.tab||'technical'},instance:null,allowClose:false,closePending:false
      };
      delete answers.__rawInstallDate;
      if(isSelene&&!actionDraft)throw new Error('SELENE_ACTION_DRAFT_REQUIRED');
      const title=asset?'ویرایش پرونده تجهیز':'ثبت تجهیز';
      modal(mhead(title)+`<div class="m-body eqv2-wizard-modal"><div id="eqv2WizardHost"></div></div>`,true);
      const host=document.getElementById('eqv2WizardHost');if(!host)throw new Error('WIZARD_HOST_NOT_FOUND');
      E.wizard=ctx;installWizardCloseGuard();
      const adapterContract={resource:'equipment',version:window.BFGEquipmentWizardAdapter.CONTRACT_VERSION,steps:wizardSteps(ctx)};
      const wizard=window.BFGEquipmentWizardAdapter.create({
        root:host,title,contract:adapterContract,initialAnswers:answers,initialStepId:startId,
        persistDraft:async()=>undefined,
        confirmText:isSelene?'پیشنهاد سلن و همه تغییرهای نمایش‌داده‌شده را برای ذخیره تأیید می‌کنم.':'اطلاعات تجهیز را بررسی و تأیید می‌کنم.',
        submitLabel:isSelene?'تأیید نهایی و ذخیره از مسیر کنترل‌شده':'ثبت در PostgreSQL',
        confirmSubmit:async()=>window.confirm(isSelene?'پس از این تأیید، اقدام کنترل‌شده سلن اجرا و رکورد در Backend ثبت می‌شود. ادامه می‌دهید؟':'پس از این تأیید، اطلاعات تجهیز در Backend ثبت می‌شود. ادامه می‌دهید؟'),
        onPersistenceError:()=>{},
        submit:async({answers:finalAnswers})=>{
          const payload=payloadFromAnswers(finalAnswers,!asset);
          if(asset&&(asset.record_status||asset.recordStatus)==='draft')payload.recordStatus='complete';
          let saved;
          if(isSelene){
            saved=await executeSeleneDraft(ctx,payload,finalAnswers);
          }else if(!asset){
            const result=await R().create(payload);
            if(!result||!result.committed||!result.data)throw Object.assign(new Error('NOT_COMMITTED'),{payload:{error:'NOT_COMMITTED'}});
            saved=result.data;
          }else{
            const changes=changedPayload(payload,asset);
            if(!Object.keys(changes).length){
              toast('تغییری برای ثبت وجود نداشت؛ رکورد دست‌نخورده ماند.');
              ctx.allowClose=true;window.closeModal();return;
            }
            const result=await R().update(asset.id,{...changes,rowVersion:Number(asset.row_version||asset.rowVersion)});
            if(!result||result.committed!==true||!result.data)throw Object.assign(new Error('NOT_COMMITTED'),{payload:{error:'NOT_COMMITTED'}});
            saved=result.data;
          }
          ctx.allowClose=true;window.closeModal();
          toast('تغییرات تجهیز پس از commit در PostgreSQL ثبت شد.');
          await returnAfterWizard(ctx,saved,!asset);
        },
        onSubmitError:error=>{
          const code=error?.payload?.error||error?.message||'EQUIPMENT_SAVE_FAILED';
          if(code==='VERSION_CONFLICT')toast('رکورد هم‌زمان تغییر کرده است؛ داده تازه را بارگذاری و دوباره بازبینی کنید.',1);
          else if(code==='DRAFT_CONFLICT')toast('تعارض داده حل نشده است؛ مقدار فعلی یا پیشنهاد را صریحاً انتخاب کنید.',1);
          else toast('ثبت در PostgreSQL انجام نشد: '+code,1);
        },
        onCancel:async({state})=>{
          if(state.dirty&&!window.confirm('فرم تغییر کرده است. بدون ذخیره بسته شود؟'))return;
          if(isSelene&&ctx.actionDraft?.id){
            try{await window.bfgApi('/api/equipment/actions/drafts/'+encodeURIComponent(ctx.actionDraft.id)+'/reject',{method:'POST',body:'{}'});}
            catch(error){setWizardMessage('پیش‌نویس سلن رد نشد؛ پنجره باز می‌ماند. '+(error.payload?.error||error.message));return;}
          }
          ctx.allowClose=true;window.closeModal();
          if(ctx.selene&&ctx.returnContext.detail){
            await openDetail(ctx.returnContext.detailKey||E.detailKey,{push:false});E.tab=ctx.returnTab;await renderCurrentDetail();
          }else if(ctx.returnContext.detail){await renderCurrentDetail();}
          else await backToEquipment();
        }
      });
      ctx.instance=wizard;
    }catch(error){
      if(E.wizard){E.wizard.allowClose=true;E.wizard=null;}
      closeModal();
      toast('ساخت ویزارد تجهیز انجام نشد: '+(error.payload?.error||error.message||'خطای نامشخص'),1);
    }
  }
  function create(){return openWizard(null,'initial','technical');}
  function edit(id){return openWizard(id,'initial',E.tab||'technical');}
  async function remove(id){
    const reason=prompt('دلیل بایگانی تجهیز را وارد کنید:');
    if(reason===null||!reason.trim()){if(reason!==null)toast('ثبت دلیل بایگانی الزامی است',1);return;}
    if(!confirm('تجهیز بایگانی شود؟ تمام روابط و سوابق آن حفظ خواهد شد.'))return;
    try{
      const {data}=await R().get(id);const row=await R().remove(id,reason.trim(),Number(data.row_version||data.rowVersion));
      if(!row||!row.data)throw new Error('NOT_COMMITTED');
      toast('تجهیز پس از بایگانی نرم در Backend تأیید شد؛ سوابق حفظ شده‌اند.');E.selected=null;
      if(E.detail)await backToEquipment();else await load();
    }catch(error){toast(error.message==='HAS_ACTIVE_CHILDREN'?'ابتدا فرزندان فعال را منتقل کنید':'بایگانی انجام نشد: '+(error.payload?.error||error.message),1);}
  }
  function columns(){modal(mhead('انتخاب ستون‌های لیست')+`<div class="m-body"><div class="eqv2-check-cols">${Object.entries(COLUMNS).map(([key,label])=>`<label class="eqv2-col-opt"><input type="checkbox" value="${key}" ${E.columns.includes(key)?'checked':''}>${label}</label>`).join('')}</div></div><div class="m-foot"><button class="btn btn-primary" onclick="eqv2SaveColumns()">اعمال</button><button class="btn btn-ghost" onclick="closeModal()">انصراف</button></div>`);}
  function saveColumns(){const selected=[...document.querySelectorAll('.eqv2-col-opt input:checked')].map(x=>x.value);if(!selected.length){toast('حداقل یک ستون انتخاب کنید',1);return;}E.columns=selected;saveState();closeModal();load();}
  function exportCsv(){const rows=[[...E.columns.map(key=>COLUMNS[key])],...E.rows.map(a=>E.columns.map(key=>valueFor(a,key)??''))],csv='\ufeff'+rows.map(row=>row.map(value=>'"'+String(value).replace(/"/g,'""')+'"').join(',')).join('\n'),link=document.createElement('a');link.href=URL.createObjectURL(new Blob([csv],{type:'text/csv;charset=utf-8'}));link.download='equipment-list.csv';link.click();URL.revokeObjectURL(link.href);}
  function createRelated(kind,equipmentId){
    const selected=String(equipmentId||'');
    const actions={
      request:{opener:'openReqForm',argument:{equipmentId:selected}},
      wo:{opener:'openWOForm',argument:{equipmentId:selected}},
      pm:{opener:'openPMForm',argument:selected}
    };
    const entry=actions[kind],opener=entry&&window[entry.opener];
    if(typeof opener!=='function'){if(typeof toast==='function')toast('فرم مرکزی مرتبط در دسترس نیست',1);return;}
    return opener.call(window,entry.argument);
  }
  function showError(error){console.error(error);const main=document.querySelector('.eqv2-main')||document.getElementById('content');if(main)main.innerHTML=`<div class="eqv2-empty"><div><i>⚠️</i><b>خطا در دریافت اطلاعات تجهیزات</b><div>${escText(error.payload?.error||error.message)}</div></div></div>`;if(typeof toast==='function')toast('خطا در بخش تجهیزات: '+(error.payload?.error||error.message),1);}

  window.eqv2Search=search;window.eqv2Filter=filter;window.eqv2View=view;window.eqv2Page=pageTo;window.eqv2Load=load;window.eqv2OpenIntake=openIntake;
  window.eqv2Select=select;window.eqv2Create=create;window.eqv2OpenWizard=openWizard;
  window.eqv2Edit=edit;window.eqv2Delete=remove;window.eqv2Columns=columns;window.eqv2SaveColumns=saveColumns;
  window.eqv2Export=exportCsv;window.eqv2Sort=sortBy;window.eqv2OpenDetail=id=>openDetail(id);window.eqv2BackToEquipment=()=>backToEquipment();
  window.eqv2CloseSummary=closeSummary;window.eqv2DetailTab=async tab=>{if(!DETAIL_TABS.some(item=>item[0]===tab))return;E.tab=tab;await renderCurrentDetail();};window.eqv2Related=createRelated;
  window.eqv2StructureAdd=structureAdd;window.eqv2StructureEdit=structureEdit;window.eqv2StructureMove=structureMoveModal;
  window.eqv2StructureArchive=structureArchive;window.eqv2StructureRestore=structureRestore;window.eqv2StructureFocus=structureFocusNode;
  window.eqv2StructureToggle=structureToggle;window.eqv2StructureAddRoot=structureAddRoot;window.eqv2StructureAddMain=structureAddMainComponent;
  window.eqv2StructureActionMenuToggle=structureActionMenuToggle;window.eqv2StructureActionMenuKeydown=structureActionMenuKeydown;
  window.eqv2StructureExpandAll=structureToggleAll;window.eqv2StructureSearch=structureSearch;
  window.eqv2StructureClose=structureClosePanel;window.eqv2StructureCrumb=structureCrumbTo;window.eqv2StructureArchivedToggle=structureArchivedToggle;
  window.eqv2RefreshReviewedStructure=()=>refreshStructure({keepPanel:true}).catch(structureSay);
  window.eqv2StructureMoveSubmit=structureMoveSubmit;window.eqv2StructureCrossSearch=structureCrossSearch;
  window.eqv2SpareAdd=spareAdd;window.eqv2SpareEdit=spareEdit;window.eqv2SpareItemSearch=spareItemSearch;window.eqv2SpareSubmit=spareSubmit;
  window.eqv2SpareArchive=spareArchive;window.eqv2SpareRestore=spareRestore;window.eqv2SparesArchivedToggle=sparesArchivedToggle;
  window.eqv2SpareTargetChanged=spareTargetChanged;
  window.eqv2SparesRefresh=()=>loadSpares(E.detailId).catch(spareSay);
  window.eqv2SpareSuggest=spareSuggest;window.eqv2SpareApprove=spareApprove;window.eqv2SpareReject=spareReject;window.eqv2SpareEditSuggestion=spareEditSuggestion;
  window.eqv2QrModal=qrModal;window.eqv2PrintIdentity=printIdentity;window.eqv2PrintQrLabels=printQrLabels;
  window.eqv2PrintBatchIdentity=printBatchIdentity;window.eqv2OpenPassport=openPassport;
  window.eqv2BatchPrintModal=batchPrintModal;window.eqv2BatchPrintRun=batchPrintRun;
  const previousEquipmentListeners=window.__bfgEquipmentV2Listeners;
  if(previousEquipmentListeners&&typeof window.removeEventListener==='function'){
    if(typeof previousEquipmentListeners.domain==='function')window.removeEventListener('bfg:domain-event',previousEquipmentListeners.domain);
    if(typeof previousEquipmentListeners.popstate==='function')window.removeEventListener('popstate',previousEquipmentListeners.popstate);
  }
  const equipmentDomainEvent=event=>{
    const payload=event&&event.detail;
    if(!payload||!E.detail)return;
    if(payload.type==='equipment.structure.changed'){
      if(String(E.structure?.rootId)!==String(payload.aggregateId))return;
      refreshStructure({keepPanel:true}).catch(()=>{});
    }else if(payload.type==='equipment.spares.changed'){
      if(String(E.detailId)!==String(payload.aggregateId))return;
      if(E.tab==='spares')loadSpares(E.detailId).catch(()=>{});
    }
  };
  const equipmentPopState=()=>{const passportKey=passportRouteKey();if(passportKey){openPassport(passportKey,{push:false,fromRoute:true});return;}const key=routeKey();if(key)openDetail(key,{push:false,fromRoute:true});else if(E.detail||E.passport)backToEquipment({historyMode:'none'});};
  if(typeof window.addEventListener==='function'){
    window.addEventListener('bfg:domain-event',equipmentDomainEvent);
    window.addEventListener('popstate',equipmentPopState);
    window.__bfgEquipmentV2Listeners={domain:equipmentDomainEvent,popstate:equipmentPopState};
  }

  if(typeof pgTree==='function')pgTree=page;else window.pgTree=page;
  const previousLogin=typeof doLogin==='function'?doLogin:null;
  if(previousLogin){
    doLogin=async function(...args){
      const result=await previousLogin.apply(this,args);
      if(typeof ME!=='undefined'&&ME)setTimeout(restoreRoute,250);
      return result;
    };
  }
  if(typeof ME!=='undefined'&&ME)setTimeout(restoreRoute,250);
})();
